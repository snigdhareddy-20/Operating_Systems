# IPC Connect — Inter-Process Chat & Visualization Lab

An interactive educational platform and lab demonstration for the hackathon problem: **Inter-Process Chat Application Using IPC**.

IPC Connect visualizes and explores how independent operating-system processes communicate across virtual-memory isolation boundaries using three primary Linux IPC mechanisms:
1. **Anonymous Pipes (`pipe()`)**
2. **Named Pipes / FIFOs (`mkfifo()`)**
3. **POSIX Shared Memory (`shm_open()` + `mmap()`)**

---

## Architecture Overview

```
                                      +------------------------+
                                      |   Web Frontend UI      |
                                      | (React 19 + Tailwind)  |
                                      +-----------+------------+
                                                  |
                                                  v
                                      +------------------------+
                                      | Node.js / Express Host |
                                      |   (/api/ipc REST)      |
                                      +-----------+------------+
                                                  |
                         +------------------------+------------------------+
                         |                                                 |
                         v                                                 v
             +-----------------------+                         +-----------------------+
             | Simulation Engine     |                         | Native Linux C IPC    |
             | (In-Browser Sandbox)  |                         | (pipe/fifo/shm_chat)  |
             +-----------------------+                         +-----------------------+
```

### Key Features
- **Interactive IPC Playground**: Two independent process panels (Process A: PID 2481, Process B: PID 2482) with full bidirectional two-way chat, preset prompts, and live packet status.
- **Central Channel Visualizer**: Dynamic animated message highway visualizing the kernel ring buffer (64 KB capacity), FIFO filesystem node rendezvous, or POSIX zero-copy RAM addresses with mutex locks.
- **Speed & Error Controls**: Step through communication in Slow-Motion (0.25x), 1x, or Fast mode. Simulate real failure scenarios like **Broken Pipe (`SIGPIPE`)** or **Buffer Overflow Block**.
- **Process Monitor**: Real-time table tracking PID, process state (Running, Stopped, Blocked on I/O), memory footprint (RSS), CPU %, and POSIX signal testing (`SIGUSR1`, `SIGTERM`).
- **Message Logs & CSV Export**: Searchable and filterable history table with full RFC 4180 CSV export download and clear actions.
- **IPC Comparison Matrix & Advisor**: Comprehensive comparison of relationship rules, throughput, synchronization, and persistence, plus an interactive 3-step decision advisor.
- **Learning Center & Mastery Quiz**: 6 in-depth educational modules and an 8-question interactive multiple-choice quiz with immediate answers, explanations, and score tracking.
- **Real Linux C Programs**: 100% production C source files (`pipe_chat.c`, `fifo_chat_a.c`, `fifo_chat_b.c`, `shm_chat.c`) and a `Makefile` ready to compile and run on native Linux.

---

## Quickstart & Installation

### Web Application (Dev Mode)
```bash
# 1. Install dependencies
npm install

# 2. Start full-stack development server on port 3000
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

### Native Linux C Execution (Optional Native Run)
If you are running on native Linux (Ubuntu, Debian, Fedora, Arch) or WSL:
```bash
# Navigate to C source directory
cd ipc_c_source

# Compile all C binaries
make all

# Run Anonymous Pipe demo:
./pipe_chat

# Run Shared Memory with Semaphores demo:
./shm_chat

# Run Named Pipe (FIFO) in two terminals:
# Terminal 1:
./fifo_chat_a
# Terminal 2:
./fifo_chat_b
```

---

## Operating System IPC Concepts Explained

| Mechanism | Process Scope | Copy Model | Synchronization | Persistence |
| :--- | :--- | :--- | :--- | :--- |
| **Anonymous Pipe** | Related (fork) | User ➔ Kernel ➔ User | Built-in OS blocking | Process lifetime |
| **Named Pipe (FIFO)** | Unrelated | User ➔ Kernel ➔ User | Rendezvous blocking | Filesystem inode |
| **Shared Memory** | Unrelated | Zero-Copy (Direct RAM) | Explicit Semaphores | Kernel namespace |

---

## Simulation Mode vs Native Execution
- **Browser Simulation Mode**: Provides instant, safe, visual demonstration of IPC concepts in any browser without needing root permissions or a native Linux C compiler.
- **Native C Mode**: Fully compilable, standard-compliant C source files included under `/ipc_c_source/` for hands-on systems programming assignments.

---

## License
Apache-2.0
