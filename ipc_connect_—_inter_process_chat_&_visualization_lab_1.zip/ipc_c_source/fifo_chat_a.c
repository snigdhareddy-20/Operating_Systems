/* fifo_chat_a.c - Named Pipe (FIFO) Peer A
 *
 * Demonstrates communication between two completely independent processes
 * using filesystem FIFOs in /tmp/.
 *
 * Compile: gcc -Wall -O2 fifo_chat_a.c -o fifo_chat_a
 * Run: ./fifo_chat_a (in Terminal 1)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define FIFO_A2B "/tmp/ipc_chat_a2b.fifo"
#define FIFO_B2A "/tmp/ipc_chat_b2a.fifo"
#define BUFFER_SIZE 256

int main(int argc, char *argv[]) {
    const char *message = (argc >= 2) ? argv[1] : "Greetings from Independent Peer A! FIFO operational.";

    printf("=========================================\n");
    printf(" IPC Connect - Named Pipe (FIFO) Peer A  \n");
    printf("=========================================\n\n");

    // 1. Create FIFO nodes in filesystem if they don't exist
    mkfifo(FIFO_A2B, 0666);
    mkfifo(FIFO_B2A, 0666);

    printf("[Peer A | PID %d] Opening FIFO channels...\n", getpid());
    printf("[Peer A] Waiting for Peer B to connect (Rendezvous blocking)...\n");

    // Open write end to B, then read end from B
    int fd_write = open(FIFO_A2B, O_WRONLY);
    if (fd_write < 0) {
        perror("Failed to open write FIFO");
        exit(EXIT_FAILURE);
    }

    int fd_read = open(FIFO_B2A, O_RDONLY);
    if (fd_read < 0) {
        perror("Failed to open read FIFO");
        exit(EXIT_FAILURE);
    }

    printf("[Peer A] Connection established with Peer B!\n");
    printf("[Peer A] Transmitting message: \"%s\"\n", message);
    if (write(fd_write, message, strlen(message) + 1) == -1) {
        perror("write failed");
    }

    char reply[BUFFER_SIZE];
    printf("[Peer A] Waiting for reply from Peer B...\n");
    ssize_t bytes_read = read(fd_read, reply, sizeof(reply));
    if (bytes_read > 0) {
        printf("[Peer A] Received reply from Peer B: \"%s\"\n", reply);
    }

    close(fd_write);
    close(fd_read);

    printf("[Peer A] Cleaning up FIFO nodes.\n");
    unlink(FIFO_A2B);
    unlink(FIFO_B2A);
    return 0;
}
