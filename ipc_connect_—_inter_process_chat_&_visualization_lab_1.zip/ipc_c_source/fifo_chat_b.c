/* fifo_chat_b.c - Named Pipe (FIFO) Peer B
 *
 * Complementary peer for fifo_chat_a.c.
 *
 * Compile: gcc -Wall -O2 fifo_chat_b.c -o fifo_chat_b
 * Run: ./fifo_chat_b (in Terminal 2)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define FIFO_A2B "/tmp/ipc_chat_a2b.fifo"
#define FIFO_B2A "/tmp/ipc_chat_b2a.fifo"
#define BUFFER_SIZE 256

int main(int argc, char *argv[]) {
    const char *reply = (argc >= 2) ? argv[1] : "ACK: Peer B confirming reception of FIFO packet!";

    printf("=========================================\n");
    printf(" IPC Connect - Named Pipe (FIFO) Peer B  \n");
    printf("=========================================\n\n");

    printf("[Peer B | PID %d] Connecting to Peer A FIFOs...\n", getpid());

    // Peer B opens in complementary order: read first, then write
    int fd_read = open(FIFO_A2B, O_RDONLY);
    if (fd_read < 0) {
        perror("Failed to open read FIFO");
        exit(EXIT_FAILURE);
    }

    int fd_write = open(FIFO_B2A, O_WRONLY);
    if (fd_write < 0) {
        perror("Failed to open write FIFO");
        exit(EXIT_FAILURE);
    }

    printf("[Peer B] Connected! Waiting for message from Peer A...\n");

    char buffer[BUFFER_SIZE];
    ssize_t bytes_read = read(fd_read, buffer, sizeof(buffer));
    if (bytes_read > 0) {
        printf("[Peer B] Received message from Peer A: \"%s\"\n", buffer);
    }

    printf("[Peer B] Sending response back to Peer A: \"%s\"\n", reply);
    if (write(fd_write, reply, strlen(reply) + 1) == -1) {
        perror("write failed");
    }

    close(fd_read);
    close(fd_write);
    return 0;
}
