/* ipc_native_runner.c - Controlled Linux IPC Execution & Experiments Engine
 *
 * Implements genuine Linux IPC:
 * 1. Anonymous Pipes (pipe(), fork(), read(), write())
 * 2. Named Pipes / FIFO (mkfifo(), open(), read(), write(), unlink())
 * 3. POSIX Shared Memory (shm_open(), mmap(), sem_wait(), sem_post())
 * 4. Four Operating System Experiments:
 *    - Receiver Termination (SIGPIPE signal handling)
 *    - Unavailable Reader (FIFO non-blocking ENXIO error)
 *    - Startup Order (Reader-first vs Writer-first rendezvous)
 *    - Synchronization (Data Race without mutex vs Consistency with semaphore)
 *
 * Output: Pure structured JSON for safe Node.js ingestion.
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <signal.h>
#include <errno.h>
#include <time.h>

#define FIFO_A2B "/tmp/ipc_runner_a2b.fifo"
#define FIFO_B2A "/tmp/ipc_runner_b2a.fifo"
#define SHM_NAME "/ipc_runner_shm"
#define BUFFER_SIZE 512

static volatile sig_atomic_t g_got_sigpipe = 0;

static void sigpipe_handler(int sig) {
    (void)sig;
    g_got_sigpipe = 1;
}

// Microsecond timestamp
static long long get_time_us(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (long long)ts.tv_sec * 1000000LL + (ts.tv_nsec / 1000LL);
}

// Escape string for JSON
static void print_json_string(const char *str) {
    putchar('"');
    while (*str) {
        if (*str == '"') printf("\\\"");
        else if (*str == '\\') printf("\\\\");
        else if (*str == '\n') printf("\\n");
        else if (*str == '\r') printf("\\r");
        else if (*str == '\t') printf("\\t");
        else putchar(*str);
        str++;
    }
    putchar('"');
}

/* ========================================================================= */
/* 1. ANONYMOUS PIPE EXECUTION                                               */
/* ========================================================================= */
static void run_pipe(const char *msg_out, const char *msg_reply) {
    int pipe_a2b[2];
    int pipe_b2a[2];

    long long t_start = get_time_us();

    if (pipe(pipe_a2b) == -1 || pipe(pipe_b2a) == -1) {
        printf("{\"success\":false,\"error\":\"Failed to create pipe: %s\"}\n", strerror(errno));
        return;
    }

    pid_t parent_pid = getpid();
    pid_t pid = fork();

    if (pid < 0) {
        printf("{\"success\":false,\"error\":\"fork failed: %s\"}\n", strerror(errno));
        return;
    }

    if (pid == 0) {
        /* Child: Process B */
        close(pipe_a2b[1]);
        close(pipe_b2a[0]);

        char buf[BUFFER_SIZE];
        memset(buf, 0, sizeof(buf));
        ssize_t n = read(pipe_a2b[0], buf, sizeof(buf) - 1);
        (void)n;

        const char *reply = (msg_reply && strlen(msg_reply) > 0)
            ? msg_reply
            : "ACK: Process B received packet through anonymous pipe";
        ssize_t w = write(pipe_b2a[1], reply, strlen(reply) + 1);
        (void)w;

        close(pipe_a2b[0]);
        close(pipe_b2a[1]);
        _exit(0);
    } else {
        /* Parent: Process A */
        close(pipe_a2b[0]);
        close(pipe_b2a[1]);

        ssize_t w = write(pipe_a2b[1], msg_out, strlen(msg_out) + 1);
        (void)w;

        char reply_buf[BUFFER_SIZE];
        memset(reply_buf, 0, sizeof(reply_buf));
        ssize_t r = read(pipe_b2a[0], reply_buf, sizeof(reply_buf) - 1);
        (void)r;

        close(pipe_a2b[1]);
        close(pipe_b2a[0]);
        waitpid(pid, NULL, 0);

        long long t_end = get_time_us();
        double latency_ms = (t_end - t_start) / 1000.0;

        printf("{\n");
        printf("  \"success\": true,\n");
        printf("  \"mode\": \"native_linux\",\n");
        printf("  \"mechanism\": \"pipe\",\n");
        printf("  \"mechanismLabel\": \"Anonymous Pipes (pipe())\",\n");
        printf("  \"senderPid\": %d,\n", (int)parent_pid);
        printf("  \"receiverPid\": %d,\n", (int)pid);
        printf("  \"payloadSent\": "); print_json_string(msg_out); printf(",\n");
        printf("  \"replyReceived\": "); print_json_string(reply_buf); printf(",\n");
        printf("  \"bytesSent\": %zu,\n", strlen(msg_out) + 1);
        printf("  \"latencyMs\": %.3f,\n", latency_ms);
        printf("  \"channel\": \"pipefs: fd[%d] -> fd[%d] (Ring Buffer 64KB)\",\n", pipe_a2b[1], pipe_a2b[0]);
        printf("  \"systemCalls\": [\n");
        printf("    {\"syscall\": \"pipe(pipe_a2b)\", \"description\": \"Kernel created pipe descriptors fd[%d, %d] in pipefs\"},\n", pipe_a2b[0], pipe_a2b[1]);
        printf("    {\"syscall\": \"fork()\", \"description\": \"Child Process B (PID %d) spawned; inherited descriptor table\"},\n", (int)pid);
        printf("    {\"syscall\": \"write(fd[%d], payload)\", \"description\": \"Process A copied %zu bytes into kernel ring buffer\"},\n", pipe_a2b[1], strlen(msg_out) + 1);
        printf("    {\"syscall\": \"read(fd[%d], buf)\", \"description\": \"Process B extracted payload in FIFO order\"},\n", pipe_a2b[0]);
        printf("    {\"syscall\": \"close(fds)\", \"description\": \"Descriptors closed, ring buffer freed\"}\n");
        printf("  ]\n");
        printf("}\n");
    }
}

/* ========================================================================= */
/* 2. NAMED PIPE (FIFO) EXECUTION                                            */
/* ========================================================================= */
static void run_fifo(const char *msg_out, const char *msg_reply) {
    long long t_start = get_time_us();

    unlink(FIFO_A2B);
    unlink(FIFO_B2A);

    if (mkfifo(FIFO_A2B, 0666) == -1 || mkfifo(FIFO_B2A, 0666) == -1) {
        printf("{\"success\":false,\"error\":\"mkfifo failed: %s\"}\n", strerror(errno));
        return;
    }

    pid_t parent_pid = getpid();
    pid_t pid = fork();

    if (pid < 0) {
        printf("{\"success\":false,\"error\":\"fork failed: %s\"}\n", strerror(errno));
        return;
    }

    if (pid == 0) {
        /* Child: Process B */
        int fd_read = open(FIFO_A2B, O_RDONLY);
        int fd_write = open(FIFO_B2A, O_WRONLY);

        char buf[BUFFER_SIZE];
        memset(buf, 0, sizeof(buf));
        ssize_t n = read(fd_read, buf, sizeof(buf) - 1);
        (void)n;

        const char *reply = (msg_reply && strlen(msg_reply) > 0)
            ? msg_reply
            : "ACK: Process B received packet from Named FIFO";
        ssize_t w = write(fd_write, reply, strlen(reply) + 1);
        (void)w;

        close(fd_read);
        close(fd_write);
        _exit(0);
    } else {
        /* Parent: Process A */
        int fd_write = open(FIFO_A2B, O_WRONLY);
        int fd_read = open(FIFO_B2A, O_RDONLY);

        ssize_t w = write(fd_write, msg_out, strlen(msg_out) + 1);
        (void)w;

        char reply_buf[BUFFER_SIZE];
        memset(reply_buf, 0, sizeof(reply_buf));
        ssize_t r = read(fd_read, reply_buf, sizeof(reply_buf) - 1);
        (void)r;

        close(fd_write);
        close(fd_read);
        waitpid(pid, NULL, 0);

        unlink(FIFO_A2B);
        unlink(FIFO_B2A);

        long long t_end = get_time_us();
        double latency_ms = (t_end - t_start) / 1000.0;

        printf("{\n");
        printf("  \"success\": true,\n");
        printf("  \"mode\": \"native_linux\",\n");
        printf("  \"mechanism\": \"fifo\",\n");
        printf("  \"mechanismLabel\": \"Named Pipes (mkfifo())\",\n");
        printf("  \"senderPid\": %d,\n", (int)parent_pid);
        printf("  \"receiverPid\": %d,\n", (int)pid);
        printf("  \"fifoPath\": \"%s\",\n", FIFO_A2B);
        printf("  \"payloadSent\": "); print_json_string(msg_out); printf(",\n");
        printf("  \"replyReceived\": "); print_json_string(reply_buf); printf(",\n");
        printf("  \"bytesSent\": %zu,\n", strlen(msg_out) + 1);
        printf("  \"latencyMs\": %.3f,\n", latency_ms);
        printf("  \"channel\": \"filesystem inode: %s (mode 0666)\",\n", FIFO_A2B);
        printf("  \"systemCalls\": [\n");
        printf("    {\"syscall\": \"mkfifo(%s, 0666)\", \"description\": \"Created special FIFO filesystem node in VFS\"},\n", FIFO_A2B);
        printf("    {\"syscall\": \"open(O_WRONLY)\", \"description\": \"Process A opened write end; blocked until Process B opened read end (Rendezvous)\"},\n");
        printf("    {\"syscall\": \"write(fd, payload)\", \"description\": \"Transmitted %zu bytes directly via kernel buffer (zero disk writes)\"},\n", strlen(msg_out) + 1);
        printf("    {\"syscall\": \"read(fd, buf)\", \"description\": \"Process B drained bytes from named channel\"},\n");
        printf("    {\"syscall\": \"unlink(path)\", \"description\": \"Cleaned up temporary named pipe node from /tmp/\"}\n");
        printf("  ]\n");
        printf("}\n");
    }
}

/* ========================================================================= */
/* 3. POSIX SHARED MEMORY EXECUTION                                          */
/* ========================================================================= */
struct shared_block {
    sem_t mutex;
    sem_t data_ready;
    sem_t data_read;
    int seq;
    char text[BUFFER_SIZE];
};

static void run_shm(const char *msg_out, const char *msg_reply) {
    long long t_start = get_time_us();

    shm_unlink(SHM_NAME);
    int shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        printf("{\"success\":false,\"error\":\"shm_open failed: %s\"}\n", strerror(errno));
        return;
    }

    if (ftruncate(shm_fd, sizeof(struct shared_block)) == -1) {
        printf("{\"success\":false,\"error\":\"ftruncate failed: %s\"}\n", strerror(errno));
        close(shm_fd);
        return;
    }

    struct shared_block *shared = mmap(NULL, sizeof(struct shared_block),
                                       PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shared == MAP_FAILED) {
        printf("{\"success\":false,\"error\":\"mmap failed: %s\"}\n", strerror(errno));
        close(shm_fd);
        return;
    }

    // Process-shared semaphores (pshared = 1)
    sem_init(&shared->mutex, 1, 1);
    sem_init(&shared->data_ready, 1, 0);
    sem_init(&shared->data_read, 1, 0);
    shared->seq = 1;

    char virtual_addr_str[32];
    snprintf(virtual_addr_str, sizeof(virtual_addr_str), "%p", (void*)shared);

    pid_t parent_pid = getpid();
    pid_t pid = fork();

    if (pid < 0) {
        printf("{\"success\":false,\"error\":\"fork failed: %s\"}\n", strerror(errno));
        return;
    }

    if (pid == 0) {
        /* Child: Process B */
        sem_wait(&shared->data_ready);
        sem_wait(&shared->mutex);

        // Read directly from RAM (Zero-Copy)
        char read_content[BUFFER_SIZE];
        strncpy(read_content, shared->text, sizeof(read_content) - 1);

        // Write reply back into the same shared memory slot
        const char *reply = (msg_reply && strlen(msg_reply) > 0)
            ? msg_reply
            : "ACK: Process B read zero-copy payload from RAM";
        strncpy(shared->text, reply, sizeof(shared->text) - 1);

        sem_post(&shared->mutex);
        sem_post(&shared->data_read);

        munmap(shared, sizeof(struct shared_block));
        close(shm_fd);
        _exit(0);
    } else {
        /* Parent: Process A */
        sem_wait(&shared->mutex);
        strncpy(shared->text, msg_out, sizeof(shared->text) - 1);
        sem_post(&shared->mutex);
        sem_post(&shared->data_ready);

        // Wait for child consumption & reply
        sem_wait(&shared->data_read);
        sem_wait(&shared->mutex);

        char reply_buf[BUFFER_SIZE];
        strncpy(reply_buf, shared->text, sizeof(reply_buf) - 1);
        sem_post(&shared->mutex);

        waitpid(pid, NULL, 0);

        munmap(shared, sizeof(struct shared_block));
        close(shm_fd);
        shm_unlink(SHM_NAME);

        long long t_end = get_time_us();
        double latency_ms = (t_end - t_start) / 1000.0;

        printf("{\n");
        printf("  \"success\": true,\n");
        printf("  \"mode\": \"native_linux\",\n");
        printf("  \"mechanism\": \"shm\",\n");
        printf("  \"mechanismLabel\": \"POSIX Shared Memory (mmap())\",\n");
        printf("  \"senderPid\": %d,\n", (int)parent_pid);
        printf("  \"receiverPid\": %d,\n", (int)pid);
        printf("  \"shmAddress\": \"%s\",\n", virtual_addr_str);
        printf("  \"payloadSent\": "); print_json_string(msg_out); printf(",\n");
        printf("  \"replyReceived\": "); print_json_string(reply_buf); printf(",\n");
        printf("  \"bytesSent\": %zu,\n", strlen(msg_out) + 1);
        printf("  \"latencyMs\": %.3f,\n", latency_ms);
        printf("  \"channel\": \"Physical RAM Page mapped at %s (Zero-Copy)\",\n", virtual_addr_str);
        printf("  \"systemCalls\": [\n");
        printf("    {\"syscall\": \"shm_open(%s)\", \"description\": \"Created POSIX shared memory object in /dev/shm\"},\n", SHM_NAME);
        printf("    {\"syscall\": \"ftruncate(fd, 4096)\", \"description\": \"Allocated 4KB memory page\"},\n");
        printf("    {\"syscall\": \"mmap(%s)\", \"description\": \"Mapped physical page into virtual address space\"},\n", virtual_addr_str);
        printf("    {\"syscall\": \"sem_wait(&mutex)\", \"description\": \"Acquired mutual exclusion lock before writing\"},\n");
        printf("    {\"syscall\": \"memcpy() in RAM\", \"description\": \"Wrote payload directly with ZERO kernel copy overhead\"},\n");
        printf("    {\"syscall\": \"sem_post(&data_ready)\", \"description\": \"Signaled consumer process that buffer is populated\"},\n");
        printf("    {\"syscall\": \"munmap() + shm_unlink()\", \"description\": \"Unmapped address and unlinked shared memory object\"}\n");
        printf("  ]\n");
        printf("}\n");
    }
}

/* ========================================================================= */
/* 4. EXPERIMENTS ENGINE                                                     */
/* ========================================================================= */
static void run_experiment(const char *type) {
    if (strcmp(type, "receiver_termination") == 0) {
        /* Experiment 1: Receiver Termination (SIGPIPE) */
        struct sigaction sa;
        memset(&sa, 0, sizeof(sa));
        sa.sa_handler = sigpipe_handler;
        sigaction(SIGPIPE, &sa, NULL);

        int pfd[2];
        pipe(pfd);

        // Close read end immediately to simulate dead receiver
        close(pfd[0]);

        g_got_sigpipe = 0;
        char test_data[] = "Attempting to write to dead reader";
        ssize_t ret = write(pfd[1], test_data, strlen(test_data));
        int saved_errno = errno;

        close(pfd[1]);

        printf("{\n");
        printf("  \"success\": true,\n");
        printf("  \"experiment\": \"receiver_termination\",\n");
        printf("  \"title\": \"Receiver Termination & SIGPIPE Test\",\n");
        printf("  \"hypothesis\": \"Writing to a pipe with no active read descriptor triggers SIGPIPE and EPIPE.\",\n");
        printf("  \"receivedSignal\": %s,\n", g_got_sigpipe ? "\"SIGPIPE (Signal 13)\"" : "\"None\"");
        printf("  \"writeReturnValue\": %zd,\n", ret);
        printf("  \"errorCode\": %d,\n", saved_errno);
        printf("  \"errorName\": \"%s\",\n", strerror(saved_errno));
        printf("  \"explanation\": \"When the reader process exits or closes its read descriptor, the OS kernel delivers signal 13 (SIGPIPE) to the writer. write() immediately returns -1 with errno EPIPE (Broken pipe).\",\n");
        printf("  \"verified\": %s\n", (g_got_sigpipe && ret == -1 && saved_errno == EPIPE) ? "true" : "false");
        printf("}\n");

    } else if (strcmp(type, "unavailable_reader") == 0) {
        /* Experiment 2: Unavailable Reader on FIFO */
        unlink("/tmp/test_unavailable.fifo");
        mkfifo("/tmp/test_unavailable.fifo", 0666);

        // Attempt non-blocking write open with no reader
        int fd = open("/tmp/test_unavailable.fifo", O_WRONLY | O_NONBLOCK);
        int saved_errno = errno;

        unlink("/tmp/test_unavailable.fifo");

        printf("{\n");
        printf("  \"success\": true,\n");
        printf("  \"experiment\": \"unavailable_reader\",\n");
        printf("  \"title\": \"Unavailable Reader & Non-blocking FIFO Test\",\n");
        printf("  \"hypothesis\": \"Opening a FIFO for writing with O_NONBLOCK when no process has it open for reading fails with ENXIO.\",\n");
        printf("  \"openReturnValue\": %d,\n", fd);
        printf("  \"errorCode\": %d,\n", saved_errno);
        printf("  \"errorName\": \"%s\",\n", strerror(saved_errno));
        printf("  \"explanation\": \"In POSIX, opening a FIFO for writing requires a reader. If O_NONBLOCK is set and no reader exists, open() returns -1 with ENXIO (No such device or address). In blocking mode, it pauses until a reader connects.\",\n");
        printf("  \"verified\": %s\n", (fd == -1 && saved_errno == ENXIO) ? "true" : "false");
        printf("}\n");

    } else if (strcmp(type, "startup_order") == 0) {
        /* Experiment 3: Process Startup Order (Rendezvous) */
        unlink("/tmp/test_rendezvous.fifo");
        mkfifo("/tmp/test_rendezvous.fifo", 0666);

        long long t0 = get_time_us();

        pid_t pid = fork();
        if (pid == 0) {
            // Child delays 100ms before opening reader
            usleep(100000);
            int rfd = open("/tmp/test_rendezvous.fifo", O_RDONLY);
            close(rfd);
            _exit(0);
        } else {
            // Parent opens writer immediately; should block until child opens reader!
            int wfd = open("/tmp/test_rendezvous.fifo", O_WRONLY);
            long long t1 = get_time_us();
            close(wfd);
            waitpid(pid, NULL, 0);
            unlink("/tmp/test_rendezvous.fifo");

            double blocked_time_ms = (t1 - t0) / 1000.0;

            printf("{\n");
            printf("  \"success\": true,\n");
            printf("  \"experiment\": \"startup_order\",\n");
            printf("  \"title\": \"FIFO Process Startup Order & Rendezvous Test\",\n");
            printf("  \"hypothesis\": \"The first process to open a FIFO blocks automatically until the second process connects.\",\n");
            printf("  \"childDelayMs\": 100.0,\n");
            printf("  \"writerBlockedTimeMs\": %.2f,\n", blocked_time_ms);
            printf("  \"explanation\": \"Process A opened write end at T=0ms and was blocked by the kernel scheduler until Process B opened read end at T=100ms. Total rendezvous block: %.2f ms.\",\n", blocked_time_ms);
            printf("  \"verified\": %s\n", blocked_time_ms >= 80.0 ? "true" : "false");
            printf("}\n");
        }

    } else if (strcmp(type, "synchronization") == 0) {
        /* Experiment 4: Shared Memory Synchronization (Race Condition vs Mutex) */
        struct test_counter {
            sem_t sem;
            long count_unsynced;
            long count_synced;
        };

        struct test_counter *tc = mmap(NULL, sizeof(struct test_counter),
                                       PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
        tc->count_unsynced = 0;
        tc->count_synced = 0;
        sem_init(&tc->sem, 1, 1);

        const int iterations = 10000;

        pid_t pid = fork();
        if (pid == 0) {
            for (int i = 0; i < iterations; i++) {
                // Unsynchronized (Race condition)
                long temp = tc->count_unsynced;
                tc->count_unsynced = temp + 1;

                // Synchronized with Semaphore
                sem_wait(&tc->sem);
                tc->count_synced++;
                sem_post(&tc->sem);
            }
            _exit(0);
        } else {
            for (int i = 0; i < iterations; i++) {
                long temp = tc->count_unsynced;
                tc->count_unsynced = temp + 1;

                sem_wait(&tc->sem);
                tc->count_synced++;
                sem_post(&tc->sem);
            }
            waitpid(pid, NULL, 0);

            long expected = iterations * 2;
            long actual_unsynced = tc->count_unsynced;
            long actual_synced = tc->count_synced;

            printf("{\n");
            printf("  \"success\": true,\n");
            printf("  \"experiment\": \"synchronization\",\n");
            printf("  \"title\": \"Shared Memory Concurrency & Mutex Synchronization Test\",\n");
            printf("  \"hypothesis\": \"Concurrent writes without a mutex suffer lost updates; semaphores guarantee strict consistency.\",\n");
            printf("  \"expectedCount\": %ld,\n", expected);
            printf("  \"unsyncedCount\": %ld,\n", actual_unsynced);
            printf("  \"syncedCount\": %ld,\n", actual_synced);
            printf("  \"raceConditionDetected\": %s,\n", (actual_unsynced != expected) ? "true" : "false");
            printf("  \"explanation\": \"Two processes executed %d increments each. Without synchronization, concurrent memory reads produced %ld lost updates (%ld vs %ld). With semaphores, the count reached exactly %ld.\",\n",
                   iterations, expected - actual_unsynced, actual_unsynced, expected, actual_synced);
            printf("  \"verified\": %s\n", (actual_synced == expected) ? "true" : "false");
            printf("}\n");

            munmap(tc, sizeof(struct test_counter));
        }
    } else {
        printf("{\"success\":false,\"error\":\"Unknown experiment type\"}\n");
    }
}

/* ========================================================================= */
/* MAIN ENTRY POINT                                                          */
/* ========================================================================= */
int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("{\"error\":\"Usage: ipc_runner <pipe|fifo|shm|experiment> [args...]\"}\n");
        return 1;
    }

    const char *cmd = argv[1];

    if (strcmp(cmd, "pipe") == 0) {
        const char *msg = (argc >= 3) ? argv[2] : "Hello from Process A via Pipe";
        const char *reply = (argc >= 4) ? argv[3] : "ACK from Process B";
        run_pipe(msg, reply);
    } else if (strcmp(cmd, "fifo") == 0) {
        const char *msg = (argc >= 3) ? argv[2] : "Greetings from Process A via FIFO";
        const char *reply = (argc >= 4) ? argv[3] : "ACK from Process B";
        run_fifo(msg, reply);
    } else if (strcmp(cmd, "shm") == 0) {
        const char *msg = (argc >= 3) ? argv[2] : "Direct RAM Packet via Shared Memory";
        const char *reply = (argc >= 4) ? argv[3] : "ACK from Process B";
        run_shm(msg, reply);
    } else if (strcmp(cmd, "experiment") == 0) {
        if (argc < 3) {
            printf("{\"error\":\"Missing experiment type\"}\n");
            return 1;
        }
        run_experiment(argv[2]);
    } else {
        printf("{\"error\":\"Unknown command '%s'\"}\n", cmd);
        return 1;
    }

    return 0;
}
