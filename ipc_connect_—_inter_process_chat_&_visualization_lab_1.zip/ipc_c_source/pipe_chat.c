/* pipe_chat.c - Anonymous Pipe Bidirectional Communication
 *
 * Demonstrates full-duplex communication between parent and child processes
 * using two unidirectional Linux pipes.
 *
 * Compile: gcc -Wall -O2 pipe_chat.c -o pipe_chat
 * Run: ./pipe_chat
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define BUFFER_SIZE 256

int main(int argc, char *argv[]) {
    int pipe_a2b[2]; // Pipe: Process A (parent) -> Process B (child)
    int pipe_b2a[2]; // Pipe: Process B (child) -> Process A (parent)
    pid_t pid;

    const char *custom_msg = (argc >= 2) ? argv[1] : "Hello from Process A (Parent PID)! Ready for sync.";
    const char *custom_reply = (argc >= 3) ? argv[2] : "ACK: Process B received message and verified integrity!";

    printf("========================================\n");
    printf(" IPC Connect - Anonymous Pipe Lab Demo   \n");
    printf("========================================\n\n");

    // Create two pipes
    if (pipe(pipe_a2b) == -1 || pipe(pipe_b2a) == -1) {
        perror("pipe creation failed");
        exit(EXIT_FAILURE);
    }

    pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        /* ================= PROCESS A (Parent) ================= */
        // Close unused ends to prevent deadlocks and broken pipe leaks
        close(pipe_a2b[0]); // Close read end of A->B
        close(pipe_b2a[1]); // Close write end of B->A

        printf("[Process A | PID %d] Sending packet via pipe_a2b...\n", getpid());
        printf("[Process A] Content: \"%s\"\n", custom_msg);

        if (write(pipe_a2b[1], custom_msg, strlen(custom_msg) + 1) == -1) {
            perror("write failed");
        }

        char msg_in[BUFFER_SIZE];
        printf("[Process A] Waiting on pipe_b2a for reply (blocking read)...\n");
        ssize_t bytes_read = read(pipe_b2a[0], msg_in, sizeof(msg_in));

        if (bytes_read > 0) {
            printf("[Process A] SUCCESS! Received %zd bytes from Process B: \"%s\"\n", bytes_read, msg_in);
        }

        close(pipe_a2b[1]);
        close(pipe_b2a[0]);

        wait(NULL); // Reap child process
        printf("\n[Process A] Child process terminated cleanly. Demo complete.\n");
    } else {
        /* ================= PROCESS B (Child) ================= */
        // Close unused ends
        close(pipe_a2b[1]); // Close write end of A->B
        close(pipe_b2a[0]); // Close read end of B->A

        char msg_in[BUFFER_SIZE];
        printf("    [Process B | PID %d] Waiting for message from Parent...\n", getpid());
        ssize_t bytes_read = read(pipe_a2b[0], msg_in, sizeof(msg_in));

        if (bytes_read > 0) {
            printf("    [Process B] Received %zd bytes: \"%s\"\n", bytes_read, msg_in);
        }

        printf("    [Process B] Sending reply packet back via pipe_b2a...\n");
        if (write(pipe_b2a[1], custom_reply, strlen(custom_reply) + 1) == -1) {
            perror("write failed");
        }

        close(pipe_a2b[0]);
        close(pipe_b2a[1]);
        exit(EXIT_SUCCESS);
    }

    return 0;
}
