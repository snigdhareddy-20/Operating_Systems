/* shm_chat.c - POSIX Shared Memory with Process-Shared Semaphores
 *
 * Demonstrates zero-copy inter-process communication using shm_open(),
 * mmap(), and POSIX semaphores for mutual exclusion synchronization.
 *
 * Compile: gcc -Wall -O2 shm_chat.c -o shm_chat -lrt -pthread
 * Run: ./shm_chat
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <semaphore.h>
#include <unistd.h>

#define SHM_NAME "/ipc_chat_shm_demo"
#define TEXT_SIZE 512

// Shared control and data structure residing in physical RAM
struct shared_chat_block {
    sem_t mutex;            // Mutex binary semaphore protecting critical section
    sem_t msg_ready;        // Signaled by writer when new packet is placed
    sem_t msg_consumed;     // Signaled by reader when packet is extracted
    int sequence_number;
    char sender_name[32];
    char text[TEXT_SIZE];
};

int main(int argc, char *argv[]) {
    const char *payload = (argc >= 2) ? argv[1] : "High-throughput direct memory packet committed to physical RAM";

    printf("====================================================\n");
    printf(" IPC Connect - POSIX Shared Memory & Semaphore Demo \n");
    printf("====================================================\n\n");

    // 1. Create POSIX shared memory object
    int shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    if (shm_fd == -1) {
        perror("shm_open failed");
        exit(EXIT_FAILURE);
    }

    // Configure size of shared memory segment
    if (ftruncate(shm_fd, sizeof(struct shared_chat_block)) == -1) {
        perror("ftruncate failed");
        exit(EXIT_FAILURE);
    }

    // 2. Map shared memory into process address space (Zero-Copy)
    struct shared_chat_block *shared = mmap(
        NULL, sizeof(struct shared_chat_block),
        PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0
    );
    if (shared == MAP_FAILED) {
        perror("mmap failed");
        exit(EXIT_FAILURE);
    }

    // 3. Initialize process-shared semaphores (pshared = 1)
    sem_init(&shared->mutex, 1, 1);
    sem_init(&shared->msg_ready, 1, 0);
    sem_init(&shared->msg_consumed, 1, 1);
    shared->sequence_number = 0;

    printf("[Parent] Shared Memory segment allocated at virtual address %p\n", (void*)shared);

    pid_t pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        /* ================= PRODUCER (Parent) ================= */
        printf("[Process A | PID %d] Preparing zero-copy packet...\n", getpid());

        // Wait until consumer is ready
        sem_wait(&shared->msg_consumed);
        // Acquire mutex lock
        sem_wait(&shared->mutex);

        shared->sequence_number++;
        strncpy(shared->sender_name, "Process_A_Parent", sizeof(shared->sender_name) - 1);
        strncpy(shared->text, payload, sizeof(shared->text) - 1);

        printf("[Process A] Wrote directly into RAM segment with ZERO kernel buffer copies.\n");
        printf("[Process A] Content: \"%s\"\n", shared->text);

        // Release mutex and signal consumer
        sem_post(&shared->mutex);
        sem_post(&shared->msg_ready);

        wait(NULL); // Wait for child

        // Cleanup
        munmap(shared, sizeof(struct shared_chat_block));
        close(shm_fd);
        shm_unlink(SHM_NAME);
        printf("\n[Parent] Shared memory unlinked and released. Success.\n");
    } else {
        /* ================= CONSUMER (Child) ================= */
        printf("    [Process B | PID %d] Attached to shared memory segment %p\n", getpid(), (void*)shared);
        printf("    [Process B] Waiting for sem_wait(msg_ready)...\n");

        sem_wait(&shared->msg_ready);
        sem_wait(&shared->mutex);

        printf("    [Process B] SUCCESS! Read directly from RAM [Seq #%d]: \"%s\"\n",
               shared->sequence_number, shared->text);

        sem_post(&shared->mutex);
        sem_post(&shared->msg_consumed); // Acknowledge consumption

        munmap(shared, sizeof(struct shared_chat_block));
        close(shm_fd);
        exit(EXIT_SUCCESS);
    }

    return 0;
}
