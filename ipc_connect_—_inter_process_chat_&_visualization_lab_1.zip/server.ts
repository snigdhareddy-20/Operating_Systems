import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { execFile } from 'child_process';
import { promisify } from 'util';

const execFileAsync = promisify(execFile);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const RUNNER_PATH = path.resolve(__dirname, 'ipc_c_source', 'ipc_native_runner');

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  app.use(express.json({ limit: '1mb' }));

  // Check if compiled native C binary is available and executable
  const isNativeBinaryReady = () => {
    try {
      return fs.existsSync(RUNNER_PATH) && (fs.statSync(RUNNER_PATH).mode & 0o111) !== 0;
    } catch {
      return false;
    }
  };

  // Health and System Info endpoint
  app.get('/api/health', (req, res) => {
    const nativeReady = isNativeBinaryReady();
    res.json({
      status: 'ok',
      service: 'ipc-connect-backend',
      timestamp: new Date().toISOString(),
      platform: process.platform,
      arch: process.arch,
      nodeVersion: process.version,
      pid: process.pid,
      nativeExecutionAvailable: nativeReady,
      binaryPath: nativeReady ? RUNNER_PATH : null
    });
  });

  // Safe IPC status API
  app.get('/api/ipc/status', (req, res) => {
    const nativeReady = isNativeBinaryReady();
    res.json({
      mode: nativeReady ? 'native_linux' : 'simulation_mode',
      label: nativeReady ? 'Native Linux C IPC Active' : 'Browser Simulation Mode',
      nativeAvailable: nativeReady,
      backendPid: process.pid,
      uptimeSeconds: Math.floor(process.uptime()),
      activeChannels: ['pipe', 'fifo', 'shm'],
      experiments: ['receiver_termination', 'unavailable_reader', 'startup_order', 'synchronization'],
      memoryFootprintMb: (process.memoryUsage().rss / (1024 * 1024)).toFixed(2)
    });
  });

  // Safe IPC Native Execution Endpoint (execFile - NO SHELL EXPANSION)
  app.post('/api/ipc/send-native', async (req, res) => {
    const { mechanism, content, reply } = req.body;

    // Strict validation
    if (!['pipe', 'fifo', 'shm'].includes(mechanism)) {
      return res.status(400).json({ error: 'Invalid IPC mechanism. Allowed: pipe, fifo, shm.' });
    }

    if (!content || typeof content !== 'string') {
      return res.status(400).json({ error: 'Message content is required.' });
    }

    // Limit length to avoid buffer overflow
    const safeContent = content.slice(0, 256);
    const safeReply = typeof reply === 'string' ? reply.slice(0, 256) : '';

    if (!isNativeBinaryReady()) {
      return res.status(503).json({
        error: 'Native C binary is not compiled on this host. Use Simulation Mode.',
        mode: 'simulation_mode'
      });
    }

    try {
      // Execute the predefined C runner directly via argv (safe, no arbitrary shell command!)
      const args = [mechanism, safeContent];
      if (safeReply) args.push(safeReply);

      const { stdout } = await execFileAsync(RUNNER_PATH, args, {
        timeout: 5000,
        maxBuffer: 1024 * 512
      });

      const parsed = JSON.parse(stdout.trim());
      res.json(parsed);
    } catch (err: any) {
      console.error('Failed to execute native C runner:', err);
      res.status(500).json({
        error: err.message || 'Execution failed',
        details: err.stderr || ''
      });
    }
  });

  // Safe Predefined Operating System Experiment Endpoint
  app.post('/api/ipc/experiment', async (req, res) => {
    const { type } = req.body;
    const allowed = ['receiver_termination', 'unavailable_reader', 'startup_order', 'synchronization'];

    if (!allowed.includes(type)) {
      return res.status(400).json({ error: `Invalid experiment type. Allowed: ${allowed.join(', ')}` });
    }

    if (!isNativeBinaryReady()) {
      return res.status(503).json({
        error: 'Native C binary is not compiled on this host.',
        mode: 'simulation_mode'
      });
    }

    try {
      const { stdout } = await execFileAsync(RUNNER_PATH, ['experiment', type], {
        timeout: 5000
      });
      const parsed = JSON.parse(stdout.trim());
      res.json(parsed);
    } catch (err: any) {
      console.error('Failed to execute experiment:', err);
      res.status(500).json({ error: err.message || 'Experiment execution failed' });
    }
  });

  // Automated Repeated Benchmark Runner for Comparison Dashboard
  app.post('/api/ipc/benchmark', async (req, res) => {
    const rounds = Math.min(20, Math.max(3, parseInt(req.body.rounds, 10) || 5));

    if (!isNativeBinaryReady()) {
      return res.status(503).json({ error: 'Native C binary not compiled.' });
    }

    try {
      const results: Record<string, { latencies: number[]; avgMs: number; minMs: number; maxMs: number }> = {
        pipe: { latencies: [], avgMs: 0, minMs: Infinity, maxMs: 0 },
        fifo: { latencies: [], avgMs: 0, minMs: Infinity, maxMs: 0 },
        shm: { latencies: [], avgMs: 0, minMs: Infinity, maxMs: 0 }
      };

      for (const mech of ['pipe', 'fifo', 'shm']) {
        for (let i = 0; i < rounds; i++) {
          const { stdout } = await execFileAsync(RUNNER_PATH, [mech, `Benchmark payload #${i + 1}`, 'ACK'], { timeout: 3000 });
          const parsed = JSON.parse(stdout.trim());
          const lat = parsed.latencyMs || 0.5;
          results[mech].latencies.push(lat);
        }
        const lats = results[mech].latencies;
        results[mech].minMs = Math.min(...lats);
        results[mech].maxMs = Math.max(...lats);
        results[mech].avgMs = Number((lats.reduce((a, b) => a + b, 0) / lats.length).toFixed(3));
      }

      res.json({
        mode: 'native_linux',
        rounds,
        timestamp: new Date().toISOString(),
        measurements: results,
        simulatedReference: {
          pipe: { avgMs: 0.45, throughputGbps: 2.8, notes: 'Theoretical 64KB kernel buffer' },
          fifo: { avgMs: 0.65, throughputGbps: 2.6, notes: 'Theoretical VFS inode rendezvous' },
          shm: { avgMs: 0.12, throughputGbps: 24.5, notes: 'Theoretical zero-copy direct RAM' }
        }
      });
    } catch (err: any) {
      console.error('Benchmark failed:', err);
      res.status(500).json({ error: err.message || 'Benchmark run failed' });
    }
  });

  // In dev mode, mount Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    // In production, serve built files
    const distPath = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[IPC Connect] Server listening on http://0.0.0.0:${PORT} (Native binary ready: ${isNativeBinaryReady()})`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
});
