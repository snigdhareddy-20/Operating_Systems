/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Activity,
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Cpu,
  Database,
  Download,
  HardDrive,
  Info,
  Layers,
  Play,
  RotateCcw,
  Search,
  Send,
  Square,
  Terminal,
  Trash2,
  XCircle,
  CornerDownLeft,
  FileCode,
  Zap,
  BarChart2,
  BookOpen
} from 'lucide-react';
import { MechanismDiagram, IPCMechanism } from './components/MechanismDiagram';
import { IPCExperiments } from './components/experiments/IPCExperiments';
import { MeasuredComparisonDashboard } from './components/comparison/MeasuredComparisonDashboard';
import { AboutModal } from './components/about/AboutModal';

interface ChatMessage {
  id: string;
  sender: 'Process A' | 'Process B';
  receiver: 'Process A' | 'Process B';
  content: string;
  timestamp: string;
  timestampMs: number;
  mechanism: IPCMechanism;
  status: 'delivered' | 'failed';
  errorReason?: string;
  isNative?: boolean;
  senderPid?: number;
  receiverPid?: number;
  latencyMs?: number;
  systemCalls?: Array<{ syscall: string; description: string }>;
}

export default function App() {
  // Navigation View
  const [activeView, setActiveView] = useState<'chat' | 'experiments' | 'comparison' | 'history'>('chat');

  // Backend & Native Mode
  const [isNativeAvailable, setIsNativeAvailable] = useState<boolean>(false);
  const [useNativeIPC, setUseNativeIPC] = useState<boolean>(true);
  const [isAboutModalOpen, setIsAboutModalOpen] = useState<boolean>(false);

  // Mechanism selector
  const [mechanism, setMechanism] = useState<IPCMechanism>('pipe');

  // Process states
  const [procAState, setProcAState] = useState<'running' | 'stopped'>('running');
  const [procBState, setProcBState] = useState<'running' | 'stopped'>('running');

  // Chat and History
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  // Form Inputs
  const [inputA, setInputA] = useState('');
  const [inputB, setInputB] = useState('');
  const [errorA, setErrorA] = useState<string | null>(null);
  const [errorB, setErrorB] = useState<string | null>(null);

  // Recent Syscalls Trace
  const [recentSyscalls, setRecentSyscalls] = useState<Array<{ syscall: string; description: string }>>([]);
  const [realShmAddress, setRealShmAddress] = useState<string>('0x7f26480e1000');
  const [realFifoPath, setRealFifoPath] = useState<string>('/tmp/ipc_runner_a2b.fifo');

  // In-flight Packet Animation
  const [inFlightPacket, setInFlightPacket] = useState<{
    text: string;
    direction: 'a_to_b' | 'b_to_a';
    sender: string;
    receiver: string;
    stage: 'sending' | 'in_channel' | 'delivered' | 'failed';
    isNative?: boolean;
  } | null>(null);

  const chatEndRefA = useRef<HTMLDivElement>(null);
  const chatEndRefB = useRef<HTMLDivElement>(null);

  // Initial check of backend health & native compiler readiness
  useEffect(() => {
    fetch('/api/health')
      .then(res => res.json())
      .then(data => {
        if (data.nativeExecutionAvailable) {
          setIsNativeAvailable(true);
          setUseNativeIPC(true);
        } else {
          setIsNativeAvailable(false);
          setUseNativeIPC(false);
        }
      })
      .catch(() => {
        setIsNativeAvailable(false);
        setUseNativeIPC(false);
      });

    try {
      const saved = localStorage.getItem('ipc_connect_simple_messages_v2');
      if (saved) {
        setMessages(JSON.parse(saved));
      }
    } catch (e) {
      console.error(e);
    }
  }, []);

  // Save history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('ipc_connect_simple_messages_v2', JSON.stringify(messages));
    } catch (e) {
      console.error(e);
    }
  }, [messages]);

  // Auto scroll chat panels
  useEffect(() => {
    chatEndRefA.current?.scrollIntoView({ behavior: 'smooth' });
    chatEndRefB.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, inFlightPacket]);

  // Derived counters
  const totalSent = messages.filter(m => m.status === 'delivered').length;
  const sentByA = messages.filter(m => m.sender === 'Process A' && m.status === 'delivered').length;
  const sentByB = messages.filter(m => m.sender === 'Process B' && m.status === 'delivered').length;

  // Send message dispatcher (Native Linux C IPC + Simulation fallback)
  const handleSendMessage = async (sender: 'Process A' | 'Process B', text: string) => {
    const isA = sender === 'Process A';
    const receiver = isA ? 'Process B' : 'Process A';
    const senderState = isA ? procAState : procBState;
    const receiverState = isA ? procBState : procAState;

    if (isA) setErrorA(null);
    else setErrorB(null);

    // Validation 1: Sender is stopped
    if (senderState === 'stopped') {
      const msg = `Cannot send: ${sender} is currently stopped. Click "Start Process" to resume.`;
      if (isA) setErrorA(msg);
      else setErrorB(msg);
      return;
    }

    // Validation 2: Empty message
    if (!text.trim()) {
      const msg = 'Please enter a message before sending.';
      if (isA) setErrorA(msg);
      else setErrorB(msg);
      return;
    }

    const trimmedText = text.trim();
    if (isA) setInputA('');
    else setInputB('');

    // Trigger visual packet animation
    setInFlightPacket({
      text: trimmedText,
      direction: isA ? 'a_to_b' : 'b_to_a',
      sender,
      receiver,
      stage: 'sending',
      isNative: isNativeAvailable && useNativeIPC
    });

    // Step 1: Leave sender
    await new Promise(r => setTimeout(r, 350));
    setInFlightPacket(prev => prev ? { ...prev, stage: 'in_channel' } : null);

    // Check if receiver is stopped -> Simulated broken pipe / drop!
    const willFail = receiverState === 'stopped';

    if (willFail) {
      await new Promise(r => setTimeout(r, 450));
      setInFlightPacket(prev => prev ? { ...prev, stage: 'failed' } : null);
      await new Promise(r => setTimeout(r, 400));

      const failedMsg: ChatMessage = {
        id: `msg_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        sender,
        receiver,
        content: trimmedText,
        timestamp: new Date().toLocaleTimeString(),
        timestampMs: Date.now(),
        mechanism,
        status: 'failed',
        errorReason: `Delivery Failed: ${receiver} is stopped (SIGPIPE / No Reader on Channel)`
      };
      setMessages(prev => [...prev, failedMsg]);
      setInFlightPacket(null);
      return;
    }

    // If both running and Native IPC is enabled, call backend C binary!
    if (isNativeAvailable && useNativeIPC) {
      try {
        const res = await fetch('/api/ipc/send-native', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            mechanism,
            content: trimmedText,
            reply: `ACK from ${receiver}`
          })
        });

        const nativeData = await res.json();

        if (nativeData.success) {
          if (nativeData.systemCalls) setRecentSyscalls(nativeData.systemCalls);
          if (nativeData.shmAddress) setRealShmAddress(nativeData.shmAddress);
          if (nativeData.fifoPath) setRealFifoPath(nativeData.fifoPath);

          await new Promise(r => setTimeout(r, 200));
          setInFlightPacket(prev => prev ? { ...prev, stage: 'delivered' } : null);
          await new Promise(r => setTimeout(r, 300));

          const newMsg: ChatMessage = {
            id: `msg_nat_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
            sender,
            receiver,
            content: trimmedText,
            timestamp: new Date().toLocaleTimeString(),
            timestampMs: Date.now(),
            mechanism,
            status: 'delivered',
            isNative: true,
            senderPid: nativeData.senderPid,
            receiverPid: nativeData.receiverPid,
            latencyMs: nativeData.latencyMs,
            systemCalls: nativeData.systemCalls
          };

          setMessages(prev => [...prev, newMsg]);
          setInFlightPacket(null);
          return;
        }
      } catch (err) {
        console.warn('Native IPC call failed, falling back to simulated path:', err);
      }
    }

    // Fallback Simulation Path
    await new Promise(r => setTimeout(r, 400));
    setInFlightPacket(prev => prev ? { ...prev, stage: 'delivered' } : null);
    await new Promise(r => setTimeout(r, 300));

    const simulatedCalls = mechanism === 'pipe' ? [
      { syscall: 'pipe(fds)', description: 'Created anonymous kernel ring buffer (64KB)' },
      { syscall: 'write(fd[4])', description: 'Transferred payload into pipefs' },
      { syscall: 'read(fd[3])', description: 'Extracted packet in FIFO sequence' }
    ] : mechanism === 'fifo' ? [
      { syscall: 'open(O_WRONLY)', description: 'Connected to /tmp/ipc_chat.fifo' },
      { syscall: 'write(fd)', description: 'Passed bytes via filesystem inode rendezvous' },
      { syscall: 'read(fd)', description: 'Received in RAM buffer' }
    ] : [
      { syscall: 'mmap()', description: 'Mapped physical RAM block 0x7ffd98e21000' },
      { syscall: 'sem_wait(&mutex)', description: 'Acquired POSIX mutual exclusion lock' },
      { syscall: 'sem_post(&mutex)', description: 'Committed zero-copy update' }
    ];

    setRecentSyscalls(simulatedCalls);

    const newMsg: ChatMessage = {
      id: `msg_sim_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      sender,
      receiver,
      content: trimmedText,
      timestamp: new Date().toLocaleTimeString(),
      timestampMs: Date.now(),
      mechanism,
      status: 'delivered',
      isNative: false,
      latencyMs: mechanism === 'shm' ? 0.12 : mechanism === 'pipe' ? 0.45 : 0.65,
      systemCalls: simulatedCalls
    };

    setMessages(prev => [...prev, newMsg]);
    setInFlightPacket(null);
  };

  const handleClearChat = () => {
    setMessages([]);
    localStorage.removeItem('ipc_connect_simple_messages_v2');
  };

  const handleResetSimulation = () => {
    setProcAState('running');
    setProcBState('running');
    setMechanism('pipe');
    setInFlightPacket(null);
    setErrorA(null);
    setErrorB(null);
    setRecentSyscalls([]);
    handleClearChat();
  };

  // CSV Export
  const handleExportCSV = () => {
    if (messages.length === 0) return;
    const headers = ['ID', 'Timestamp', 'Sender', 'Receiver', 'Message', 'Mechanism', 'Execution Mode', 'Latency (ms)', 'Status', 'Error'];
    const rows = messages.map(m => [
      m.id,
      m.timestamp,
      m.sender,
      m.receiver,
      `"${m.content.replace(/"/g, '""')}"`,
      m.mechanism.toUpperCase(),
      m.isNative ? 'NATIVE_LINUX_C' : 'BROWSER_SIMULATION',
      m.latencyMs ? m.latencyMs.toFixed(3) : '0.450',
      m.status,
      m.errorReason ? `"${m.errorReason.replace(/"/g, '""')}"` : ''
    ]);
    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.setAttribute('download', `ipc_connect_logs_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Filtered History
  const filteredMessages = messages.filter(m =>
    m.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.sender.toLowerCase().includes(searchTerm.toLowerCase()) ||
    m.receiver.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col antialiased">
      
      {/* ================= 1. HEADER ================= */}
      <header className="border-b border-slate-800/80 bg-[#0a101d]/90 backdrop-blur-md sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
          
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-cyan-950/80 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold text-white tracking-tight">IPC Connect</h1>
                <span className="text-[11px] font-mono text-cyan-300 bg-cyan-950/70 border border-cyan-800/50 px-2 py-0.5 rounded">
                  OS Chat Simulator
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Inter-Process Communication Laboratory & C Benchmark Suite
              </p>
            </div>
          </div>

          {/* Mode Badge & Actions */}
          <div className="flex items-center gap-3">
            {/* Native vs Simulation Mode Indicator & Toggle */}
            <div className="flex items-center gap-2 text-xs font-mono px-3 py-1 bg-slate-900 border border-slate-800 rounded-lg">
              <span className={`w-2 h-2 rounded-full ${isNativeAvailable && useNativeIPC ? 'bg-emerald-400 animate-pulse' : 'bg-cyan-400'}`} />
              <span className={isNativeAvailable && useNativeIPC ? 'text-emerald-300 font-bold' : 'text-slate-300'}>
                {isNativeAvailable && useNativeIPC ? 'Native Linux C IPC Active' : 'Simulation Mode'}
              </span>
              {isNativeAvailable && (
                <button
                  onClick={() => setUseNativeIPC(!useNativeIPC)}
                  className="ml-2 text-[10px] text-slate-400 hover:text-white underline cursor-pointer"
                  title="Toggle between native compiled C execution and browser simulation"
                >
                  [{useNativeIPC ? 'Switch to Sim' : 'Switch to Native'}]
                </button>
              )}
            </div>

            <button
              onClick={() => setIsAboutModalOpen(true)}
              className="px-3 py-1.5 text-xs text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-md flex items-center gap-1.5 cursor-pointer transition-colors"
              title="Inspect Linux C Source Files & Compilation Instructions"
            >
              <FileCode className="w-3.5 h-3.5 text-cyan-400" />
              <span>C Code & Setup</span>
            </button>

            <button
              onClick={handleClearChat}
              className="px-3 py-1.5 text-xs text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-md flex items-center gap-1.5 cursor-pointer transition-colors"
              title="Clear all messages in chat"
            >
              <Trash2 className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline">Clear Chat</span>
            </button>

            <button
              onClick={handleResetSimulation}
              className="px-3 py-1.5 text-xs text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-md flex items-center gap-1.5 cursor-pointer transition-colors"
              title="Reset simulation to default state"
            >
              <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
              <span className="hidden sm:inline">Reset</span>
            </button>
          </div>

        </div>
      </header>

      {/* ================= 2. MAIN CONTENT ================= */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        
        {/* Short Explanation Banner */}
        <div className="p-4 rounded-xl border border-cyan-500/30 bg-gradient-to-r from-slate-900 via-[#0a1324] to-[#070e1c] flex items-start justify-between gap-4 shadow-md">
          <div className="flex items-start gap-3.5">
            <div className="p-2 rounded-lg bg-cyan-950/80 border border-cyan-500/40 text-cyan-400 shrink-0 mt-0.5">
              <Info className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">What is Inter-Process Communication (IPC)?</h2>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed max-w-3xl">
                Operating systems enforce strict virtual memory isolation between processes to prevent accidental corruption. 
                <strong> IPC</strong> provides mediated OS kernel bridges (like <em>Pipes</em>, <em>FIFOs</em>, and <em>Shared Memory</em>) enabling separate processes to coordinate safely.
              </p>
            </div>
          </div>

          {/* Native Verified Pill */}
          {isNativeAvailable && (
            <div className="hidden lg:flex flex-col items-end shrink-0 text-right">
              <span className="text-[11px] font-mono text-emerald-400 font-bold bg-emerald-950/80 border border-emerald-500/40 px-2.5 py-1 rounded-md flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Real Linux Binaries Ready</span>
              </span>
              <span className="text-[10px] text-slate-500 font-mono mt-1">pipe_chat · fifo_chat · shm_chat</span>
            </div>
          )}
        </div>

        {/* Live Status & Counters Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
          {/* Card 1: Process A */}
          <div className="bg-[#0b1222] border border-slate-800 rounded-xl p-3.5 flex items-center justify-between">
            <div>
              <div className="text-[11px] font-mono text-slate-400">PROCESS A (PID 1024)</div>
              <div className="text-sm font-bold mt-0.5 flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${procAState === 'running' ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                <span className={procAState === 'running' ? 'text-emerald-300' : 'text-rose-300'}>
                  {procAState === 'running' ? 'Running' : 'Stopped'}
                </span>
              </div>
            </div>
            <div className="text-right text-xs font-mono text-slate-400">
              <span className="text-cyan-400 font-bold">{sentByA}</span> sent
            </div>
          </div>

          {/* Card 2: Process B */}
          <div className="bg-[#0b1222] border border-slate-800 rounded-xl p-3.5 flex items-center justify-between">
            <div>
              <div className="text-[11px] font-mono text-slate-400">PROCESS B (PID 2048)</div>
              <div className="text-sm font-bold mt-0.5 flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${procBState === 'running' ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                <span className={procBState === 'running' ? 'text-emerald-300' : 'text-rose-300'}>
                  {procBState === 'running' ? 'Running' : 'Stopped'}
                </span>
              </div>
            </div>
            <div className="text-right text-xs font-mono text-slate-400">
              <span className="text-emerald-400 font-bold">{sentByB}</span> sent
            </div>
          </div>

          {/* Card 3: Total Transferred */}
          <div className="bg-[#0b1222] border border-slate-800 rounded-xl p-3.5 flex items-center justify-between">
            <div>
              <div className="text-[11px] font-mono text-slate-400">TOTAL DELIVERED</div>
              <div className="text-base font-bold text-white font-mono mt-0.5">
                {totalSent} <span className="text-xs text-slate-400 font-normal">packets</span>
              </div>
            </div>
            <Activity className="w-4 h-4 text-cyan-400" />
          </div>

          {/* Card 4: Active Channel */}
          <div className="bg-[#0b1222] border border-slate-800 rounded-xl p-3.5 flex items-center justify-between">
            <div>
              <div className="text-[11px] font-mono text-slate-400">ACTIVE IPC CHANNEL</div>
              <div className="text-xs font-bold text-cyan-300 capitalize font-mono mt-0.5">
                {mechanism === 'pipe' && 'Kernel Pipe (64KB)'}
                {mechanism === 'fifo' && 'Named Inode (/tmp/)'}
                {mechanism === 'shm' && 'Zero-Copy RAM (mmap)'}
              </div>
            </div>
            <Layers className="w-4 h-4 text-cyan-400" />
          </div>
        </div>

        {/* View Switcher Tabs: Chat | Experiments | Benchmark | History */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2">
          <button
            onClick={() => setActiveView('chat')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-bold cursor-pointer transition-colors flex items-center gap-1.5 ${
              activeView === 'chat'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Interactive Chat & Channels</span>
          </button>

          <button
            onClick={() => setActiveView('experiments')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-bold cursor-pointer transition-colors flex items-center gap-1.5 ${
              activeView === 'experiments'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span>OS Experiments Lab (4 Tests)</span>
          </button>

          <button
            onClick={() => setActiveView('comparison')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-bold cursor-pointer transition-colors flex items-center gap-1.5 ${
              activeView === 'comparison'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800'
            }`}
          >
            <BarChart2 className="w-3.5 h-3.5" />
            <span>Measured Benchmark Dashboard</span>
          </button>

          <button
            onClick={() => setActiveView('history')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-mono font-bold cursor-pointer transition-colors flex items-center gap-1.5 ${
              activeView === 'history'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 bg-slate-900 border border-slate-800'
            }`}
          >
            <span>Message Audit Logs ({messages.length})</span>
          </button>
        </div>

        {/* ================= VIEW 1: INTERACTIVE CHAT & DISTINCT CHANNELS ================= */}
        {activeView === 'chat' && (
          <div className="space-y-6">
            
            {/* IPC Mechanism Selector Card */}
            <div className="bg-[#0b1222] border border-slate-800 rounded-xl p-4 shadow-md space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
                <div>
                  <label htmlFor="mechanism-select" className="text-xs font-bold font-mono text-slate-300 uppercase tracking-wider block">
                    Select IPC Communication Mechanism:
                  </label>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Observe how each mechanism configures distinct operating system communication channels
                  </p>
                </div>

                {/* Dropdown Selector */}
                <div className="flex items-center gap-2">
                  <select
                    id="mechanism-select"
                    value={mechanism}
                    onChange={(e) => setMechanism(e.target.value as IPCMechanism)}
                    className="bg-slate-900 border border-slate-750 text-xs font-mono text-cyan-300 rounded-lg px-3 py-2 focus:outline-none focus:border-cyan-400 cursor-pointer font-bold"
                  >
                    <option value="pipe">1. Anonymous Pipes (pipe())</option>
                    <option value="fifo">2. Named Pipes (FIFO / mkfifo())</option>
                    <option value="shm">3. Shared Memory (mmap() + Mutex)</option>
                  </select>
                </div>
              </div>

              {/* Visually and Functionally Distinct Channel Diagram */}
              <MechanismDiagram
                mechanism={mechanism}
                isTransferring={!!inFlightPacket}
                shmAddress={realShmAddress}
                fifoPath={realFifoPath}
                recentSyscalls={recentSyscalls}
                isNative={isNativeAvailable && useNativeIPC}
              />
            </div>

            {/* Interactive Two-Process Chat Panels */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold font-mono text-slate-200 uppercase tracking-wider">
                  Two-Process Bidirectional Chat
                </h3>
                <span className="text-xs font-mono text-slate-400">
                  {isNativeAvailable && useNativeIPC ? (
                    <span className="text-emerald-400">● Invoking Linux C Binaries on Host</span>
                  ) : (
                    <span>● Client-Side Simulation</span>
                  )}
                </span>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 relative">
                
                {/* ====== PROCESS A PANEL ====== */}
                <div className="bg-[#0b1222] border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
                  <div>
                    {/* Header */}
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-3 h-3 rounded-full ${procAState === 'running' ? 'bg-emerald-400 ring-2 ring-emerald-500/20' : 'bg-rose-400'}`} />
                        <div>
                          <h4 className="text-sm font-bold text-white">Process A (Sender / Peer 1)</h4>
                          <div className="text-[11px] font-mono text-slate-400">
                            PID: 1024 · Status: <span className={procAState === 'running' ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>{procAState.toUpperCase()}</span>
                          </div>
                        </div>
                      </div>

                      {/* Start/Stop Button */}
                      {procAState === 'running' ? (
                        <button
                          onClick={() => setProcAState('stopped')}
                          className="px-2.5 py-1 text-xs text-rose-300 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/50 rounded-md flex items-center gap-1 cursor-pointer transition-colors"
                          title="Stop Process A"
                        >
                          <Square className="w-3 h-3 fill-rose-400 text-rose-400" />
                          <span>Stop Process</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => {
                            setProcAState('running');
                            setErrorA(null);
                          }}
                          className="px-2.5 py-1 text-xs text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-800/50 rounded-md flex items-center gap-1 cursor-pointer transition-colors"
                        >
                          <Play className="w-3 h-3 fill-emerald-400 text-emerald-400" />
                          <span>Start Process</span>
                        </button>
                      )}
                    </div>

                    {/* Stopped Notice */}
                    {procAState === 'stopped' && (
                      <div className="mt-3 p-2.5 rounded-lg bg-rose-950/40 border border-rose-800/50 text-xs text-rose-300 flex items-center gap-2">
                        <XCircle className="w-4 h-4 shrink-0 text-rose-400" />
                        <span>Process A is stopped. Click "Start Process" to resume communication.</span>
                      </div>
                    )}

                    {/* Chat Stream A */}
                    <div className="mt-3.5 mb-3">
                      <div className="text-[11px] font-mono text-slate-400 mb-1 flex justify-between">
                        <span>Message Feed (Process A View)</span>
                        <span>{messages.length} total</span>
                      </div>

                      <div className="h-56 overflow-y-auto bg-slate-950/70 border border-slate-850 rounded-lg p-3 space-y-2 text-xs font-mono">
                        {messages.length === 0 ? (
                          <div className="h-full flex items-center justify-center text-slate-500 italic">
                            No messages yet. Send a message to Process B below.
                          </div>
                        ) : (
                          messages.map((msg) => {
                            const isSent = msg.sender === 'Process A';
                            const isFail = msg.status === 'failed';

                            return (
                              <div
                                key={msg.id}
                                className={`p-2.5 rounded-lg border text-xs ${
                                  isFail
                                    ? 'bg-rose-950/30 border-rose-800/50 text-rose-200'
                                    : isSent
                                    ? 'bg-cyan-950/30 border-cyan-800/50 text-slate-200 ml-4'
                                    : 'bg-slate-900 border-slate-800 text-slate-200 mr-4'
                                }`}
                              >
                                <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                                  <span className={isSent ? 'text-cyan-400 font-semibold' : 'text-emerald-400 font-semibold'}>
                                    {isSent ? 'Sent to Process B' : 'Received from Process B'}
                                  </span>
                                  <span>{msg.timestamp} {msg.latencyMs ? `· ${msg.latencyMs}ms` : ''}</span>
                                </div>
                                <div className="text-slate-100 font-sans break-words">{msg.content}</div>
                                {msg.errorReason && (
                                  <div className="text-[10px] text-rose-400 font-mono mt-1">
                                    ⚠ {msg.errorReason}
                                  </div>
                                )}
                                {msg.isNative && (
                                  <div className="text-[9px] text-emerald-400/80 font-mono mt-1">
                                    ✓ Native Linux Execution (PIDs: {msg.senderPid || 'parent'} ➔ {msg.receiverPid || 'child'})
                                  </div>
                                )}
                              </div>
                            );
                          })
                        )}
                        <div ref={chatEndRefA} />
                      </div>
                    </div>

                    {/* Presets */}
                    <div className="mb-3">
                      <span className="text-[11px] text-slate-400 block mb-1">Quick Presets:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {[
                          'Hello Process B!',
                          'Request sensor packet 01',
                          'Sync clock timestamp',
                          'PING'
                        ].map((preset, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => setInputA(preset)}
                            className="text-[11px] px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 cursor-pointer transition-colors"
                          >
                            {preset}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Form Input A */}
                  <div>
                    {errorA && (
                      <div className="mb-2 text-xs text-rose-400 font-mono flex items-center gap-1">
                        <span>⚠ {errorA}</span>
                      </div>
                    )}
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        handleSendMessage('Process A', inputA);
                      }}
                      className="flex gap-2"
                    >
                      <input
                        type="text"
                        value={inputA}
                        onChange={(e) => {
                          setInputA(e.target.value);
                          if (errorA) setErrorA(null);
                        }}
                        disabled={procAState === 'stopped'}
                        placeholder={procAState === 'stopped' ? 'Process A is stopped' : 'Type message for Process B...'}
                        className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 disabled:opacity-50"
                      />
                      <button
                        type="submit"
                        disabled={procAState === 'stopped'}
                        className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Send</span>
                      </button>
                    </form>
                  </div>
                </div>

                {/* ====== PROCESS B PANEL ====== */}
                <div className="bg-[#0b1222] border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
                  <div>
                    {/* Header */}
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-3 h-3 rounded-full ${procBState === 'running' ? 'bg-emerald-400 ring-2 ring-emerald-500/20' : 'bg-rose-400'}`} />
                        <div>
                          <h4 className="text-sm font-bold text-white">Process B (Receiver / Peer 2)</h4>
                          <div className="text-[11px] font-mono text-slate-400">
                            PID: 2048 · Status: <span className={procBState === 'running' ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>{procBState.toUpperCase()}</span>
                          </div>
                        </div>
                      </div>

                      {/* Start/Stop Button */}
                      {procBState === 'running' ? (
                        <button
                          onClick={() => setProcBState('stopped')}
                          className="px-2.5 py-1 text-xs text-rose-300 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/50 rounded-md flex items-center gap-1 cursor-pointer transition-colors"
                          title="Stop Process B"
                        >
                          <Square className="w-3 h-3 fill-rose-400 text-rose-400" />
                          <span>Stop Process</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => {
                            setProcBState('running');
                            setErrorB(null);
                          }}
                          className="px-2.5 py-1 text-xs text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-800/50 rounded-md flex items-center gap-1 cursor-pointer transition-colors"
                        >
                          <Play className="w-3 h-3 fill-emerald-400 text-emerald-400" />
                          <span>Start Process</span>
                        </button>
                      )}
                    </div>

                    {/* Stopped Notice */}
                    {procBState === 'stopped' && (
                      <div className="mt-3 p-2.5 rounded-lg bg-rose-950/40 border border-rose-800/50 text-xs text-rose-300 flex items-center gap-2">
                        <XCircle className="w-4 h-4 shrink-0 text-rose-400" />
                        <span>Process B is stopped. Click "Start Process" to resume communication.</span>
                      </div>
                    )}

                    {/* Chat Stream B */}
                    <div className="mt-3.5 mb-3">
                      <div className="text-[11px] font-mono text-slate-400 mb-1 flex justify-between">
                        <span>Message Feed (Process B View)</span>
                        <span>{messages.length} total</span>
                      </div>

                      <div className="h-56 overflow-y-auto bg-slate-950/70 border border-slate-850 rounded-lg p-3 space-y-2 text-xs font-mono">
                        {messages.length === 0 ? (
                          <div className="h-full flex items-center justify-center text-slate-500 italic">
                            Waiting for incoming IPC packets from Process A...
                          </div>
                        ) : (
                          messages.map((msg) => {
                            const isSent = msg.sender === 'Process B';
                            const isFail = msg.status === 'failed';

                            return (
                              <div
                                key={msg.id}
                                className={`p-2.5 rounded-lg border text-xs ${
                                  isFail
                                    ? 'bg-rose-950/30 border-rose-800/50 text-rose-200'
                                    : isSent
                                    ? 'bg-emerald-950/30 border-emerald-800/50 text-slate-200 ml-4'
                                    : 'bg-slate-900 border-slate-800 text-slate-200 mr-4'
                                }`}
                              >
                                <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                                  <span className={isSent ? 'text-emerald-400 font-semibold' : 'text-cyan-400 font-semibold'}>
                                    {isSent ? 'Replied to Process A' : 'Received from Process A'}
                                  </span>
                                  <span>{msg.timestamp} {msg.latencyMs ? `· ${msg.latencyMs}ms` : ''}</span>
                                </div>
                                <div className="text-slate-100 font-sans break-words">{msg.content}</div>
                                {msg.errorReason && (
                                  <div className="text-[10px] text-rose-400 font-mono mt-1">
                                    ⚠ {msg.errorReason}
                                  </div>
                                )}
                                {msg.isNative && (
                                  <div className="text-[9px] text-emerald-400/80 font-mono mt-1">
                                    ✓ Native Linux Execution (PIDs: {msg.senderPid || 'parent'} ➔ {msg.receiverPid || 'child'})
                                  </div>
                                )}
                              </div>
                            );
                          })
                        )}
                        <div ref={chatEndRefB} />
                      </div>
                    </div>

                    {/* Presets */}
                    <div className="mb-3">
                      <span className="text-[11px] text-slate-400 block mb-1">Quick Presets:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {[
                          'Hello Process A!',
                          'ACK: Packet received OK',
                          'Sensor data: Temp 24°C',
                          'PONG'
                        ].map((preset, idx) => (
                          <button
                            key={idx}
                            type="button"
                            onClick={() => setInputB(preset)}
                            className="text-[11px] px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 cursor-pointer transition-colors"
                          >
                            {preset}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Form Input B */}
                  <div>
                    {errorB && (
                      <div className="mb-2 text-xs text-rose-400 font-mono flex items-center gap-1">
                        <span>⚠ {errorB}</span>
                      </div>
                    )}
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        handleSendMessage('Process B', inputB);
                      }}
                      className="flex gap-2"
                    >
                      <input
                        type="text"
                        value={inputB}
                        onChange={(e) => {
                          setInputB(e.target.value);
                          if (errorB) setErrorB(null);
                        }}
                        disabled={procBState === 'stopped'}
                        placeholder={procBState === 'stopped' ? 'Process B is stopped' : 'Type reply for Process A...'}
                        className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 disabled:opacity-50"
                      />
                      <button
                        type="submit"
                        disabled={procBState === 'stopped'}
                        className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      >
                        <CornerDownLeft className="w-3.5 h-3.5" />
                        <span>Reply</span>
                      </button>
                    </form>
                  </div>
                </div>

              </div>

              {/* In-Flight Message Packet Animation Banner */}
              {inFlightPacket && (
                <div className="p-3.5 rounded-xl border border-cyan-500/60 bg-cyan-950/40 text-xs font-mono shadow-[0_0_20px_rgba(6,182,212,0.2)] flex items-center justify-between transition-all animate-in fade-in">
                  <div className="flex items-center gap-2.5">
                    {inFlightPacket.direction === 'a_to_b' ? (
                      <ArrowRight className="w-4 h-4 text-cyan-400 animate-pulse" />
                    ) : (
                      <ArrowLeft className="w-4 h-4 text-emerald-400 animate-pulse" />
                    )}
                    <div>
                      <span className="text-slate-400 font-normal">Active In-Flight Packet: </span>
                      <span className="font-bold text-white">"{inFlightPacket.text}"</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-cyan-300">
                      {inFlightPacket.sender} ➔ {inFlightPacket.receiver}
                    </span>
                    <span className="text-slate-600">·</span>
                    <span className={`text-[11px] font-bold uppercase ${
                      inFlightPacket.stage === 'failed' ? 'text-rose-400' : 'text-emerald-400'
                    }`}>
                      {inFlightPacket.stage === 'sending' && 'Writing to Channel...'}
                      {inFlightPacket.stage === 'in_channel' && 'Inside IPC Channel...'}
                      {inFlightPacket.stage === 'delivered' && 'Delivered OK!'}
                      {inFlightPacket.stage === 'failed' && 'Delivery Dropped!'}
                    </span>
                  </div>
                </div>
              )}
            </div>

          </div>
        )}

        {/* ================= VIEW 2: OS EXPERIMENTS LAB ================= */}
        {activeView === 'experiments' && (
          <IPCExperiments isNativeAvailable={isNativeAvailable && useNativeIPC} />
        )}

        {/* ================= VIEW 3: MEASURED COMPARISON DASHBOARD ================= */}
        {activeView === 'comparison' && (
          <MeasuredComparisonDashboard isNativeAvailable={isNativeAvailable && useNativeIPC} />
        )}

        {/* ================= VIEW 4: MESSAGE HISTORY TABLE ================= */}
        {activeView === 'history' && (
          <div className="bg-[#0b1222] border border-slate-800 rounded-xl overflow-hidden shadow-lg space-y-4 p-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-sm font-bold font-mono text-slate-200 uppercase tracking-wider">
                  Message History Audit Table
                </h3>
                <p className="text-xs text-slate-400">
                  Searchable record of all transmitted packets, latency measurements, and system calls
                </p>
              </div>

              <div className="flex items-center gap-2.5">
                <button
                  onClick={handleExportCSV}
                  disabled={messages.length === 0}
                  className="px-3 py-1.5 text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-slate-950 rounded-lg flex items-center gap-1.5 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                  title="Download CSV"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export CSV</span>
                </button>

                <button
                  onClick={handleClearChat}
                  disabled={messages.length === 0}
                  className="px-3 py-1.5 text-xs text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg flex items-center gap-1.5 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5 text-slate-400" />
                  <span>Clear History</span>
                </button>
              </div>
            </div>

            {/* Search bar */}
            <div className="relative max-w-sm">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search messages by content or sender..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500"
              />
            </div>

            {/* Table */}
            <div className="overflow-x-auto rounded-lg border border-slate-850">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-900/90 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-2.5 px-3">Timestamp</th>
                    <th className="py-2.5 px-3">Sender</th>
                    <th className="py-2.5 px-3">Receiver</th>
                    <th className="py-2.5 px-3">Message Content</th>
                    <th className="py-2.5 px-3">Mechanism</th>
                    <th className="py-2.5 px-3">Mode</th>
                    <th className="py-2.5 px-3">Latency</th>
                    <th className="py-2.5 px-3 text-right">Delivery Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-855 text-slate-300">
                  {filteredMessages.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-500 italic">
                        No message history recorded yet. Send a message to populate audit logs.
                      </td>
                    </tr>
                  ) : (
                    filteredMessages.map((msg) => (
                      <tr key={msg.id} className="hover:bg-slate-800/30 transition-colors">
                        <td className="py-2.5 px-3 text-slate-400">{msg.timestamp}</td>
                        <td className="py-2.5 px-3">
                          <span className={msg.sender === 'Process A' ? 'text-cyan-400 font-bold' : 'text-emerald-400 font-bold'}>
                            {msg.sender}
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          <span className={msg.receiver === 'Process A' ? 'text-cyan-400 font-bold' : 'text-emerald-400 font-bold'}>
                            {msg.receiver}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-sans text-slate-100 max-w-xs truncate" title={msg.content}>
                          {msg.content}
                          {msg.errorReason && (
                            <div className="text-[10px] text-rose-400 font-mono mt-0.5">
                              {msg.errorReason}
                            </div>
                          )}
                        </td>
                        <td className="py-2.5 px-3 uppercase text-cyan-300 text-[11px]">
                          {msg.mechanism}
                        </td>
                        <td className="py-2.5 px-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            msg.isNative ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/60' : 'bg-slate-900 text-slate-400'
                          }`}>
                            {msg.isNative ? 'NATIVE C' : 'SIMULATION'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-slate-300">
                          {msg.latencyMs ? `${msg.latencyMs.toFixed(3)} ms` : '0.450 ms'}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          {msg.status === 'delivered' ? (
                            <span className="inline-flex items-center gap-1 text-emerald-400 text-[11px] font-semibold">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>DELIVERED</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-rose-400 text-[11px] font-semibold">
                              <XCircle className="w-3.5 h-3.5" />
                              <span>FAILED</span>
                            </span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
            <div className="text-[11px] text-slate-500 font-mono">
              Showing {filteredMessages.length} of {messages.length} total messages
            </div>
          </div>
        )}

      </main>

      {/* ================= 3. FOOTER ================= */}
      <footer className="border-t border-slate-800/80 bg-[#070b14] py-4 px-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>IPC Connect — Operating Systems Hackathon Project</span>
          <div className="flex items-center gap-3 text-slate-400">
            <span>Mode: {isNativeAvailable && useNativeIPC ? 'Native Linux Kernel (Verified)' : 'Simulation Fallback'}</span>
            <span>·</span>
            <button
              onClick={() => setIsAboutModalOpen(true)}
              className="text-cyan-400 hover:underline cursor-pointer"
            >
              Linux Setup & C Source Files
            </button>
          </div>
        </div>
      </footer>

      {/* About & C Code Inspector Modal */}
      <AboutModal
        isOpen={isAboutModalOpen}
        onClose={() => setIsAboutModalOpen(false)}
      />

    </div>
  );
}
