import React from 'react';
import { Database, HardDrive, Cpu, ArrowRight, Lock, Unlock, FileText, CheckCircle2, ShieldAlert } from 'lucide-react';

export type IPCMechanism = 'pipe' | 'fifo' | 'shm';

interface MechanismDiagramProps {
  mechanism: IPCMechanism;
  isTransferring?: boolean;
  shmAddress?: string;
  fifoPath?: string;
  recentSyscalls?: Array<{ syscall: string; description: string }>;
  isNative?: boolean;
}

export const MechanismDiagram: React.FC<MechanismDiagramProps> = ({
  mechanism,
  isTransferring,
  shmAddress = '0x7ffd98e21000',
  fifoPath = '/tmp/ipc_runner_a2b.fifo',
  recentSyscalls,
  isNative
}) => {
  return (
    <div className="bg-[#0b1222] border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-800/80">
        <div>
          <div className="flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${isNative ? 'bg-emerald-400' : 'bg-cyan-400'}`} />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              {mechanism === 'pipe' && 'Anonymous Pipe: Kernel Communication Channel'}
              {mechanism === 'fifo' && 'Named Pipe: Filesystem Channel Inode'}
              {mechanism === 'shm' && 'Shared Memory: Zero-Copy Physical RAM Buffer'}
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            {mechanism === 'pipe' && 'Unidirectional byte-stream buffer managed in pipefs with 64KB kernel limit'}
            {mechanism === 'fifo' && 'Special FIFO node in /tmp/ allowing unrelated processes to rendezvous in RAM'}
            {mechanism === 'shm' && 'Direct virtual memory mapping avoiding kernel copies, guarded by semaphores'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isNative ? (
            <span className="text-[11px] font-mono text-emerald-300 bg-emerald-950/60 border border-emerald-800/50 px-2.5 py-1 rounded flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              <span>Native Linux Kernel Backed</span>
            </span>
          ) : (
            <span className="text-[11px] font-mono text-cyan-300 bg-cyan-950/60 border border-cyan-800/50 px-2.5 py-1 rounded">
              Simulation Sandbox
            </span>
          )}
        </div>
      </div>

      {/* Visual Diagram Channel Box */}
      <div className="p-5 rounded-lg bg-slate-950/70 border border-slate-850">
        
        {/* ================= 1. PIPES DIAGRAM ================= */}
        {mechanism === 'pipe' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3 items-center text-center">
              {/* Process A Node */}
              <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono">
                <div className="font-bold text-cyan-400 mb-0.5">Process A (Parent)</div>
                <div className="text-[11px] text-slate-400">User Space (Ring 3)</div>
                <div className="text-[10px] text-cyan-400 font-bold mt-1 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                  write(fd[4], payload)
                </div>
              </div>

              {/* Ingress Arrow */}
              <div className="hidden md:flex flex-col items-center justify-center text-slate-500">
                <ArrowRight className={`w-5 h-5 ${isTransferring ? 'text-cyan-400 animate-pulse' : ''}`} />
                <span className="text-[10px] font-mono text-slate-400">User ➔ Kernel</span>
              </div>

              {/* Kernel Pipe Channel */}
              <div className="p-4 rounded-xl bg-cyan-950/40 border border-cyan-500/50 text-xs text-center shadow-[0_0_15px_rgba(6,182,212,0.15)]">
                <div className="flex items-center justify-center gap-1.5 text-cyan-300 font-bold font-mono mb-1">
                  <Database className="w-4 h-4 text-cyan-400" />
                  <span>Kernel Pipe Channel</span>
                </div>
                <div className="text-[11px] text-slate-300">pipefs In-Memory Ring Buffer</div>
                
                {/* Visual 64KB Buffer Slots */}
                <div className="mt-2.5 bg-slate-950 p-2 rounded border border-slate-800 space-y-1">
                  <div className="flex justify-between text-[10px] font-mono text-slate-400">
                    <span>Ring Capacity: 65,536 B</span>
                    <span className="text-cyan-400">FIFO Order</span>
                  </div>
                  <div className="grid grid-cols-6 gap-1 h-3">
                    <div className="bg-cyan-500 rounded-sm animate-pulse" title="Slot 0: Active" />
                    <div className="bg-cyan-600 rounded-sm" title="Slot 1: Buffered" />
                    <div className="bg-cyan-900 rounded-sm" title="Slot 2: Free" />
                    <div className="bg-slate-800 rounded-sm" title="Slot 3: Free" />
                    <div className="bg-slate-800 rounded-sm" title="Slot 4: Free" />
                    <div className="bg-slate-800 rounded-sm" title="Slot 5: Free" />
                  </div>
                </div>
                <div className="text-[10px] text-slate-400 font-mono mt-1">Blocks writer when full (64KB)</div>
              </div>

              {/* Egress Arrow */}
              <div className="hidden md:flex flex-col items-center justify-center text-slate-500">
                <ArrowRight className={`w-5 h-5 ${isTransferring ? 'text-cyan-400 animate-pulse' : ''}`} />
                <span className="text-[10px] font-mono text-slate-400">Kernel ➔ User</span>
              </div>

              {/* Process B Node */}
              <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono">
                <div className="font-bold text-emerald-400 mb-0.5">Process B (Child)</div>
                <div className="text-[11px] text-slate-400">User Space (Ring 3)</div>
                <div className="text-[10px] text-emerald-400 font-bold mt-1 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                  read(fd[3], buf)
                </div>
              </div>
            </div>

            <div className="p-2.5 rounded bg-slate-900/60 border border-slate-800 text-xs text-slate-300 flex items-center justify-between">
              <div>
                <span className="font-bold text-cyan-300">Failure Mode: </span>
                <span>Writing to pipe with reader closed triggers <code className="text-rose-400 font-mono">SIGPIPE (Signal 13)</code> and returns <code className="text-rose-400 font-mono">EPIPE</code>.</span>
              </div>
              <span className="text-[10px] font-mono text-slate-400 hidden sm:inline">OS Syscall: pipe(fds)</span>
            </div>
          </div>
        )}

        {/* ================= 2. NAMED PIPES (FIFO) DIAGRAM ================= */}
        {mechanism === 'fifo' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3 items-center text-center">
              {/* Process A Node */}
              <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono">
                <div className="font-bold text-cyan-400 mb-0.5">Process A (Writer)</div>
                <div className="text-[11px] text-slate-400">Independent PID</div>
                <div className="text-[10px] text-amber-400 font-bold mt-1 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                  open(path, O_WRONLY)
                </div>
              </div>

              {/* Ingress Arrow */}
              <div className="hidden md:flex flex-col items-center justify-center text-slate-500">
                <ArrowRight className={`w-5 h-5 ${isTransferring ? 'text-amber-400 animate-pulse' : ''}`} />
                <span className="text-[10px] font-mono text-slate-400">Rendezvous</span>
              </div>

              {/* Named FIFO Filesystem Channel */}
              <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-500/50 text-xs text-center shadow-[0_0_15px_rgba(245,158,11,0.15)]">
                <div className="flex items-center justify-center gap-1.5 text-amber-300 font-bold font-mono mb-1">
                  <HardDrive className="w-4 h-4 text-amber-400" />
                  <span>Named FIFO Channel</span>
                </div>
                <div className="text-[11px] text-slate-200 font-mono font-semibold truncate px-1">
                  {fifoPath}
                </div>

                {/* VFS Inode Card */}
                <div className="mt-2.5 bg-slate-950 p-2 rounded border border-slate-800 text-[10px] font-mono text-left space-y-0.5">
                  <div className="text-amber-400">File Type: <span className="text-white">p (FIFO Special Node)</span></div>
                  <div className="text-slate-400">Mode: <span className="text-slate-200">prw-rw-rw-</span> · Zero Disk I/O</div>
                  <div className="text-emerald-400">Rendezvous: <span className="text-white">Both ends attached</span></div>
                </div>
              </div>

              {/* Egress Arrow */}
              <div className="hidden md:flex flex-col items-center justify-center text-slate-500">
                <ArrowRight className={`w-5 h-5 ${isTransferring ? 'text-amber-400 animate-pulse' : ''}`} />
                <span className="text-[10px] font-mono text-slate-400">RAM Stream</span>
              </div>

              {/* Process B Node */}
              <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono">
                <div className="font-bold text-emerald-400 mb-0.5">Process B (Reader)</div>
                <div className="text-[11px] text-slate-400">Independent PID</div>
                <div className="text-[10px] text-emerald-400 font-bold mt-1 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                  open(path, O_RDONLY)
                </div>
              </div>
            </div>

            <div className="p-2.5 rounded bg-slate-900/60 border border-slate-800 text-xs text-slate-300 flex items-center justify-between">
              <div>
                <span className="font-bold text-amber-300">Rendezvous Rule: </span>
                <span>Opening for write blocks until reader connects (unless <code className="text-cyan-300 font-mono">O_NONBLOCK</code> is specified, which returns <code className="text-rose-400 font-mono">ENXIO</code>).</span>
              </div>
              <span className="text-[10px] font-mono text-slate-400 hidden sm:inline">OS Syscall: mkfifo()</span>
            </div>
          </div>
        )}

        {/* ================= 3. SHARED MEMORY DIAGRAM ================= */}
        {mechanism === 'shm' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3 items-center text-center">
              {/* Process A Node */}
              <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono">
                <div className="font-bold text-cyan-400 mb-0.5">Process A (Addr Space)</div>
                <div className="text-[11px] text-slate-300">Virtual: {shmAddress}</div>
                <div className="text-[10px] text-emerald-400 font-bold mt-1 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                  sem_wait(&mutex)
                </div>
              </div>

              {/* Zero-Copy Direct Access */}
              <div className="hidden md:flex flex-col items-center justify-center text-slate-500">
                <ArrowRight className={`w-5 h-5 ${isTransferring ? 'text-emerald-400 animate-pulse' : ''}`} />
                <span className="text-[10px] font-mono text-emerald-400 font-bold">Zero-Copy</span>
              </div>

              {/* Shared Memory Buffer Card */}
              <div className="p-4 rounded-xl bg-emerald-950/40 border border-emerald-500/50 text-xs text-center shadow-[0_0_15px_rgba(16,185,129,0.15)]">
                <div className="flex items-center justify-center gap-1.5 text-emerald-300 font-bold font-mono mb-1">
                  <Cpu className="w-4 h-4 text-emerald-400" />
                  <span>Shared Memory Buffer</span>
                </div>
                <div className="text-[11px] text-slate-200">Common Physical RAM Page</div>

                {/* Shared Memory Struct Layout */}
                <div className="mt-2.5 bg-slate-950 p-2 rounded border border-slate-800 text-[10px] font-mono text-left space-y-1">
                  <div className="flex items-center justify-between text-emerald-400">
                    <span className="flex items-center gap-1"><Lock className="w-3 h-3" /> sem_t mutex:</span>
                    <span className="bg-emerald-950 px-1 rounded text-white border border-emerald-700">1 (Unlocked)</span>
                  </div>
                  <div className="flex items-center justify-between text-cyan-300">
                    <span>sem_t data_ready:</span>
                    <span className="text-white">0</span>
                  </div>
                  <div className="text-slate-400 truncate">
                    payload[512]: <span className="text-slate-200">"Direct RAM segment"</span>
                  </div>
                </div>
              </div>

              {/* Zero-Copy Direct Access */}
              <div className="hidden md:flex flex-col items-center justify-center text-slate-500">
                <ArrowRight className={`w-5 h-5 ${isTransferring ? 'text-emerald-400 animate-pulse' : ''}`} />
                <span className="text-[10px] font-mono text-emerald-400 font-bold">Zero-Copy</span>
              </div>

              {/* Process B Node */}
              <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono">
                <div className="font-bold text-emerald-400 mb-0.5">Process B (Addr Space)</div>
                <div className="text-[11px] text-slate-300">Virtual: {shmAddress}</div>
                <div className="text-[10px] text-emerald-400 font-bold mt-1 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">
                  sem_post(&mutex)
                </div>
              </div>
            </div>

            <div className="p-2.5 rounded bg-slate-900/60 border border-slate-800 text-xs text-slate-300 flex items-center justify-between">
              <div>
                <span className="font-bold text-emerald-300">Performance Advantage: </span>
                <span>Zero kernel copies (data is never copied into kernel space). POSIX semaphores synchronize concurrent access.</span>
              </div>
              <span className="text-[10px] font-mono text-slate-400 hidden sm:inline">OS Syscall: shm_open() + mmap()</span>
            </div>
          </div>
        )}

      </div>

      {/* Relevant System Calls Log */}
      {recentSyscalls && recentSyscalls.length > 0 && (
        <div className="bg-slate-950/80 p-3 rounded-lg border border-slate-850">
          <div className="text-[11px] font-mono text-slate-400 mb-2 flex items-center justify-between">
            <span className="flex items-center gap-1.5 text-cyan-300 font-semibold">
              <FileText className="w-3.5 h-3.5" />
              <span>Real Linux Kernel System Calls Executed in Transaction:</span>
            </span>
            <span className="text-[10px] text-slate-500">Monitored in Ring 0</span>
          </div>
          <div className="space-y-1 font-mono text-xs">
            {recentSyscalls.map((call, idx) => (
              <div key={idx} className="flex items-start gap-2 text-[11px]">
                <span className="text-cyan-400 font-bold shrink-0">{call.syscall}</span>
                <span className="text-slate-600">➔</span>
                <span className="text-slate-300">{call.description}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
