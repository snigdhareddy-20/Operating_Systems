import React, { useState } from 'react';
import { C_CODE_EXAMPLES } from '../../data/learningContent';
import { MAKEFILE_CONTENT, downloadCFile } from '../../services/ipcSimulation';
import { X, Copy, Check, Download, Terminal, Cpu, ShieldCheck, FileCode } from 'lucide-react';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AboutModal: React.FC<AboutModalProps> = ({ isOpen, onClose }) => {
  const [activeCodeTab, setActiveCodeTab] = useState<'pipe' | 'fifo' | 'shm' | 'makefile'>('pipe');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentContent = activeCodeTab === 'makefile' ? MAKEFILE_CONTENT : C_CODE_EXAMPLES[activeCodeTab];
  const currentFilename = activeCodeTab === 'makefile' ? 'Makefile' : `${activeCodeTab}_chat.c`;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    downloadCFile(currentFilename, currentContent);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#0b1120] border border-slate-800 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-cyan-950/80 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <FileCode className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">Native Linux C IPC Implementation</h2>
              <p className="text-xs text-slate-400">Complete, standard-compliant C source code and compilation guides</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          
          {/* Architecture & Problem Statement */}
          <div className="p-4 rounded-xl border border-cyan-500/20 bg-cyan-950/10 space-y-2 text-xs text-slate-300">
            <div className="font-semibold text-cyan-300 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              <span>Hackathon Solution: Inter-Process Chat Using Linux IPC</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              This project demonstrates true inter-process chat architectures. In this web environment, operations run in <strong>Simulation Mode</strong> to provide instant interactive feedback without exposing your host system. 
              The C programs below are 100% production-ready Linux system code using genuine <code className="text-cyan-300">pipe()</code>, <code className="text-cyan-300">mkfifo()</code>, and <code className="text-cyan-300">shm_open()</code> system calls with POSIX semaphores.
            </p>
          </div>

          {/* Code Viewer Tabs & Actions */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden">
            <div className="p-3 bg-slate-900 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
              
              {/* Tab Selector */}
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setActiveCodeTab('pipe')}
                  className={`px-3 py-1 text-xs font-mono rounded cursor-pointer transition-colors ${
                    activeCodeTab === 'pipe' ? 'bg-cyan-950 text-cyan-300 font-bold border border-cyan-800/60' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  pipe_chat.c
                </button>
                <button
                  onClick={() => setActiveCodeTab('fifo')}
                  className={`px-3 py-1 text-xs font-mono rounded cursor-pointer transition-colors ${
                    activeCodeTab === 'fifo' ? 'bg-amber-950 text-amber-300 font-bold border border-amber-800/60' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  fifo_chat_a.c
                </button>
                <button
                  onClick={() => setActiveCodeTab('shm')}
                  className={`px-3 py-1 text-xs font-mono rounded cursor-pointer transition-colors ${
                    activeCodeTab === 'shm' ? 'bg-emerald-950 text-emerald-300 font-bold border border-emerald-800/60' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  shm_chat.c
                </button>
                <button
                  onClick={() => setActiveCodeTab('makefile')}
                  className={`px-3 py-1 text-xs font-mono rounded cursor-pointer transition-colors ${
                    activeCodeTab === 'makefile' ? 'bg-slate-800 text-slate-200 font-bold border border-slate-700' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Makefile
                </button>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopy}
                  className="px-2.5 py-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 rounded flex items-center gap-1 cursor-pointer transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-slate-400" />}
                  <span>{copied ? 'Copied' : 'Copy Code'}</span>
                </button>

                <button
                  onClick={handleDownload}
                  className="px-2.5 py-1 text-xs bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-bold rounded flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download File</span>
                </button>
              </div>
            </div>

            {/* Code Content */}
            <pre className="p-4 text-xs font-mono text-slate-200 overflow-x-auto max-h-72 leading-relaxed selection:bg-cyan-500/30">
              <code>{currentContent}</code>
            </pre>
          </div>

          {/* Compilation Guide */}
          <div className="bg-[#0e1526] border border-slate-800 rounded-xl p-5 space-y-3">
            <h3 className="text-xs font-bold font-mono text-slate-200 flex items-center gap-1.5 uppercase">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span>Native Linux Execution Instructions</span>
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              To execute these programs on any native Linux distribution (Ubuntu, Debian, Fedora, Arch, Alpine) or WSL:
            </p>
            <div className="bg-slate-950 p-3 rounded-lg border border-slate-850 font-mono text-xs text-cyan-300 space-y-1">
              <div><span className="text-slate-500"># 1. Save files and compile with GCC:</span></div>
              <div>gcc -Wall -O2 pipe_chat.c -o pipe_chat</div>
              <div>gcc -Wall -O2 shm_chat.c -o shm_chat -lrt -pthread</div>
              <div className="pt-2"><span className="text-slate-500"># 2. Execute binary:</span></div>
              <div>./pipe_chat</div>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-900/60 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>IPC Connect Lab · Built for Operating Systems Students & Hackathons</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg cursor-pointer"
          >
            Close Inspector
          </button>
        </div>

      </div>
    </div>
  );
};
