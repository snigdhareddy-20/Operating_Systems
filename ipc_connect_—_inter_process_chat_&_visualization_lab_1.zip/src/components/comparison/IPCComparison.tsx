import React, { useState } from 'react';
import { COMPARISON_DATA } from '../../data/learningContent';
import { Check, HelpCircle, Sparkles, Database, HardDrive, Cpu, ArrowRight } from 'lucide-react';

interface IPCComparisonProps {
  onSelectMechanism: (m: 'pipe' | 'fifo' | 'shm') => void;
}

export const IPCComparison: React.FC<IPCComparisonProps> = ({ onSelectMechanism }) => {
  // Interactive Decision Advisor State
  const [q1, setQ1] = useState<'related' | 'unrelated' | null>(null);
  const [q2, setQ2] = useState<'throughput' | 'simplicity' | null>(null);
  const [q3, setQ3] = useState<'bidirectional' | 'unidirectional' | null>(null);

  // Compute recommendation
  const getRecommendation = () => {
    if (!q1 || !q2) return null;

    if (q2 === 'throughput') {
      return {
        mechanism: 'shm' as const,
        title: 'POSIX Shared Memory (mmap)',
        reason: 'Zero-copy direct memory access delivers maximum throughput (20–50+ GB/s) for high-frequency or large-payload inter-process streaming.',
        syscalls: 'shm_open(), ftruncate(), mmap(), sem_init(), sem_wait()'
      };
    }

    if (q1 === 'unrelated') {
      return {
        mechanism: 'fifo' as const,
        title: 'Named Pipe (FIFO)',
        reason: 'Independent processes running in separate terminals or daemons can rendezvous through a filesystem path (/tmp/...) with zero parent-child requirements.',
        syscalls: 'mkfifo(), open(), read(), write(), close()'
      };
    }

    return {
      mechanism: 'pipe' as const,
      title: 'Anonymous Pipes (pipe)',
      reason: 'Standard Unix pipeline between related parent/child processes. Simple, robust, automatic kernel blocking, and zero cleanup overhead upon termination.',
      syscalls: 'pipe(), fork(), read(), write(), close()'
    };
  };

  const recommendation = getRecommendation();

  return (
    <div className="space-y-6">
      
      {/* Intro Header */}
      <div className="bg-[#0e1526] border border-slate-800 rounded-xl p-5 shadow-lg">
        <h2 className="text-lg font-bold text-slate-100">IPC Mechanism Architectural Comparison</h2>
        <p className="text-xs text-slate-400 mt-1 max-w-3xl leading-relaxed">
          Operating system processes choose IPC primitives based on process genealogy (related vs independent), transfer volume, synchronization complexity, and persistence requirements.
        </p>
      </div>

      {/* Interactive Mechanism Advisor Wizard */}
      <div className="bg-gradient-to-r from-slate-900 via-[#0e172a] to-[#0d1527] border border-cyan-500/30 rounded-xl p-6 shadow-xl">
        <div className="flex items-center gap-2 mb-2 text-xs font-mono text-cyan-400">
          <Sparkles className="w-4 h-4" />
          <span>INTERACTIVE ARCHITECTURE ADVISOR</span>
        </div>
        <h3 className="text-base font-bold text-white mb-2">Which IPC Mechanism Should You Choose?</h3>
        <p className="text-xs text-slate-300 mb-5">Answer these questions to determine the optimal mechanism for your Linux application:</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">
          {/* Question 1 */}
          <div className="p-4 rounded-lg bg-slate-950/70 border border-slate-800 space-y-2">
            <div className="text-xs font-semibold text-slate-200">1. Are your processes related by fork()?</div>
            <div className="flex gap-2">
              <button
                onClick={() => setQ1('related')}
                className={`flex-1 py-1.5 px-3 rounded text-xs transition-colors cursor-pointer ${
                  q1 === 'related' ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                Yes (Parent-Child)
              </button>
              <button
                onClick={() => setQ1('unrelated')}
                className={`flex-1 py-1.5 px-3 rounded text-xs transition-colors cursor-pointer ${
                  q1 === 'unrelated' ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                No (Independent)
              </button>
            </div>
          </div>

          {/* Question 2 */}
          <div className="p-4 rounded-lg bg-slate-950/70 border border-slate-800 space-y-2">
            <div className="text-xs font-semibold text-slate-200">2. What is your primary design priority?</div>
            <div className="flex gap-2">
              <button
                onClick={() => setQ2('simplicity')}
                className={`flex-1 py-1.5 px-3 rounded text-xs transition-colors cursor-pointer ${
                  q2 === 'simplicity' ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                Simplicity & Safety
              </button>
              <button
                onClick={() => setQ2('throughput')}
                className={`flex-1 py-1.5 px-3 rounded text-xs transition-colors cursor-pointer ${
                  q2 === 'throughput' ? 'bg-cyan-500 text-slate-950 font-bold' : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                Max Zero-Copy Speed
              </button>
            </div>
          </div>
        </div>

        {/* Advisor Recommendation Result */}
        {recommendation ? (
          <div className="p-4 rounded-lg bg-cyan-950/40 border border-cyan-500/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="text-xs font-mono text-cyan-400 font-semibold mb-1">RECOMMENDED IPC MECHANISM:</div>
              <div className="text-base font-bold text-white">{recommendation.title}</div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl">{recommendation.reason}</p>
              <div className="text-[11px] font-mono text-slate-400 mt-1">Syscalls: {recommendation.syscalls}</div>
            </div>
            <button
              onClick={() => onSelectMechanism(recommendation.mechanism)}
              className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1.5 whitespace-nowrap cursor-pointer transition-colors"
            >
              <span>Test in Lab</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <div className="text-xs text-slate-500 italic text-center py-2">
            Select your architecture choices above to view the optimal mechanism recommendation.
          </div>
        )}
      </div>

      {/* Comprehensive Comparison Matrix Table */}
      <div className="bg-[#0e1526] border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div className="p-5 border-b border-slate-800">
          <h3 className="text-sm font-semibold text-slate-200">System Architecture Comparison Matrix</h3>
          <p className="text-xs text-slate-400">Detailed breakdown across kernel memory, concurrency, persistence, and performance</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/80 border-b border-slate-800 font-mono text-slate-400">
              <tr>
                <th className="py-3.5 px-4 w-1/5">Criterion</th>
                <th className="py-3.5 px-4 w-1/4 text-cyan-400">
                  <div className="flex items-center gap-1.5 font-bold">
                    <Database className="w-4 h-4" />
                    <span>Anonymous Pipe</span>
                  </div>
                </th>
                <th className="py-3.5 px-4 w-1/4 text-amber-400">
                  <div className="flex items-center gap-1.5 font-bold">
                    <HardDrive className="w-4 h-4" />
                    <span>Named Pipe (FIFO)</span>
                  </div>
                </th>
                <th className="py-3.5 px-4 w-1/4 text-emerald-400">
                  <div className="flex items-center gap-1.5 font-bold">
                    <Cpu className="w-4 h-4" />
                    <span>Shared Memory</span>
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {COMPARISON_DATA.map((item, idx) => (
                <tr key={idx} className="hover:bg-slate-800/20 transition-colors">
                  <td className="py-3.5 px-4 font-semibold text-slate-200 font-sans">
                    {item.metric}
                    <div className="text-[10px] text-slate-500 font-mono mt-0.5">{item.category}</div>
                  </td>
                  <td className="py-3.5 px-4 leading-relaxed font-sans text-slate-300">
                    {item.pipe}
                  </td>
                  <td className="py-3.5 px-4 leading-relaxed font-sans text-slate-300">
                    {item.fifo}
                  </td>
                  <td className="py-3.5 px-4 leading-relaxed font-sans text-slate-300">
                    {item.shm}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
