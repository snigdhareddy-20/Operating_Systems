import React from 'react';
import { ChannelState, IPCMechanismType, IPCMessage, ProcessState } from '../../types/ipc';
import { Activity, ArrowRight, CheckCircle2, Clock, Cpu, Database, HardDrive, Layers, Play, Send, ShieldAlert, Sparkles, Terminal } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

interface OverviewDashboardProps {
  channelState: ChannelState;
  messages: IPCMessage[];
  processAState: ProcessState;
  processBState: ProcessState;
  totalSent: number;
  totalReceived: number;
  totalBytes: number;
  activeMechanism: IPCMechanismType;
  setActiveMechanism: (m: IPCMechanismType) => void;
  onNavigate: (tab: string) => void;
  onQuickSend: () => void;
}

export const OverviewDashboard: React.FC<OverviewDashboardProps> = ({
  channelState,
  messages,
  processAState,
  processBState,
  totalSent,
  totalReceived,
  totalBytes,
  activeMechanism,
  setActiveMechanism,
  onNavigate,
  onQuickSend
}) => {
  // Generate mock chart timeline based on real message count
  const chartData = [
    { time: 'T-5m', packets: Math.max(0, totalSent - 8), bytes: Math.max(0, totalBytes - 350) },
    { time: 'T-4m', packets: Math.max(0, totalSent - 6), bytes: Math.max(0, totalBytes - 260) },
    { time: 'T-3m', packets: Math.max(0, totalSent - 4), bytes: Math.max(0, totalBytes - 180) },
    { time: 'T-2m', packets: Math.max(0, totalSent - 2), bytes: Math.max(0, totalBytes - 90) },
    { time: 'T-1m', packets: Math.max(0, totalSent - 1), bytes: Math.max(0, totalBytes - 30) },
    { time: 'Now', packets: totalSent, bytes: totalBytes }
  ];

  const avgLatency = messages.length > 0
    ? (messages.reduce((acc, m) => acc + m.latencyMs, 0) / messages.length).toFixed(2)
    : '0.45';

  return (
    <div className="space-y-6">
      
      {/* Hero Welcome Banner */}
      <div className="relative overflow-hidden rounded-2xl border border-cyan-500/20 bg-gradient-to-r from-slate-900 via-[#0d1627] to-[#090f1d] p-6 lg:p-8 shadow-xl">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 text-xs font-mono text-cyan-400 mb-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            <span>OPERATING SYSTEM LAB · REAL-TIME IPC DEMONSTRATION</span>
          </div>
          <h1 className="text-2xl lg:text-3xl font-bold tracking-tight text-white mb-2 text-balance">
            Inter-Process Chat & Kernel Visualization Lab
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed mb-5">
            Explore how isolated operating system processes bypass virtual memory boundaries to exchange data.
            Simulate anonymous pipes, named FIFOs, and shared memory with live packet tracing, process telemetry, and real Linux C source code.
          </p>
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => onNavigate('playground')}
              className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-2 cursor-pointer transition-colors"
            >
              <Play className="w-3.5 h-3.5 fill-slate-950" />
              <span>Launch Interactive Playground</span>
            </button>
            <button
              onClick={onQuickSend}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-cyan-500/30 text-xs font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <Send className="w-3.5 h-3.5 text-cyan-400" />
              <span>Send Sample IPC Packet</span>
            </button>
            <button
              onClick={() => onNavigate('learning')}
              className="px-4 py-2 bg-transparent hover:bg-slate-800/60 text-slate-300 border border-slate-750 text-xs font-medium rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <span>Learn Mechanisms & Quizzes</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
            </button>
          </div>
        </div>

        {/* Ambient subtle glow background */}
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-gradient-to-l from-cyan-500/10 to-transparent pointer-events-none" />
      </div>

      {/* Live Metric Counters Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Metric 1: Process Status */}
        <div className="bg-[#0e1526] border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="text-xs text-slate-400 font-mono flex items-center justify-between mb-1">
            <span>PROCESS STATES</span>
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-base font-bold text-white flex items-center gap-2 mt-1">
            <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded ${processAState === 'running' ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/40' : 'bg-rose-950/60 text-rose-300 border border-rose-800/40'}`}>
              Proc A: {processAState}
            </span>
            <span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded ${processBState === 'running' ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/40' : 'bg-rose-950/60 text-rose-300 border border-rose-800/40'}`}>
              Proc B: {processBState}
            </span>
          </div>
          <div className="text-[11px] text-slate-500 mt-2 font-mono">
            PID 2481 & PID 2482
          </div>
        </div>

        {/* Metric 2: Transmitted Packets */}
        <div className="bg-[#0e1526] border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="text-xs text-slate-400 font-mono flex items-center justify-between mb-1">
            <span>PACKETS COMMITTED</span>
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">
            {totalSent} <span className="text-xs font-normal text-slate-400">pkts</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono flex items-center gap-2">
            <span>{totalBytes} Bytes Total</span>
            <span>·</span>
            <span className="text-emerald-400">{totalReceived} Recv</span>
          </div>
        </div>

        {/* Metric 3: Active Mechanism */}
        <div className="bg-[#0e1526] border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="text-xs text-slate-400 font-mono flex items-center justify-between mb-1">
            <span>ACTIVE CHANNEL</span>
            <Database className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-base font-bold text-white capitalize mt-0.5">
            {activeMechanism === 'pipe' ? 'Anonymous Pipe' : activeMechanism === 'fifo' ? 'Named Pipe (FIFO)' : 'Shared Memory'}
          </div>
          <div className="text-[11px] text-cyan-400 mt-1 font-mono">
            {activeMechanism === 'pipe' && 'Kernel Ring Buffer (64 KB)'}
            {activeMechanism === 'fifo' && '/tmp/ipc_chat_a2b.fifo'}
            {activeMechanism === 'shm' && 'Zero-Copy RAM 0x7ffd1000'}
          </div>
        </div>

        {/* Metric 4: Latency & Transfer Speed */}
        <div className="bg-[#0e1526] border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="text-xs text-slate-400 font-mono flex items-center justify-between mb-1">
            <span>AVG IPC LATENCY</span>
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">
            {avgLatency} <span className="text-xs font-normal text-slate-400">ms</span>
          </div>
          <div className="text-[11px] text-emerald-400 mt-1 font-mono">
            Memory Bus Speed (Nominal)
          </div>
        </div>

      </div>

      {/* Two Column Section: Architecture Visual & Live Throughput Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Visual Architecture Card */}
        <div className="bg-[#0e1526] border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">OS Virtual Memory & IPC Architecture</h3>
                <p className="text-xs text-slate-400">Physical address translation and kernel channel bridge</p>
              </div>
              <span className="text-[11px] font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800/40 px-2 py-0.5 rounded">
                Linux MMU Diagram
              </span>
            </div>

            {/* Generated Architectural Visual */}
            <div className="relative rounded-lg overflow-hidden border border-slate-800 aspect-video bg-slate-950">
              <img
                src="/src/assets/images/ipc_kernel_architecture_1792212145309.jpg"
                alt="IPC Kernel Memory Architecture"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-transparent flex items-end p-3">
                <div className="text-xs text-slate-300 font-mono">
                  Process A [0x1000] ➔ Shared Kernel Memory ➔ Process B [0x5000]
                </div>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-between">
            <span>Zero-copy shared memory avoids double-buffer user space copy.</span>
            <button
              onClick={() => onNavigate('comparison')}
              className="text-cyan-400 hover:underline font-medium cursor-pointer"
            >
              Compare Mechanisms →
            </button>
          </div>
        </div>

        {/* Live Throughput & Packet Activity */}
        <div className="bg-[#0e1526] border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">Packet Throughput Telemetry</h3>
                <p className="text-xs text-slate-400">Total packets transmitted over observation window</p>
              </div>
              <span className="text-xs font-mono text-emerald-400 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                Live Sync
              </span>
            </div>

            {/* Recharts Area Chart */}
            <div className="h-48 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="packetGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="time" stroke="#475569" fontSize={11} tickLine={false} />
                  <YAxis stroke="#475569" fontSize={11} tickLine={false} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#090d16', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
                    itemStyle={{ color: '#06b6d4' }}
                  />
                  <Area type="monotone" dataKey="packets" stroke="#06b6d4" strokeWidth={2} fillOpacity={1} fill="url(#packetGradient)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-between">
            <span>Buffer capacity: 64 KB (Pipe) · 4 KB (SHM block)</span>
            <button
              onClick={() => onNavigate('logs')}
              className="text-cyan-400 hover:underline font-medium cursor-pointer"
            >
              View Message Logs ({messages.length}) →
            </button>
          </div>
        </div>

      </div>

      {/* IPC Mechanisms Feature Showcase Cards */}
      <div>
        <div className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-3">
          Choose an IPC Mechanism to Explore:
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          
          {/* Card 1: Anonymous Pipes */}
          <div
            onClick={() => {
              setActiveMechanism('pipe');
              onNavigate('playground');
            }}
            className={`p-4 rounded-xl border transition-all cursor-pointer group ${
              activeMechanism === 'pipe'
                ? 'bg-cyan-950/30 border-cyan-500/60 shadow-[0_0_15px_rgba(6,182,212,0.15)]'
                : 'bg-[#0e1526] border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono text-cyan-400 font-semibold">pipe() / fork()</span>
              <Database className="w-4 h-4 text-slate-400 group-hover:text-cyan-400 transition-colors" />
            </div>
            <h4 className="text-sm font-bold text-slate-100 group-hover:text-cyan-300 transition-colors">
              Anonymous Pipes
            </h4>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Unidirectional byte stream between parent and child processes. Inherited across fork() with built-in OS blocking.
            </p>
            <div className="mt-3 text-[11px] font-mono text-slate-500 flex items-center justify-between">
              <span>Related Processes</span>
              <span className="text-cyan-400 group-hover:translate-x-1 transition-transform">Explore →</span>
            </div>
          </div>

          {/* Card 2: Named Pipes (FIFO) */}
          <div
            onClick={() => {
              setActiveMechanism('fifo');
              onNavigate('playground');
            }}
            className={`p-4 rounded-xl border transition-all cursor-pointer group ${
              activeMechanism === 'fifo'
                ? 'bg-cyan-950/30 border-cyan-500/60 shadow-[0_0_15px_rgba(6,182,212,0.15)]'
                : 'bg-[#0e1526] border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono text-amber-400 font-semibold">mkfifo() / open()</span>
              <HardDrive className="w-4 h-4 text-slate-400 group-hover:text-amber-400 transition-colors" />
            </div>
            <h4 className="text-sm font-bold text-slate-100 group-hover:text-amber-300 transition-colors">
              Named Pipes (FIFO)
            </h4>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Special filesystem nodes allowing two completely unrelated processes to communicate without common ancestry.
            </p>
            <div className="mt-3 text-[11px] font-mono text-slate-500 flex items-center justify-between">
              <span>Independent Processes</span>
              <span className="text-cyan-400 group-hover:translate-x-1 transition-transform">Explore →</span>
            </div>
          </div>

          {/* Card 3: Shared Memory */}
          <div
            onClick={() => {
              setActiveMechanism('shm');
              onNavigate('playground');
            }}
            className={`p-4 rounded-xl border transition-all cursor-pointer group ${
              activeMechanism === 'shm'
                ? 'bg-cyan-950/30 border-cyan-500/60 shadow-[0_0_15px_rgba(6,182,212,0.15)]'
                : 'bg-[#0e1526] border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-mono text-emerald-400 font-semibold">shm_open() / mmap()</span>
              <Cpu className="w-4 h-4 text-slate-400 group-hover:text-emerald-400 transition-colors" />
            </div>
            <h4 className="text-sm font-bold text-slate-100 group-hover:text-emerald-300 transition-colors">
              POSIX Shared Memory
            </h4>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Fastest IPC mechanism. Maps physical RAM directly into processes. Requires explicit semaphores to prevent race conditions.
            </p>
            <div className="mt-3 text-[11px] font-mono text-slate-500 flex items-center justify-between">
              <span>Zero-Copy Speed</span>
              <span className="text-cyan-400 group-hover:translate-x-1 transition-transform">Explore →</span>
            </div>
          </div>

        </div>
      </div>

    </div>
  );
};
