import React, { useState } from 'react';
import { IPCMechanismType, IPCMessage } from '../../types/ipc';
import { exportLogsToCSV } from '../../services/ipcSimulation';
import { Download, Search, Trash2, Filter, CheckCircle2, AlertTriangle, Clock, ArrowRightLeft } from 'lucide-react';

interface MessageLogsProps {
  messages: IPCMessage[];
  onClearLogs: () => void;
}

export const MessageLogs: React.FC<MessageLogsProps> = ({ messages, onClearLogs }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterProcess, setFilterProcess] = useState<string>('all');
  const [filterMechanism, setFilterMechanism] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const filteredMessages = messages.filter((msg) => {
    // Search
    if (searchTerm && !msg.content.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    // Process filter
    if (filterProcess === 'proc_a' && msg.senderId !== 'proc_a' && msg.receiverId !== 'proc_a') {
      return false;
    }
    if (filterProcess === 'proc_b' && msg.senderId !== 'proc_b' && msg.receiverId !== 'proc_b') {
      return false;
    }
    // Mechanism filter
    if (filterMechanism !== 'all' && msg.mechanism !== filterMechanism) {
      return false;
    }
    // Status filter
    if (filterStatus === 'delivered' && msg.status !== 'delivered') {
      return false;
    }
    if (filterStatus === 'error' && !msg.status.startsWith('error')) {
      return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      
      {/* Top Controls Bar */}
      <div className="bg-[#0e1526] border border-slate-800 rounded-xl p-5 shadow-lg">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <h3 className="text-sm font-semibold text-slate-200">IPC Packet Transmission Logs</h3>
            <p className="text-xs text-slate-400">Searchable history of inter-process messages, channel stats, and delivery states</p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => exportLogsToCSV(messages)}
              disabled={messages.length === 0}
              className="px-3.5 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              title="Download RFC 4180 CSV export"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>

            <button
              onClick={onClearLogs}
              disabled={messages.length === 0}
              className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-rose-300 border border-slate-800 rounded-lg text-xs flex items-center gap-1.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              title="Clear all stored logs"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear History</span>
            </button>
          </div>
        </div>

        {/* Filter Toolbar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-4">
          
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search packet payload..."
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Process Filter */}
          <div>
            <select
              value={filterProcess}
              onChange={(e) => setFilterProcess(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              <option value="all">All Processes</option>
              <option value="proc_a">Process A (PID 2481)</option>
              <option value="proc_b">Process B (PID 2482)</option>
            </select>
          </div>

          {/* Mechanism Filter */}
          <div>
            <select
              value={filterMechanism}
              onChange={(e) => setFilterMechanism(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              <option value="all">All Mechanisms</option>
              <option value="pipe">Anonymous Pipe</option>
              <option value="fifo">Named Pipe (FIFO)</option>
              <option value="shm">POSIX Shared Memory</option>
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              <option value="all">All Delivery States</option>
              <option value="delivered">Delivered OK</option>
              <option value="error">Errors & Dropped (SIGPIPE)</option>
            </select>
          </div>

        </div>
      </div>

      {/* Log Table */}
      <div className="bg-[#0e1526] border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/80 border-b border-slate-800 text-slate-400 font-mono">
              <tr>
                <th className="py-3 px-4">Packet Seq / ID</th>
                <th className="py-3 px-3">Timestamp</th>
                <th className="py-3 px-3">Flow Path</th>
                <th className="py-3 px-3">Mechanism</th>
                <th className="py-3 px-4">Payload Content</th>
                <th className="py-3 px-3">Size (Bytes)</th>
                <th className="py-3 px-3">Latency</th>
                <th className="py-3 px-4 text-right">Delivery Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
              {filteredMessages.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500">
                    <div className="max-w-xs mx-auto space-y-1">
                      <p className="font-semibold text-slate-400">No matching message packets</p>
                      <p className="text-[11px]">Send a message from the Playground to record new IPC transmission logs.</p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredMessages.map((msg) => {
                  const isAtoB = msg.senderId === 'proc_a';
                  const isSuccess = msg.status === 'delivered';

                  return (
                    <tr key={msg.id} className="hover:bg-slate-800/20 transition-colors">
                      <td className="py-3 px-4 text-slate-400 text-[11px]">
                        #{msg.packetSeq} · <span className="text-slate-500">{msg.id.slice(0, 10)}</span>
                      </td>
                      <td className="py-3 px-3 text-slate-300">
                        {msg.timestamp}
                      </td>
                      <td className="py-3 px-3">
                        <span className="inline-flex items-center gap-1.5 font-sans font-medium text-slate-200">
                          {isAtoB ? (
                            <>
                              <span className="text-cyan-400">Proc A (2481)</span>
                              <span className="text-slate-500">➔</span>
                              <span className="text-slate-300">Proc B (2482)</span>
                            </>
                          ) : (
                            <>
                              <span className="text-emerald-400">Proc B (2482)</span>
                              <span className="text-slate-500">➔</span>
                              <span className="text-slate-300">Proc A (2481)</span>
                            </>
                          )}
                        </span>
                      </td>
                      <td className="py-3 px-3 capitalize">
                        <span className={`px-2 py-0.5 rounded text-[11px] ${
                          msg.mechanism === 'pipe'
                            ? 'bg-cyan-950/60 text-cyan-300 border border-cyan-800/40'
                            : msg.mechanism === 'fifo'
                            ? 'bg-amber-950/60 text-amber-300 border border-amber-800/40'
                            : 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/40'
                        }`}>
                          {msg.mechanism}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-sans max-w-xs truncate text-slate-100" title={msg.content}>
                        {msg.content}
                        {msg.errorMessage && (
                          <div className="text-[10px] text-rose-400 font-mono mt-0.5">
                            {msg.errorMessage}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-3 tabular-nums text-slate-400">
                        {msg.sizeBytes} B
                      </td>
                      <td className="py-3 px-3 tabular-nums text-slate-400">
                        {msg.latencyMs} ms
                      </td>
                      <td className="py-3 px-4 text-right">
                        {isSuccess ? (
                          <span className="inline-flex items-center gap-1 text-emerald-400 text-[11px] font-semibold">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>DELIVERED</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-rose-400 text-[11px] font-semibold">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            <span>SIGPIPE / ERR</span>
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer */}
        <div className="p-3 bg-slate-900/60 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-between">
          <span>Showing {filteredMessages.length} of {messages.length} total recorded packets</span>
          <span className="font-mono text-[11px]">CSV formatted per RFC 4180</span>
        </div>
      </div>

    </div>
  );
};
