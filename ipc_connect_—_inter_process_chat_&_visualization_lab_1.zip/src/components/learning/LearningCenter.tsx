import React, { useState } from 'react';
import { LEARNING_MODULES, QUIZ_QUESTIONS } from '../../data/learningContent';
import { BookOpen, CheckCircle2, XCircle, RotateCcw, Award, ChevronRight, HelpCircle, Sparkles } from 'lucide-react';

export const LearningCenter: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'guides' | 'quiz'>('guides');
  const [selectedModuleId, setSelectedModuleId] = useState<string>('processes');

  // Quiz state
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [showResults, setShowResults] = useState(false);

  const selectedModule = LEARNING_MODULES.find(m => m.id === selectedModuleId) || LEARNING_MODULES[0];

  const handleSelectAnswer = (questionId: number, optionIdx: number) => {
    if (selectedAnswers[questionId] !== undefined) return; // Prevent changing after selection
    setSelectedAnswers(prev => ({ ...prev, [questionId]: optionIdx }));
  };

  const resetQuiz = () => {
    setSelectedAnswers({});
    setShowResults(false);
  };

  const answeredCount = Object.keys(selectedAnswers).length;
  const correctCount = QUIZ_QUESTIONS.filter(q => selectedAnswers[q.id] === q.correctIndex).length;
  const scorePercent = Math.round((correctCount / QUIZ_QUESTIONS.length) * 100);

  return (
    <div className="space-y-6">
      
      {/* Top Header & Sub-tab switcher */}
      <div className="bg-[#0e1526] border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-100">IPC Systems Learning Center</h2>
          <p className="text-xs text-slate-400 mt-0.5">Explore operating system process communication, memory architecture, and test your knowledge</p>
        </div>

        <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-1 text-xs font-medium shrink-0">
          <button
            onClick={() => setActiveSubTab('guides')}
            className={`px-3 py-1.5 rounded-md cursor-pointer transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'guides' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Interactive Guides</span>
          </button>
          <button
            onClick={() => setActiveSubTab('quiz')}
            className={`px-3 py-1.5 rounded-md cursor-pointer transition-colors flex items-center gap-1.5 ${
              activeSubTab === 'quiz' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            <span>IPC Quiz ({answeredCount}/{QUIZ_QUESTIONS.length})</span>
          </button>
        </div>
      </div>

      {/* SUB-TAB 1: GUIDES & THEORY */}
      {activeSubTab === 'guides' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          
          {/* Module Selector Sidebar */}
          <div className="space-y-2 lg:col-span-1">
            <div className="text-xs font-mono text-slate-400 uppercase tracking-wider px-1 mb-2">
              Curriculum Modules
            </div>
            {LEARNING_MODULES.map((mod) => {
              const isSelected = mod.id === selectedModuleId;
              return (
                <button
                  key={mod.id}
                  onClick={() => setSelectedModuleId(mod.id)}
                  className={`w-full text-left p-3 rounded-xl border transition-all cursor-pointer flex items-start justify-between gap-2 ${
                    isSelected
                      ? 'bg-cyan-950/40 border-cyan-500/60 shadow-[0_0_15px_rgba(6,182,212,0.15)] text-white'
                      : 'bg-[#0e1526] border-slate-850 hover:border-slate-750 text-slate-300'
                  }`}
                >
                  <div>
                    <div className="text-xs font-bold leading-tight">{mod.title}</div>
                    <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-2">
                      <span>{mod.tag}</span>
                      <span>·</span>
                      <span>{mod.readTime}</span>
                    </div>
                  </div>
                  {isSelected && <ChevronRight className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />}
                </button>
              );
            })}
          </div>

          {/* Module Reader Panel */}
          <div className="lg:col-span-3 bg-[#0e1526] border border-slate-800 rounded-xl p-6 lg:p-8 shadow-lg">
            <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-2">
              <span>{selectedModule.tag}</span>
              <span>·</span>
              <span>{selectedModule.readTime}</span>
            </div>
            
            <h2 className="text-xl font-bold text-white mb-2">
              {selectedModule.title}
            </h2>
            
            <p className="text-xs text-slate-400 pb-5 mb-6 border-b border-slate-800 leading-relaxed">
              {selectedModule.summary}
            </p>

            <div className="prose prose-invert max-w-none text-slate-300 text-sm leading-relaxed space-y-4">
              {selectedModule.content.split('\n\n').map((paragraph, idx) => {
                const trimmed = paragraph.trim();
                if (!trimmed) return null;

                if (trimmed.startsWith('### ')) {
                  return (
                    <h3 key={idx} className="text-base font-bold text-slate-100 pt-4 pb-1 text-cyan-300">
                      {trimmed.replace('### ', '')}
                    </h3>
                  );
                }

                if (trimmed.startsWith('```')) {
                  const codeLines = trimmed.replace(/```[a-z]*/g, '').trim();
                  return (
                    <pre key={idx} className="bg-slate-950 p-4 rounded-lg border border-slate-800 font-mono text-xs text-slate-200 overflow-x-auto">
                      <code>{codeLines}</code>
                    </pre>
                  );
                }

                if (trimmed.startsWith('- ')) {
                  const listItems = trimmed.split('\n').map(l => l.replace(/^- /, ''));
                  return (
                    <ul key={idx} className="list-disc pl-5 space-y-1.5 text-xs text-slate-300">
                      {listItems.map((item, lIdx) => (
                        <li key={lIdx}>
                          <span dangerouslySetInnerHTML={{
                            __html: item
                              .replace(/\*\*(.*?)\*\*/g, '<strong class="text-white">$1</strong>')
                              .replace(/`([^`]+)`/g, '<code class="bg-slate-900 px-1 py-0.5 rounded text-cyan-300 font-mono text-[11px]">$1</code>')
                          }} />
                        </li>
                      ))}
                    </ul>
                  );
                }

                if (/^[0-9]+\. /.test(trimmed)) {
                  const listItems = trimmed.split('\n').map(l => l.replace(/^[0-9]+\. /, ''));
                  return (
                    <ol key={idx} className="list-decimal pl-5 space-y-1.5 text-xs text-slate-300">
                      {listItems.map((item, lIdx) => (
                        <li key={lIdx}>
                          <span dangerouslySetInnerHTML={{
                            __html: item
                              .replace(/\*\*(.*?)\*\*/g, '<strong class="text-white">$1</strong>')
                              .replace(/`([^`]+)`/g, '<code class="bg-slate-900 px-1 py-0.5 rounded text-cyan-300 font-mono text-[11px]">$1</code>')
                          }} />
                        </li>
                      ))}
                    </ol>
                  );
                }

                return (
                  <p key={idx} className="text-xs text-slate-300 leading-relaxed"
                    dangerouslySetInnerHTML={{
                      __html: trimmed
                        .replace(/\*\*(.*?)\*\*/g, '<strong class="text-white">$1</strong>')
                        .replace(/`([^`]+)`/g, '<code class="bg-slate-900 px-1 py-0.5 rounded text-cyan-300 font-mono text-[11px]">$1</code>')
                    }}
                  />
                );
              })}
            </div>
          </div>

        </div>
      )}

      {/* SUB-TAB 2: INTERACTIVE QUIZ LAB */}
      {activeSubTab === 'quiz' && (
        <div className="space-y-6">
          
          {/* Quiz Scoreboard Banner */}
          <div className="bg-[#0e1526] border border-slate-800 rounded-xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="text-xs font-mono text-cyan-400 mb-1 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>INTERACTIVE KNOWLEDGE EVALUATION</span>
              </div>
              <h3 className="text-base font-bold text-white">Linux IPC Mastery Assessment</h3>
              <p className="text-xs text-slate-400">Answer each question to receive immediate operating-system feedback and explanations.</p>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-right">
                <div className="text-xs text-slate-400 font-mono">Current Score</div>
                <div className="text-lg font-bold font-mono text-cyan-400 tabular-nums">
                  {correctCount} / {QUIZ_QUESTIONS.length} ({scorePercent}%)
                </div>
              </div>

              <button
                onClick={resetQuiz}
                className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 rounded-lg text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
                <span>Retake Quiz</span>
              </button>
            </div>
          </div>

          {/* Question Cards */}
          <div className="space-y-4">
            {QUIZ_QUESTIONS.map((q, qIndex) => {
              const selectedOption = selectedAnswers[q.id];
              const isAnswered = selectedOption !== undefined;
              const isCorrect = selectedOption === q.correctIndex;

              return (
                <div
                  key={q.id}
                  className={`bg-[#0e1526] border rounded-xl p-5 transition-all ${
                    isAnswered
                      ? isCorrect
                        ? 'border-emerald-500/40 bg-emerald-950/10'
                        : 'border-rose-500/40 bg-rose-950/10'
                      : 'border-slate-800'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <span className="text-xs font-mono text-cyan-400 font-semibold">
                      Question {qIndex + 1} of {QUIZ_QUESTIONS.length}
                    </span>
                    <span className="text-[11px] font-mono uppercase text-slate-500">
                      Category: {q.category}
                    </span>
                  </div>

                  <p className="text-sm font-semibold text-slate-100 mb-4 leading-snug">
                    {q.question}
                  </p>

                  {/* Options */}
                  <div className="space-y-2 mb-4">
                    {q.options.map((opt, optIdx) => {
                      let btnStyle = 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-850 hover:text-white';
                      
                      if (isAnswered) {
                        if (optIdx === q.correctIndex) {
                          btnStyle = 'bg-emerald-950/60 border-emerald-500 text-emerald-200 font-medium';
                        } else if (optIdx === selectedOption) {
                          btnStyle = 'bg-rose-950/60 border-rose-500 text-rose-200';
                        } else {
                          btnStyle = 'bg-slate-950/40 border-slate-850 text-slate-500 opacity-60';
                        }
                      }

                      return (
                        <button
                          key={optIdx}
                          onClick={() => handleSelectAnswer(q.id, optIdx)}
                          disabled={isAnswered}
                          className={`w-full text-left p-3 rounded-lg border text-xs transition-colors flex items-center justify-between gap-3 cursor-pointer disabled:cursor-default ${btnStyle}`}
                        >
                          <span>{opt}</span>
                          {isAnswered && optIdx === q.correctIndex && (
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          )}
                          {isAnswered && optIdx === selectedOption && optIdx !== q.correctIndex && (
                            <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                          )}
                        </button>
                      );
                    })}
                  </div>

                  {/* Immediate Explanation Reveal */}
                  {isAnswered && (
                    <div className={`p-3.5 rounded-lg border text-xs leading-relaxed ${
                      isCorrect ? 'bg-emerald-950/40 border-emerald-800/40 text-emerald-200' : 'bg-rose-950/40 border-rose-800/40 text-rose-200'
                    }`}>
                      <div className="font-bold mb-1 flex items-center gap-1.5">
                        {isCorrect ? '✓ Correct Answer!' : '✕ Incorrect'}
                      </div>
                      <p className="text-slate-300">{q.explanation}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

        </div>
      )}

    </div>
  );
};
