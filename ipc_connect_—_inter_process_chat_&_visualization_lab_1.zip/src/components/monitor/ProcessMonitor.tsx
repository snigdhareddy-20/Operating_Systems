import React, { useState } from 'react';
import { ChannelState, IPCMechanismType, IPCProcess, ProcessState } from '../../types/ipc';
import { Activity, AlertCircle, CheckCircle, Cpu, HardDrive, Info, Layers, Play, RefreshCw, Square, Terminal, Zap } from 'lucide-react';

interface ProcessMonitorProps {
  processA: IPCProcess;
  processB: IPCProcess;
  channelState: ChannelState;
  activeMechanism: IPCMechanismType;
  onToggleProcessState: (processId: 'proc_a' | 'proc_b', newState: ProcessState) => void;
  onSendSignal: (processId: 'proc_a' | 'proc_b', signal: string) => void;
}

export const ProcessMonitor: React.FC<ProcessMonitorProps> = ({
  processA,
  processB,
  channelState,
  activeMechanism,
  onToggleProcessState,
  onSendSignal
}) => {
  const [signalFeedback, setSignalFeedback] = useState<string | null>(null);

  const handleSignal = (procId: 'proc_a' | 'proc_b', sig: string) => {
    onSendSignal(procId, sig);
    setSignalFeedback(`Sent ${sig} to ${procId === 'proc_a' ? 'Process A (PID 2481)' : 'Process B (PID 2482)'}`);
    setTimeout(() => setSignalFeedback(null), 3000);
  };

  const kernelDaemon = {
    id: 'kernel_broker',
    name: 'Linux Kernel IPC Subsystem',
    pid: 1,
    state: 'running',
    role: 'kernel',
    channel: activeMechanism === 'pipe' ? 'pipefs / ring buffer' : activeMechanism === 'fifo' ? 'vfs / fifo inode' : 'shmfs / tmpfs',
    memoryUsageKb: 1024,
    cpuPercent: 0.1,
    lastActive: 'Continuous'
  };

  return (
    <div className="space-y-6">
      
      {/* Simulation Transparency Banner */}
      <div className="p-4 rounded-xl border border-cyan-500/30 bg-cyan-950/20 flex items-start gap-3 text-xs text-slate-300">
        <Info className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <div className="font-semibold text-cyan-200">
            Simulated Linux Process Telemetry
          </div>
          <p className="text-slate-400 leading-relaxed">
            These processes operate within the educational sandbox to demonstrate POSIX process states (Running, Stopped, Blocked on I/O), memory page mapping, and file descriptor allocation.
            They accurately reflect Linux IPC semantics without making fabricated claims about your host machine.
          </p>
        </div>
      </div>

      {signalFeedback && (
        <div className="p-3 bg-emerald-950/40 border border-emerald-500/50 rounded-lg text-xs font-mono text-emerald-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            <span>{signalFeedback}</span>
          </div>
          <span className="text-[11px] text-slate-400">Signal Acknowledged</span>
        </div>
      )}

      {/* Main Process Table */}
      <div className="bg-[#0e1526] border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-200">Active Monitored Processes</h3>
            <p className="text-xs text-slate-400">Process lifecycle, memory footprint, and channel bindings</p>
          </div>
          <span className="text-xs font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-800/40 px-2.5 py-1 rounded">
            Channel: {activeMechanism.toUpperCase()}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/80 border-b border-slate-800 text-slate-400 font-mono">
              <tr>
                <th className="py-3 px-4">Process Name</th>
                <th className="py-3 px-3">PID</th>
                <th className="py-3 px-3">State</th>
                <th className="py-3 px-3">IPC Channel</th>
                <th className="py-3 px-3">Sent / Recv</th>
                <th className="py-3 px-3">Bytes Flow</th>
                <th className="py-3 px-3">Memory (RSS)</th>
                <th className="py-3 px-3">Last Active</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-slate-300">
              
              {/* Process A Row */}
              <tr className="hover:bg-slate-800/20 transition-colors">
                <td className="py-3 px-4">
                  <div className="font-semibold text-slate-100 flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${processA.state === 'running' ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                    {processA.name}
                  </div>
                  <div className="text-[11px] text-slate-500">Virtual Memory Space: 0x7ffd...</div>
                </td>
                <td className="py-3 px-3 font-bold text-cyan-400">2481</td>
                <td className="py-3 px-3">
                  <span className={`px-2 py-0.5 rounded text-[11px] uppercase font-semibold ${
                    processA.state === 'running' ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/40' : 'bg-rose-950/60 text-rose-300 border border-rose-800/40'
                  }`}>
                    {processA.state}
                  </span>
                </td>
                <td className="py-3 px-3 text-slate-300">
                  {activeMechanism === 'pipe' ? 'fd[4] (Write)' : activeMechanism === 'fifo' ? '/tmp/ipc_a2b.fifo' : 'SHM 0x7ffd1000'}
                </td>
                <td className="py-3 px-3 tabular-nums">
                  <span className="text-cyan-400">{processA.messagesSent} TX</span> / <span className="text-slate-400">{processA.messagesReceived} RX</span>
                </td>
                <td className="py-3 px-3 tabular-nums text-slate-400">
                  {processA.bytesSent} B
                </td>
                <td className="py-3 px-3 tabular-nums text-slate-400">
                  {processA.memoryUsageKb} KB
                </td>
                <td className="py-3 px-3 text-slate-400 text-[11px]">
                  {processA.lastActive}
                </td>
                <td className="py-3 px-4 text-right">
                  <div className="flex items-center justify-end gap-1.5 font-sans">
                    {processA.state === 'running' ? (
                      <button
                        onClick={() => onToggleProcessState('proc_a', 'stopped')}
                        className="px-2 py-1 text-[11px] text-rose-300 bg-rose-950/50 hover:bg-rose-900 border border-rose-800/40 rounded cursor-pointer"
                        title="Stop Process (Simulate killed process)"
                      >
                        Stop
                      </button>
                    ) : (
                      <button
                        onClick={() => onToggleProcessState('proc_a', 'running')}
                        className="px-2 py-1 text-[11px] text-emerald-300 bg-emerald-950/50 hover:bg-emerald-900 border border-emerald-800/40 rounded cursor-pointer"
                      >
                        Resume
                      </button>
                    )}
                    <button
                      onClick={() => handleSignal('proc_a', 'SIGUSR1')}
                      className="px-2 py-1 text-[11px] text-cyan-300 bg-slate-900 hover:bg-slate-800 border border-slate-750 rounded cursor-pointer"
                      title="Send User Defined Signal 1"
                    >
                      SIGUSR1
                    </button>
                  </div>
                </td>
              </tr>

              {/* Process B Row */}
              <tr className="hover:bg-slate-800/20 transition-colors">
                <td className="py-3 px-4">
                  <div className="font-semibold text-slate-100 flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${processB.state === 'running' ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                    {processB.name}
                  </div>
                  <div className="text-[11px] text-slate-500">Virtual Memory Space: 0x55a4...</div>
                </td>
                <td className="py-3 px-3 font-bold text-cyan-400">2482</td>
                <td className="py-3 px-3">
                  <span className={`px-2 py-0.5 rounded text-[11px] uppercase font-semibold ${
                    processB.state === 'running' ? 'bg-emerald-950/60 text-emerald-300 border border-emerald-800/40' : 'bg-rose-950/60 text-rose-300 border border-rose-800/40'
                  }`}>
                    {processB.state}
                  </span>
                </td>
                <td className="py-3 px-3 text-slate-300">
                  {activeMechanism === 'pipe' ? 'fd[3] (Read)' : activeMechanism === 'fifo' ? '/tmp/ipc_b2a.fifo' : 'SHM 0x7ffd1000'}
                </td>
                <td className="py-3 px-3 tabular-nums">
                  <span className="text-cyan-400">{processB.messagesSent} TX</span> / <span className="text-slate-400">{processB.messagesReceived} RX</span>
                </td>
                <td className="py-3 px-3 tabular-nums text-slate-400">
                  {processB.bytesSent} B
                </td>
                <td className="py-3 px-3 tabular-nums text-slate-400">
                  {processB.memoryUsageKb} KB
                </td>
                <td className="py-3 px-3 text-slate-400 text-[11px]">
                  {processB.lastActive}
                </td>
                <td className="py-3 px-4 text-right">
                  <div className="flex items-center justify-end gap-1.5 font-sans">
                    {processB.state === 'running' ? (
                      <button
                        onClick={() => onToggleProcessState('proc_b', 'stopped')}
                        className="px-2 py-1 text-[11px] text-rose-300 bg-rose-950/50 hover:bg-rose-900 border border-rose-800/40 rounded cursor-pointer"
                        title="Stop Process B"
                      >
                        Stop
                      </button>
                    ) : (
                      <button
                        onClick={() => onToggleProcessState('proc_b', 'running')}
                        className="px-2 py-1 text-[11px] text-emerald-300 bg-emerald-950/50 hover:bg-emerald-900 border border-emerald-800/40 rounded cursor-pointer"
                      >
                        Resume
                      </button>
                    )}
                    <button
                      onClick={() => handleSignal('proc_b', 'SIGUSR1')}
                      className="px-2 py-1 text-[11px] text-cyan-300 bg-slate-900 hover:bg-slate-800 border border-slate-750 rounded cursor-pointer"
                      title="Send User Defined Signal 1"
                    >
                      SIGUSR1
                    </button>
                  </div>
                </td>
              </tr>

              {/* Kernel Subsystem Row */}
              <tr className="bg-slate-950/40 text-slate-400">
                <td className="py-3 px-4">
                  <div className="font-semibold text-slate-300 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-cyan-400" />
                    {kernelDaemon.name}
                  </div>
                  <div className="text-[11px] text-slate-500">Ring-0 Kernel Space</div>
                </td>
                <td className="py-3 px-3 font-bold text-slate-400">1</td>
                <td className="py-3 px-3">
                  <span className="px-2 py-0.5 rounded text-[11px] uppercase bg-cyan-950/60 text-cyan-300 border border-cyan-800/40">
                    System Core
                  </span>
                </td>
                <td className="py-3 px-3 text-slate-400">{kernelDaemon.channel}</td>
                <td className="py-3 px-3 tabular-nums">Routing</td>
                <td className="py-3 px-3 tabular-nums">64 KB Limit</td>
                <td className="py-3 px-3 tabular-nums">1,024 KB</td>
                <td className="py-3 px-3 text-[11px]">Continuous</td>
                <td className="py-3 px-4 text-right text-[11px] text-slate-500 italic">
                  Kernel Protected
                </td>
              </tr>

            </tbody>
          </table>
        </div>
      </div>

      {/* Visual Memory Map & Process Space Diagram */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Virtual Address Space Layout */}
        <div className="bg-[#0e1526] border border-slate-800 rounded-xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-semibold text-slate-200">Process Virtual Address Space (x86_64)</h3>
              <p className="text-xs text-slate-400">Isolation prevents direct memory access across boundaries</p>
            </div>
            <Layers className="w-4 h-4 text-cyan-400" />
          </div>

          <div className="space-y-1.5 font-mono text-xs">
            <div className="p-2.5 rounded bg-rose-950/40 border border-rose-800/50 text-rose-200 flex justify-between items-center">
              <span>0xFFFFFFFFFFFFFFFF</span>
              <span className="font-semibold">Kernel Space (Protected)</span>
              <span>0xFFFF800000000000</span>
            </div>
            <div className="p-2 rounded bg-slate-900 border border-slate-800 text-slate-300 flex justify-between items-center">
              <span>0x7FFFFFFFFFFF</span>
              <span>User Stack (grows downwards ↓)</span>
              <span>0x7FFD00000000</span>
            </div>
            <div className="p-2.5 rounded bg-cyan-950/60 border border-cyan-500/60 text-cyan-200 flex justify-between items-center shadow-[0_0_10px_rgba(6,182,212,0.1)]">
              <span>0x7FFD1000</span>
              <span className="font-bold">★ Memory-Mapped IPC Segment (mmap / pipe)</span>
              <span>0x7FFD2000</span>
            </div>
            <div className="p-2 rounded bg-slate-900 border border-slate-800 text-slate-300 flex justify-between items-center">
              <span>0x55A40000</span>
              <span>Heap Space (malloc / brk ↑)</span>
              <span>0x55A00000</span>
            </div>
            <div className="p-2 rounded bg-slate-950 border border-slate-850 text-slate-400 flex justify-between items-center">
              <span>0x00400000</span>
              <span>Text (Executable Code) & BSS</span>
              <span>0x00000000</span>
            </div>
          </div>
        </div>

        {/* Linux Signals and Lifecycle Control */}
        <div className="bg-[#0e1526] border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-sm font-semibold text-slate-200">POSIX Signal Testing</h3>
                <p className="text-xs text-slate-400">Trigger standard OS signals to observe process reaction</p>
              </div>
              <Zap className="w-4 h-4 text-cyan-400" />
            </div>

            <div className="space-y-3">
              <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-lg flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-slate-200 font-mono">SIGPIPE (Signal 13)</div>
                  <div className="text-[11px] text-slate-400">Sent when writing to a pipe with no active reader.</div>
                </div>
                <button
                  onClick={() => {
                    onToggleProcessState('proc_b', 'stopped');
                    handleSignal('proc_a', 'SIGPIPE');
                  }}
                  className="px-2.5 py-1 text-xs bg-rose-950/60 hover:bg-rose-900 text-rose-300 border border-rose-800/50 rounded cursor-pointer"
                >
                  Trigger SIGPIPE
                </button>
              </div>

              <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-lg flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-slate-200 font-mono">SIGUSR1 (Signal 10)</div>
                  <div className="text-[11px] text-slate-400">User-defined signal used for IPC heartbeat notification.</div>
                </div>
                <button
                  onClick={() => handleSignal('proc_b', 'SIGUSR1')}
                  className="px-2.5 py-1 text-xs bg-cyan-950/60 hover:bg-cyan-900 text-cyan-300 border border-cyan-800/50 rounded cursor-pointer"
                >
                  Ping Process B
                </button>
              </div>

              <div className="p-3 bg-slate-900/80 border border-slate-800 rounded-lg flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-slate-200 font-mono">SIGTERM (Signal 15)</div>
                  <div className="text-[11px] text-slate-400">Graceful termination request to release IPC buffers.</div>
                </div>
                <button
                  onClick={() => onToggleProcessState('proc_b', 'stopped')}
                  className="px-2.5 py-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded cursor-pointer"
                >
                  Terminate B
                </button>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-500 font-mono">
            Process states synchronize with the interactive playground in real time.
          </div>
        </div>

      </div>

    </div>
  );
};
