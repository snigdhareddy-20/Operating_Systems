import React from 'react';
import { ChannelState, IPCMechanismType, IPCMessage, ProcessState } from '../../types/ipc';
import { ArrowRight, ArrowLeft, ShieldAlert, Cpu, Database, RefreshCw, Lock, Unlock, HardDrive } from 'lucide-react';

interface ChannelVisualizerProps {
  mechanism: IPCMechanismType;
  channelState: ChannelState;
  activePacket: IPCMessage | null;
  packetStage: 'idle' | 'sender_outbox' | 'kernel_buffer' | 'receiver_inbox' | 'delivered' | 'error';
  direction: 'a_to_b' | 'b_to_a';
  processAState: ProcessState;
  processBState: ProcessState;
  animationSpeed: 'slow' | 'normal' | 'fast';
  setAnimationSpeed: (speed: 'slow' | 'normal' | 'fast') => void;
  errorSimulation: 'none' | 'sigpipe' | 'buffer_full';
  setErrorSimulation: (err: 'none' | 'sigpipe' | 'buffer_full') => void;
}

export const ChannelVisualizer: React.FC<ChannelVisualizerProps> = ({
  mechanism,
  channelState,
  activePacket,
  packetStage,
  direction,
  processAState,
  processBState,
  animationSpeed,
  setAnimationSpeed,
  errorSimulation,
  setErrorSimulation
}) => {
  const isAtoB = direction === 'a_to_b';

  return (
    <div className="bg-[#0e1526] border border-slate-850 rounded-xl p-5 shadow-xl flex flex-col h-full">
      {/* Top Header with speed controls & error simulation */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="text-xs text-slate-400 font-mono">
            <span>COMMUNICATION CHANNEL</span>
            <span className="mx-1.5 text-slate-600">·</span>
            <span className="text-cyan-400 capitalize">{mechanism === 'pipe' ? 'Anonymous Pipe' : mechanism === 'fifo' ? 'Named Pipe (FIFO)' : 'POSIX Shared Memory'}</span>
          </div>
          <div className="text-sm font-semibold text-slate-200 mt-0.5">
            {isAtoB ? 'Forward Flow: Process A ➔ Process B' : 'Reverse Reply Flow: Process B ➔ Process A'}
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Speed Selector */}
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5 text-xs">
            <button
              onClick={() => setAnimationSpeed('slow')}
              className={`px-2 py-1 rounded cursor-pointer transition-colors ${
                animationSpeed === 'slow' ? 'bg-cyan-950 text-cyan-300 font-medium' : 'text-slate-400 hover:text-slate-200'
              }`}
              title="Slow Motion (0.25x) - Great for step-by-step teaching"
            >
              Slow
            </button>
            <button
              onClick={() => setAnimationSpeed('normal')}
              className={`px-2 py-1 rounded cursor-pointer transition-colors ${
                animationSpeed === 'normal' ? 'bg-cyan-950 text-cyan-300 font-medium' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              1x
            </button>
            <button
              onClick={() => setAnimationSpeed('fast')}
              className={`px-2 py-1 rounded cursor-pointer transition-colors ${
                animationSpeed === 'fast' ? 'bg-cyan-950 text-cyan-300 font-medium' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Fast
            </button>
          </div>

          {/* Error Injection */}
          <div className="flex items-center gap-1.5">
            <label className="text-xs text-slate-400 hidden xl:inline">Test Scenario:</label>
            <select
              value={errorSimulation}
              onChange={(e) => setErrorSimulation(e.target.value as any)}
              className="bg-slate-900 border border-slate-800 text-xs text-slate-300 rounded-lg px-2.5 py-1 focus:outline-none focus:border-cyan-500 cursor-pointer"
            >
              <option value="none">Normal Delivery</option>
              <option value="sigpipe">Simulate SIGPIPE (Broken Pipe)</option>
              <option value="buffer_full">Simulate 64KB Buffer Block</option>
            </select>
          </div>
        </div>
      </div>

      {/* Visual Animation Highway */}
      <div className="my-5 relative flex-1 min-h-[220px] flex flex-col justify-center">
        
        {/* Background track line */}
        <div className="absolute left-6 right-6 top-1/2 -translate-y-1/2 h-1.5 bg-slate-800/80 rounded-full overflow-hidden">
          <div
            className={`h-full transition-all duration-500 ${
              packetStage === 'error'
                ? 'bg-rose-500 w-full'
                : packetStage !== 'idle'
                ? 'bg-cyan-500/50 w-full animate-pulse'
                : 'w-0'
            }`}
          />
        </div>

        {/* 3 Nodes: Sender Socket, Channel Core, Receiver Socket */}
        <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
          
          {/* Node 1: Process A Gateway */}
          <div className={`p-4 rounded-xl border transition-all ${
            (isAtoB && packetStage === 'sender_outbox') || (!isAtoB && packetStage === 'delivered')
              ? 'bg-cyan-950/40 border-cyan-500/60 shadow-[0_0_15px_rgba(6,182,212,0.15)]'
              : 'bg-slate-900/80 border-slate-800'
          }`}>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="font-semibold text-slate-300">Process A Gateway</span>
              <span className="font-mono text-slate-400">PID 2481</span>
            </div>
            <div className="text-xs text-slate-400 font-mono flex items-center justify-between">
              <span>{mechanism === 'pipe' ? (isAtoB ? 'fd[4] write' : 'fd[5] read') : mechanism === 'fifo' ? 'O_WRONLY' : 'mmap() 0x7ffd1'}</span>
              <span className={`text-[11px] ${processAState === 'running' ? 'text-emerald-400' : 'text-rose-400'}`}>
                {processAState === 'running' ? 'Active' : 'Stopped'}
              </span>
            </div>
          </div>

          {/* Node 2: The Core IPC Channel Buffer */}
          <div className={`p-4 rounded-xl border text-center transition-all ${
            packetStage === 'kernel_buffer'
              ? 'bg-cyan-950/60 border-cyan-400 shadow-[0_0_20px_rgba(6,182,212,0.25)]'
              : packetStage === 'error'
              ? 'bg-rose-950/40 border-rose-500'
              : 'bg-slate-900/90 border-slate-750'
          }`}>
            {mechanism === 'pipe' && (
              <div>
                <div className="flex items-center justify-center gap-1.5 text-xs text-cyan-400 font-mono font-medium mb-1">
                  <Database className="w-3.5 h-3.5" />
                  <span>Kernel Ring Buffer</span>
                </div>
                <div className="text-xs text-slate-400 font-mono">
                  Capacity: 65,536 Bytes (64 KB)
                </div>
                {/* Buffer fill bar */}
                <div className="w-full bg-slate-950 h-2 rounded-full mt-2.5 overflow-hidden border border-slate-800">
                  <div
                    className="bg-cyan-500 h-full transition-all duration-300"
                    style={{
                      width: `${Math.min(100, Math.max(5, (channelState.currentBufferBytes / 65536) * 100))}%`
                    }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-1">
                  <span>In Queue: {channelState.currentBufferBytes} B</span>
                  <span>Max: 64 KB</span>
                </div>
              </div>
            )}

            {mechanism === 'fifo' && (
              <div>
                <div className="flex items-center justify-center gap-1.5 text-xs text-amber-400 font-mono font-medium mb-1">
                  <HardDrive className="w-3.5 h-3.5" />
                  <span>Filesystem FIFO Inode</span>
                </div>
                <div className="text-xs text-slate-300 font-mono truncate px-1" title={isAtoB ? channelState.fifoPaths.aToB : channelState.fifoPaths.bToA}>
                  {isAtoB ? '/tmp/ipc_chat_a2b.fifo' : '/tmp/ipc_chat_b2a.fifo'}
                </div>
                <div className="text-[11px] text-slate-400 mt-2 font-mono flex items-center justify-center gap-2">
                  <span>Inode #84912</span>
                  <span>·</span>
                  <span className="text-emerald-400">Rendezvous OK</span>
                </div>
              </div>
            )}

            {mechanism === 'shm' && (
              <div>
                <div className="flex items-center justify-center gap-1.5 text-xs text-emerald-400 font-mono font-medium mb-1">
                  <Cpu className="w-3.5 h-3.5" />
                  <span>Zero-Copy RAM Block</span>
                </div>
                <div className="text-xs text-slate-300 font-mono">
                  {channelState.shmState.segmentAddress}
                </div>
                <div className="flex items-center justify-center gap-2 mt-2 text-xs font-mono">
                  {channelState.shmState.mutexLocked ? (
                    <span className="inline-flex items-center gap-1 text-amber-400">
                      <Lock className="w-3 h-3" /> Mutex Locked
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-emerald-400">
                      <Unlock className="w-3 h-3" /> Mutex Free
                    </span>
                  )}
                  <span className="text-slate-500">·</span>
                  <span className="text-slate-400">4096 B Block</span>
                </div>
              </div>
            )}
          </div>

          {/* Node 3: Process B Gateway */}
          <div className={`p-4 rounded-xl border transition-all ${
            (!isAtoB && packetStage === 'sender_outbox') || (isAtoB && packetStage === 'delivered')
              ? 'bg-cyan-950/40 border-cyan-500/60 shadow-[0_0_15px_rgba(6,182,212,0.15)]'
              : 'bg-slate-900/80 border-slate-800'
          }`}>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="font-semibold text-slate-300">Process B Gateway</span>
              <span className="font-mono text-slate-400">PID 2482</span>
            </div>
            <div className="text-xs text-slate-400 font-mono flex items-center justify-between">
              <span>{mechanism === 'pipe' ? (isAtoB ? 'fd[3] read' : 'fd[6] write') : mechanism === 'fifo' ? 'O_RDONLY' : 'mmap() 0x7ffd1'}</span>
              <span className={`text-[11px] ${processBState === 'running' ? 'text-emerald-400' : 'text-rose-400'}`}>
                {processBState === 'running' ? 'Active' : 'Stopped'}
              </span>
            </div>
          </div>

        </div>

        {/* Animated Flying Packet Overlay */}
        {activePacket && packetStage !== 'idle' && (
          <div
            className={`mt-4 p-3 rounded-lg border text-xs font-mono transition-all duration-300 flex items-center justify-between ${
              packetStage === 'error'
                ? 'bg-rose-950/60 border-rose-500/80 text-rose-200'
                : 'bg-cyan-950/70 border-cyan-400 text-cyan-100 shadow-[0_0_15px_rgba(6,182,212,0.25)]'
            }`}
          >
            <div className="flex items-center gap-2">
              {isAtoB ? <ArrowRight className="w-4 h-4 text-cyan-400 shrink-0" /> : <ArrowLeft className="w-4 h-4 text-cyan-400 shrink-0" />}
              <div>
                <span className="text-slate-400 font-normal">Payload: </span>
                <span className="font-semibold text-white">"{activePacket.content}"</span>
              </div>
            </div>

            <div className="flex items-center gap-3 text-right shrink-0">
              <span className="text-slate-400">{activePacket.sizeBytes} Bytes</span>
              <span className="text-slate-500">·</span>
              <span className="text-cyan-300 font-bold uppercase text-[11px]">
                {packetStage === 'sender_outbox'
                  ? 'Transmitting...'
                  : packetStage === 'kernel_buffer'
                  ? 'Inside Channel'
                  : packetStage === 'delivered'
                  ? 'Delivered OK'
                  : 'SIGPIPE Error'}
              </span>
            </div>
          </div>
        )}

      </div>

      {/* Channel Explanation Footer */}
      <div className="pt-3 border-t border-slate-800/80 text-xs text-slate-400 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-cyan-400" />
          <span>
            {mechanism === 'pipe' && 'Anonymous pipes use kernel circular memory buffer; blocked reads release on write.'}
            {mechanism === 'fifo' && 'Named pipes rendezvous at filesystem node; data stays in RAM without touching disk.'}
            {mechanism === 'shm' && 'Shared memory avoids memory copying completely; semaphores guard concurrent read/write.'}
          </span>
        </div>
        <div className="font-mono text-slate-400 text-[11px]">
          OS Syscall: {mechanism === 'pipe' ? 'pipe(int fd[2])' : mechanism === 'fifo' ? 'mkfifo(path, mode)' : 'shm_open() + mmap()'}
        </div>
      </div>
    </div>
  );
};
