import React, { useState } from 'react';
import { ChannelState, IPCMechanismType, IPCMessage, ProcessState } from '../../types/ipc';
import { ChannelVisualizer } from './ChannelVisualizer';
import { Send, Play, Square, Trash2, RotateCcw, AlertTriangle, ArrowRight, CornerDownLeft } from 'lucide-react';

interface IPCPlaygroundProps {
  mechanism: IPCMechanismType;
  setMechanism: (m: IPCMechanismType) => void;
  channelState: ChannelState;
  messages: IPCMessage[];
  processAState: ProcessState;
  processBState: ProcessState;
  setProcessAState: (s: ProcessState) => void;
  setProcessBState: (s: ProcessState) => void;
  onSendMessage: (senderId: 'proc_a' | 'proc_b', text: string) => Promise<void>;
  onClearChat: () => void;
  onResetSimulation: () => void;
  activePacket: IPCMessage | null;
  packetStage: 'idle' | 'sender_outbox' | 'kernel_buffer' | 'receiver_inbox' | 'delivered' | 'error';
  direction: 'a_to_b' | 'b_to_a';
  animationSpeed: 'slow' | 'normal' | 'fast';
  setAnimationSpeed: (s: 'slow' | 'normal' | 'fast') => void;
  errorSimulation: 'none' | 'sigpipe' | 'buffer_full';
  setErrorSimulation: (e: 'none' | 'sigpipe' | 'buffer_full') => void;
}

export const IPCPlayground: React.FC<IPCPlaygroundProps> = ({
  mechanism,
  setMechanism,
  channelState,
  messages,
  processAState,
  processBState,
  setProcessAState,
  setProcessBState,
  onSendMessage,
  onClearChat,
  onResetSimulation,
  activePacket,
  packetStage,
  direction,
  animationSpeed,
  setAnimationSpeed,
  errorSimulation,
  setErrorSimulation
}) => {
  const [inputA, setInputA] = useState('');
  const [inputB, setInputB] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [validationErrorA, setValidationErrorA] = useState<string | null>(null);
  const [validationErrorB, setValidationErrorB] = useState<string | null>(null);

  const presetsA = [
    'HELO_B: Ready for transfer',
    'QUERY: Sensor_temperature_C',
    'SYNC_CLOCK: 1776378291',
    'PING: Sequence_#001'
  ];

  const presetsB = [
    'ACK: Packet sequence accepted',
    'DATA: Temp=23.4C, Humidity=48%',
    'PONG: Round-trip confirmed',
    'ERR_CODE: 0 (Nominal)'
  ];

  const handleSendA = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setValidationErrorA(null);

    if (processAState === 'stopped') {
      setValidationErrorA('Cannot send: Process A is currently stopped.');
      return;
    }
    if (!inputA.trim()) {
      setValidationErrorA('Please enter a message or choose a preset.');
      return;
    }

    try {
      setIsSending(true);
      await onSendMessage('proc_a', inputA.trim());
      setInputA('');
    } finally {
      setIsSending(false);
    }
  };

  const handleSendB = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setValidationErrorB(null);

    if (processBState === 'stopped') {
      setValidationErrorB('Cannot send: Process B is currently stopped.');
      return;
    }
    if (!inputB.trim()) {
      setValidationErrorB('Please enter a reply or choose a preset.');
      return;
    }

    try {
      setIsSending(true);
      await onSendMessage('proc_b', inputB.trim());
      setInputB('');
    } finally {
      setIsSending(false);
    }
  };

  const messagesA = messages.filter(m => m.senderId === 'proc_a' || m.receiverId === 'proc_a');
  const messagesB = messages.filter(m => m.senderId === 'proc_b' || m.receiverId === 'proc_b');

  return (
    <div className="space-y-6">
      
      {/* Top Mechanism Selection Bar & Simulation Controls */}
      <div className="bg-[#0e1526] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
        
        {/* IPC Selector Buttons */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-medium mr-1 hidden sm:inline">Mechanism:</span>
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-1 text-xs font-medium">
            <button
              onClick={() => setMechanism('pipe')}
              className={`px-3 py-1.5 rounded-md cursor-pointer transition-colors ${
                mechanism === 'pipe'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Anonymous Pipe
            </button>
            <button
              onClick={() => setMechanism('fifo')}
              className={`px-3 py-1.5 rounded-md cursor-pointer transition-colors ${
                mechanism === 'fifo'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Named Pipe (FIFO)
            </button>
            <button
              onClick={() => setMechanism('shm')}
              className={`px-3 py-1.5 rounded-md cursor-pointer transition-colors ${
                mechanism === 'shm'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Shared Memory
            </button>
          </div>
        </div>

        {/* Global Action Buttons */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={onClearChat}
            className="px-3 py-1.5 text-xs text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors"
            title="Clear visible chat history"
          >
            <Trash2 className="w-3.5 h-3.5 text-slate-400" />
            <span>Clear Chat</span>
          </button>

          <button
            onClick={onResetSimulation}
            className="px-3 py-1.5 text-xs text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg flex items-center gap-1.5 cursor-pointer transition-colors"
            title="Reset processes and channel state"
          >
            <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
            <span>Reset Lab</span>
          </button>
        </div>
      </div>

      {/* Central Visualizer of the Live IPC Channel */}
      <ChannelVisualizer
        mechanism={mechanism}
        channelState={channelState}
        activePacket={activePacket}
        packetStage={packetStage}
        direction={direction}
        processAState={processAState}
        processBState={processBState}
        animationSpeed={animationSpeed}
        setAnimationSpeed={setAnimationSpeed}
        errorSimulation={errorSimulation}
        setErrorSimulation={setErrorSimulation}
      />

      {/* Two Independent Process Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* ================= PROCESS A (Sender / Process 1) ================= */}
        <div className="bg-[#0e1526] border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            {/* Header with PID and State Toggle */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className={`w-3 h-3 rounded-full ${processAState === 'running' ? 'bg-emerald-400 ring-2 ring-emerald-500/20' : 'bg-rose-400'}`} />
                <div>
                  <h3 className="text-sm font-semibold text-slate-200">Process A (Sender / Peer 1)</h3>
                  <div className="text-xs text-slate-400 font-mono">
                    PID: 2481 · State: <span className={processAState === 'running' ? 'text-emerald-400 uppercase font-semibold' : 'text-rose-400 uppercase font-semibold'}>{processAState}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {processAState === 'running' ? (
                  <button
                    onClick={() => setProcessAState('stopped')}
                    className="px-2.5 py-1 text-xs text-rose-300 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/50 rounded-md flex items-center gap-1 cursor-pointer transition-colors"
                    title="Stop Process A (Will trigger SIGPIPE if written to)"
                  >
                    <Square className="w-3 h-3 fill-rose-400 text-rose-400" />
                    <span>Stop</span>
                  </button>
                ) : (
                  <button
                    onClick={() => setProcessAState('running')}
                    className="px-2.5 py-1 text-xs text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-800/50 rounded-md flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Play className="w-3 h-3 fill-emerald-400 text-emerald-400" />
                    <span>Start</span>
                  </button>
                )}
              </div>
            </div>

            {/* Process A Chat Stream */}
            <div className="mt-4 mb-3">
              <div className="text-xs text-slate-400 font-mono mb-1.5 flex justify-between">
                <span>Process A Outbox & Log</span>
                <span>{messagesA.length} packets</span>
              </div>
              
              <div className="h-48 overflow-y-auto bg-slate-950/70 border border-slate-850 rounded-lg p-3 space-y-2 text-xs font-mono">
                {messagesA.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-slate-500 italic">
                    No communication packets yet. Send a message below.
                  </div>
                ) : (
                  messagesA.map((msg) => {
                    const isOutbound = msg.senderId === 'proc_a';
                    return (
                      <div
                        key={msg.id}
                        className={`p-2 rounded border text-xs ${
                          msg.status.startsWith('error')
                            ? 'bg-rose-950/40 border-rose-800/60 text-rose-300'
                            : isOutbound
                            ? 'bg-cyan-950/30 border-cyan-800/50 text-slate-200'
                            : 'bg-slate-900 border-slate-800 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                          <span className="font-semibold text-cyan-400">
                            {isOutbound ? 'TX ➔ To Process B' : 'RX 🠐 From Process B'}
                          </span>
                          <span>{msg.timestamp} · {msg.latencyMs}ms</span>
                        </div>
                        <div className="text-slate-100 break-words font-sans">{msg.content}</div>
                        {msg.errorMessage && (
                          <div className="text-[11px] text-rose-400 mt-1 font-mono">
                            ⚠ Error: {msg.errorMessage}
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Presets */}
            <div className="mb-3">
              <span className="text-[11px] text-slate-400 block mb-1">Quick Test Presets:</span>
              <div className="flex flex-wrap gap-1.5">
                {presetsA.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setInputA(preset)}
                    className="text-[11px] px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 cursor-pointer transition-colors"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Input & Send Form */}
          <div>
            {validationErrorA && (
              <div className="mb-2 text-xs text-rose-400 flex items-center gap-1 font-mono">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span>{validationErrorA}</span>
              </div>
            )}

            <form onSubmit={handleSendA} className="flex gap-2">
              <input
                type="text"
                value={inputA}
                onChange={(e) => {
                  setInputA(e.target.value);
                  if (validationErrorA) setValidationErrorA(null);
                }}
                disabled={processAState === 'stopped' || isSending}
                placeholder={processAState === 'stopped' ? 'Process A is stopped' : 'Type message to send via IPC...'}
                className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={processAState === 'stopped' || isSending}
                className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Send</span>
              </button>
            </form>
          </div>
        </div>

        {/* ================= PROCESS B (Receiver / Process 2) ================= */}
        <div className="bg-[#0e1526] border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            {/* Header with PID and State Toggle */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className={`w-3 h-3 rounded-full ${processBState === 'running' ? 'bg-emerald-400 ring-2 ring-emerald-500/20' : 'bg-rose-400'}`} />
                <div>
                  <h3 className="text-sm font-semibold text-slate-200">Process B (Receiver / Peer 2)</h3>
                  <div className="text-xs text-slate-400 font-mono">
                    PID: 2482 · State: <span className={processBState === 'running' ? 'text-emerald-400 uppercase font-semibold' : 'text-rose-400 uppercase font-semibold'}>{processBState}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {processBState === 'running' ? (
                  <button
                    onClick={() => setProcessBState('stopped')}
                    className="px-2.5 py-1 text-xs text-rose-300 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/50 rounded-md flex items-center gap-1 cursor-pointer transition-colors"
                    title="Stop Process B (Will cause SIGPIPE if A writes)"
                  >
                    <Square className="w-3 h-3 fill-rose-400 text-rose-400" />
                    <span>Stop</span>
                  </button>
                ) : (
                  <button
                    onClick={() => setProcessBState('running')}
                    className="px-2.5 py-1 text-xs text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900/60 border border-emerald-800/50 rounded-md flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <Play className="w-3 h-3 fill-emerald-400 text-emerald-400" />
                    <span>Start</span>
                  </button>
                )}
              </div>
            </div>

            {/* Process B Chat Stream */}
            <div className="mt-4 mb-3">
              <div className="text-xs text-slate-400 font-mono mb-1.5 flex justify-between">
                <span>Process B Inbox & Log</span>
                <span>{messagesB.length} packets</span>
              </div>
              
              <div className="h-48 overflow-y-auto bg-slate-950/70 border border-slate-850 rounded-lg p-3 space-y-2 text-xs font-mono">
                {messagesB.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-slate-500 italic">
                    Waiting for incoming IPC packets from Process A...
                  </div>
                ) : (
                  messagesB.map((msg) => {
                    const isOutbound = msg.senderId === 'proc_b';
                    return (
                      <div
                        key={msg.id}
                        className={`p-2 rounded border text-xs ${
                          msg.status.startsWith('error')
                            ? 'bg-rose-950/40 border-rose-800/60 text-rose-300'
                            : isOutbound
                            ? 'bg-emerald-950/30 border-emerald-800/50 text-slate-200'
                            : 'bg-slate-900 border-slate-800 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                          <span className="font-semibold text-emerald-400">
                            {isOutbound ? 'TX ➔ Reply To Process A' : 'RX 🠐 From Process A'}
                          </span>
                          <span>{msg.timestamp} · {msg.latencyMs}ms</span>
                        </div>
                        <div className="text-slate-100 break-words font-sans">{msg.content}</div>
                        {msg.errorMessage && (
                          <div className="text-[11px] text-rose-400 mt-1 font-mono">
                            ⚠ Error: {msg.errorMessage}
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Presets */}
            <div className="mb-3">
              <span className="text-[11px] text-slate-400 block mb-1">Reply Presets:</span>
              <div className="flex flex-wrap gap-1.5">
                {presetsB.map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setInputB(preset)}
                    className="text-[11px] px-2 py-0.5 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 cursor-pointer transition-colors"
                  >
                    {preset}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Reply Form */}
          <div>
            {validationErrorB && (
              <div className="mb-2 text-xs text-rose-400 flex items-center gap-1 font-mono">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span>{validationErrorB}</span>
              </div>
            )}

            <form onSubmit={handleSendB} className="flex gap-2">
              <input
                type="text"
                value={inputB}
                onChange={(e) => {
                  setInputB(e.target.value);
                  if (validationErrorB) setValidationErrorB(null);
                }}
                disabled={processBState === 'stopped' || isSending}
                placeholder={processBState === 'stopped' ? 'Process B is stopped' : 'Type reply to send back to Process A...'}
                className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={processBState === 'stopped' || isSending}
                className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg flex items-center gap-1.5 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                <CornerDownLeft className="w-3.5 h-3.5" />
                <span>Reply</span>
              </button>
            </form>
          </div>
        </div>

      </div>
    </div>
  );
};
