import { ComparisonFeature, QuizQuestion } from '../types/ipc';

export const C_CODE_EXAMPLES = {
  pipe: `/* pipe_chat.c - Anonymous Pipe Bidirectional Communication */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define BUFFER_SIZE 256

int main() {
    int pipe_a2b[2]; // Pipe: Process A (parent) -> Process B (child)
    int pipe_b2a[2]; // Pipe: Process B (child) -> Process A (parent)
    pid_t pid;

    // Create two unidirectional pipes for full-duplex communication
    if (pipe(pipe_a2b) == -1 || pipe(pipe_b2a) == -1) {
        perror("pipe creation failed");
        exit(EXIT_FAILURE);
    }

    pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(EXIT_FAILURE);
    }

    if (pid > 0) {
        /* PROCESS A (Parent Process) */
        close(pipe_a2b[0]); // Close unused read end of A->B
        close(pipe_b2a[1]); // Close unused write end of B->A

        char msg_out[] = "Hello from Process A (PID: Parent)!";
        printf("[Process A] Sending: %s\\n", msg_out);
        write(pipe_a2b[1], msg_out, strlen(msg_out) + 1);

        char msg_in[BUFFER_SIZE];
        read(pipe_b2a[0], msg_in, sizeof(msg_in));
        printf("[Process A] Received reply: %s\\n", msg_in);

        close(pipe_a2b[1]);
        close(pipe_b2a[0]);
        wait(NULL); // Reaping child
    } else {
        /* PROCESS B (Child Process) */
        close(pipe_a2b[1]); // Close unused write end of A->B
        close(pipe_b2a[0]); // Close unused read end of B->A

        char msg_in[BUFFER_SIZE];
        read(pipe_a2b[0], msg_in, sizeof(msg_in));
        printf("    [Process B] Received: %s\\n", msg_in);

        char reply[] = "ACK: Process B received your packet!";
        printf("    [Process B] Sending reply: %s\\n", reply);
        write(pipe_b2a[1], reply, strlen(reply) + 1);

        close(pipe_a2b[0]);
        close(pipe_b2a[1]);
        exit(EXIT_SUCCESS);
    }

    return 0;
}`,

  fifo: `/* fifo_chat_a.c - Named Pipe (FIFO) Process A (Writer & Reader) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#define FIFO_A2B "/tmp/ipc_chat_a2b.fifo"
#define FIFO_B2A "/tmp/ipc_chat_b2a.fifo"
#define BUFFER_SIZE 256

int main() {
    // Create FIFOs in filesystem with rw-rw-rw permissions
    mkfifo(FIFO_A2B, 0666);
    mkfifo(FIFO_B2A, 0666);

    printf("[Process A] Waiting for Process B to connect...\\n");
    // Open write end (blocks until Process B opens read end)
    int fd_write = open(FIFO_A2B, O_WRONLY);
    int fd_read  = open(FIFO_B2A, O_RDONLY);
    printf("[Process A] Channel established!\\n");

    char message[] = "Greetings from Independent Process A!";
    write(fd_write, message, strlen(message) + 1);
    printf("[Process A] Sent: %s\\n", message);

    char reply[BUFFER_SIZE];
    read(fd_read, reply, sizeof(reply));
    printf("[Process A] Received from B: %s\\n", reply);

    close(fd_write);
    close(fd_read);
    unlink(FIFO_A2B); // Remove named pipes
    unlink(FIFO_B2A);
    return 0;
}`,

  shm: `/* shm_chat.c - POSIX Shared Memory with Mutex/Condition Semaphores */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <unistd.h>

#define SHM_NAME "/ipc_chat_shm"
#define BUFFER_SIZE 512

struct shared_chat_block {
    sem_t mutex;            // Mutual exclusion binary semaphore
    sem_t data_available;   // Signaled when a new message is ready
    int message_ready;      // Flag: 1 if unread, 0 if consumed
    char sender[32];
    char text[BUFFER_SIZE];
};

int main() {
    // 1. Create or open POSIX shared memory object
    int shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    ftruncate(shm_fd, sizeof(struct shared_chat_block));

    // 2. Map into calling process's virtual address space (Zero-Copy)
    struct shared_chat_block *block = mmap(
        NULL, sizeof(struct shared_chat_block),
        PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0
    );

    // 3. Initialize process-shared semaphores (pshared = 1)
    sem_init(&block->mutex, 1, 1);
    sem_init(&block->data_available, 1, 0);
    block->message_ready = 0;

    printf("[Shared Memory] Mapped at virtual address %p\\n", (void*)block);

    // Write message safely within critical section
    sem_wait(&block->mutex);
    strncpy(block->sender, "Process_A", sizeof(block->sender));
    strncpy(block->text, "High-throughput zero-copy packet", sizeof(block->text));
    block->message_ready = 1;
    sem_post(&block->mutex);

    sem_post(&block->data_available); // Signal consumer process
    printf("[Process A] Message committed directly to physical RAM block!\\n");

    munmap(block, sizeof(struct shared_chat_block));
    close(shm_fd);
    shm_unlink(SHM_NAME);
    return 0;
}`
};

export const COMPARISON_DATA: ComparisonFeature[] = [
  {
    metric: 'Process Relationship',
    category: 'Architecture',
    pipe: 'Related processes only (parent-child or sibling via fork())',
    fifo: 'Completely unrelated & independent processes',
    shm: 'Any independent processes with access permissions',
    detail: 'Pipes inherit file descriptors across fork(). FIFOs use filesystem inode names. SHM uses shared memory keys/names.'
  },
  {
    metric: 'Data Transfer Mechanism',
    category: 'Performance',
    pipe: 'Byte stream copied through kernel ring buffer',
    fifo: 'Byte stream copied through kernel ring buffer (backed by FIFO inode)',
    shm: 'Zero-copy direct memory access (Physical RAM mapped into process space)',
    detail: 'Pipes require two kernel copies (user -> kernel -> user). Shared memory requires ZERO copies.'
  },
  {
    metric: 'Synchronization',
    category: 'Concurrency',
    pipe: 'Built-in OS blocking (read blocks when empty; write blocks when 64KB full)',
    fifo: 'Built-in OS blocking (open, read, and write block until peer attaches)',
    shm: 'None built-in. Requires explicit synchronization (POSIX semaphores or mutexes)',
    detail: 'Failing to synchronize shared memory results in race conditions and dirty reads.'
  },
  {
    metric: 'Persistence',
    category: 'Lifecycle',
    pipe: 'Process lifecycle only (destroys when all file descriptors close)',
    fifo: 'Filesystem persistence (inode persists until unlink() or reboot)',
    shm: 'Kernel persistence (persists until shm_unlink()/ipcrm or reboot)',
    detail: 'Named pipes leave a special device file in /tmp/ until explicitly unlinked.'
  },
  {
    metric: 'Typical Linux Throughput',
    category: 'Performance',
    pipe: 'High (~2 to 4 GB/s on modern NVMe/RAM cache via page cache)',
    fifo: 'High (~2 to 4 GB/s, identical kernel pipe buffer implementation)',
    shm: 'Extreme (~20 to 50+ GB/s, bounded strictly by DDR4/DDR5 RAM bandwidth)',
    detail: 'Shared memory has no context-switch kernel boundary tax during payload transfer.'
  },
  {
    metric: 'Primary System Calls',
    category: 'API & Linux Calls',
    pipe: 'pipe(), fork(), read(), write(), close()',
    fifo: 'mkfifo(), open(), read(), write(), close(), unlink()',
    shm: 'shm_open(), ftruncate(), mmap(), sem_init(), sem_wait(), sem_post()',
    detail: 'POSIX APIs are modern standard; System V equivalents are shmget(), shmat(), semop().'
  },
  {
    metric: 'Failure & Error States',
    category: 'Reliability',
    pipe: 'SIGPIPE signal if writing to closed read end; deadlocks on circular reads',
    fifo: 'Blocks indefinitely if receiver is killed before open(); broken pipe',
    shm: 'Race conditions, torn writes, deadlocks if process dies while holding mutex',
    detail: 'Robust shared memory code must employ robust mutexes (PTHREAD_MUTEX_ROBUST).'
  },
  {
    metric: 'Real-World Production Uses',
    category: 'Applications',
    pipe: 'Unix command pipelines (ls | grep | wc), parent-worker task runners',
    fifo: 'System log daemons, background service input feeds, inter-language bridge',
    shm: 'PostgreSQL shared buffers, Chrome browser multi-process GPU rendering, High-Frequency Trading'
  }
];

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: 'Why can an Anonymous Pipe (created via pipe()) NOT be used to communicate between two independent processes started in separate terminals?',
    options: [
      'Anonymous pipes are slower than terminal input/output buffers.',
      'Anonymous pipes have no filesystem path or identifier; file descriptors can only be inherited via fork().',
      'The Linux kernel restricts anonymous pipes to the root user only.',
      'Anonymous pipes can only transfer binary numbers, not text characters.'
    ],
    correctIndex: 1,
    explanation: 'Anonymous pipes exist solely as memory buffers associated with file descriptors in the process file table. Because they lack a filesystem node or global identifier, only child processes created via fork() can inherit access to them.',
    category: 'pipes'
  },
  {
    id: 2,
    question: 'What happens by default when a process writes to a pipe whose read end has been closed by all readers?',
    options: [
      'The write silently discards the bytes with zero error.',
      'The kernel sends a SIGPIPE signal to the writing process and write() fails with EPIPE.',
      'The kernel pauses the writing process indefinitely until a reader opens it.',
      'The data is automatically saved to /tmp/dead_letters.'
    ],
    correctIndex: 1,
    explanation: 'Writing to a pipe or FIFO with no open read end is illegal in POSIX. The kernel delivers a SIGPIPE signal (which terminates the process by default unless caught or ignored) and write() returns -1 with errno set to EPIPE.',
    category: 'pipes'
  },
  {
    id: 3,
    question: 'How do Named Pipes (FIFOs) solve the independent process limitation of anonymous pipes?',
    options: [
      'They transmit data over internet sockets using IP addresses.',
      'They create a special FIFO node in the filesystem (via mkfifo()) with an inode that any unrelated process can open().',
      'They store messages permanently on the hard disk inside a SQLite database.',
      'They bypass the operating system kernel completely using CPU registers.'
    ],
    correctIndex: 1,
    explanation: 'Named pipes exist as special directory entries on the filesystem created by mkfifo(). While the data itself still flows through a kernel memory buffer (never written to disk!), any independent process with proper file permissions can open() the path.',
    category: 'fifo'
  },
  {
    id: 4,
    question: 'Why does Shared Memory provide the highest data throughput among all IPC mechanisms?',
    options: [
      'Because it compresses messages with gzip before sending.',
      'Because the kernel encrypts it with specialized hardware instructions.',
      'Because communication occurs at memory speed (Zero-Copy) without copying data into and out of kernel space.',
      'Because it uses multiple CPU cores in parallel for every byte.'
    ],
    correctIndex: 2,
    explanation: 'Traditional IPC (pipes, FIFOs, sockets) requires copying data from user space to kernel space, and then from kernel space back to user space. Shared memory maps the exact same physical RAM pages into both processes, eliminating the kernel buffer copy altogether.',
    category: 'shm'
  },
  {
    id: 5,
    question: 'What is the primary danger when two processes communicate via Shared Memory without explicit synchronization?',
    options: [
      'The computer motherboard will overheat.',
      'Race conditions, torn reads/writes, and inconsistent data states.',
      'The hard drive will run out of inodes.',
      'The network router will reject the packets.'
    ],
    correctIndex: 1,
    explanation: 'Unlike pipes, shared memory does not have automatic blocking or queueing. If Process A writes while Process B reads without a mutex or semaphore, Process B may read partially updated or corrupted memory.',
    category: 'shm'
  },
  {
    id: 6,
    question: 'What is the typical default buffer capacity of a pipe on modern Linux systems?',
    options: [
      '512 bytes',
      '64 Kilobytes (65,536 bytes / 16 memory pages)',
      '10 Megabytes',
      'Unlimited virtual memory'
    ],
    correctIndex: 1,
    explanation: 'Since Linux 2.6.11, the default pipe buffer size is 65,536 bytes (64 KB). If a writer attempts to write more data into a full pipe without a reader consuming it, the write() call blocks.',
    category: 'pipes'
  },
  {
    id: 7,
    question: 'In POSIX shared memory, which pair of system calls is used to create and attach the memory segment?',
    options: [
      'malloc() and free()',
      'shm_open() followed by mmap()',
      'pipe() followed by dup2()',
      'socket() followed by connect()'
    ],
    correctIndex: 1,
    explanation: 'shm_open() creates or opens a POSIX shared memory object and returns a file descriptor, and mmap() maps that memory segment into the calling process address space.',
    category: 'shm'
  },
  {
    id: 8,
    question: 'What happens when a process calls open() on a Named Pipe with O_RDONLY, but no process has opened it for writing yet?',
    options: [
      'The open() call immediately crashes with a segmentation fault.',
      'The open() call returns an empty buffer immediately.',
      'The open() call blocks and waits until another process opens the FIFO for writing (unless O_NONBLOCK is set).',
      'The kernel creates a background thread to generate dummy messages.'
    ],
    correctIndex: 2,
    explanation: 'Opening a FIFO is a rendezvous operation. A read-only open() blocks until a writer connects, and a write-only open() blocks until a reader connects. This ensures synchronization without extra code.',
    category: 'fifo'
  }
];

export const LEARNING_MODULES = [
  {
    id: 'processes',
    title: '1. What is a Process & Virtual Memory Isolation',
    tag: 'Foundations',
    readTime: '3 min read',
    summary: 'Understand the operating system boundary that keeps programs strictly isolated in private address spaces.',
    content: `
### What is a Process?
An operating system **process** is an instance of a running computer program. When you execute an application, the OS kernel provisions:
- A private **Virtual Memory Address Space** (code, heap, stack, data)
- A set of **CPU register contexts** and instruction pointers
- A **File Descriptor Table** tracking open files, sockets, and pipes
- An isolated **Process ID (PID)** and security credentials

### Virtual Memory Isolation
Modern operating systems employ the hardware Memory Management Unit (MMU) to enforce strict isolation. Process A (e.g. PID 1024) cannot read or write to the memory addresses of Process B (PID 1025). If Process A attempts to access memory outside its allocated page tables, the CPU raises a hardware interrupt and the kernel terminates the process with a **Segmentation Fault (SIGSEGV)**.

Because of this necessary security and stability boundary, processes cannot simply "share a pointer" or read each other's variables. They need a mediated bridge: **Inter-Process Communication (IPC)**.
    `
  },
  {
    id: 'why_ipc',
    title: '2. Why IPC Exists & The Kernel Bridge',
    tag: 'Core Concept',
    readTime: '4 min read',
    summary: 'Explore how independent microservices, browser architectures, and operating system daemons cooperate safely.',
    content: `
### Why Do Independent Processes Need to Talk?
Real-world systems rarely run as monolithic giant programs. Modular multi-process architectures offer critical advantages:
- **Fault Isolation**: If one tab crashes in Google Chrome, only the renderer process dies. The browser UI and other tabs stay alive.
- **Privilege Separation**: A web server worker running as unprivileged user \`www-data\` communicates with an authenticated root daemon to bind low ports.
- **Concurrency & Parallelism**: Independent processes can execute across separate CPU cores simultaneously without sharing lock overhead.
- **Modularity & Unix Philosophy**: Programs do one job well and chain data using text streams (e.g., \`cat access.log | grep 404 | wc -l\`).

### The Two Major IPC Paradigms
All IPC mechanisms fall into one of two fundamental models:
1. **Message-Passing (Kernel-Mediated)**:
   - Examples: Anonymous Pipes, Named Pipes (FIFO), UNIX Domain Sockets, Message Queues
   - How it works: Data is copied from Process A's user space into a kernel buffer, and then copied from the kernel buffer into Process B's user space.
   - Advantage: Safe, built-in synchronization and boundary isolation.

2. **Shared Memory (Direct-Access)**:
   - Examples: POSIX Shared Memory (\`shm_open\`), System V Shared Memory (\`shmget\`)
   - How it works: The OS kernel maps the same physical RAM page frames into the page tables of multiple processes.
   - Advantage: Extremely fast zero-copy communication.
   - Requirement: The developer must coordinate access using semaphores or mutexes.
    `
  },
  {
    id: 'pipes_deep_dive',
    title: '3. Anonymous Pipes: File Descriptors & Ring Buffers',
    tag: 'Mechanism Deep Dive',
    readTime: '5 min read',
    summary: 'Deep dive into the unidirectional byte stream created by the pipe() system call and managed in kernel ring buffers.',
    content: `
### How Anonymous Pipes Work
An anonymous pipe is a unidirectional data channel managed directly by the kernel memory.
\`\`\`c
int fds[2];
pipe(fds);
// fds[0] is opened for READING
// fds[1] is opened for WRITING
\`\`\`

### The Fork-Inheritance Pattern
Because the pipe has no name in the filesystem, unrelated processes cannot open it. It is strictly used between related processes:
1. Parent process calls \`pipe(fds)\`.
2. Parent calls \`fork()\`, cloning its file descriptor table into the child.
3. Both parent and child now have access to \`fds[0]\` and \`fds[1]\`.
4. To avoid deadlocks and broken pipe errors, each process closes the end it doesn't use:
   - Sender closes \`fds[0]\` (read end) and writes to \`fds[1]\`.
   - Receiver closes \`fds[1]\` (write end) and reads from \`fds[0]\`.

### The 64KB Kernel Ring Buffer
Pipes are backed by a **circular FIFO buffer** in kernel RAM (typically 65,536 bytes).
- When a writer writes, bytes are placed into the ring buffer.
- When a reader reads, bytes are extracted in FIFO order.
- If the buffer fills up, subsequent \`write()\` calls **block** until the reader drains data.
- If the buffer is empty, \`read()\` **blocks** until new data arrives.
    `
  },
  {
    id: 'fifo_deep_dive',
    title: '4. Named Pipes (FIFOs): Filesystem Inodes',
    tag: 'Mechanism Deep Dive',
    readTime: '4 min read',
    summary: 'Learn how mkfifo() attaches a kernel pipe to a filesystem path so completely independent programs can chat.',
    content: `
### Breaking Free of the Parent-Child Constraint
What if you have two independent programs—say a Python script and a C daemon started in different terminal windows—that need to communicate?
Anonymous pipes cannot connect them. This is where **Named Pipes (FIFOs)** come in.

### The mkfifo() System Call
\`\`\`c
mkfifo("/tmp/my_service.fifo", 0666);
\`\`\`
This creates a special file with file type \`p\` (FIFO) visible in the directory listing (\`ls -l /tmp/my_service.fifo\`).

### Crucial Inode Fact: Zero Disk I/O!
Students often mistakenly assume that because a named pipe sits on the filesystem, messages are written to the SSD or hard drive.
**They are not!** The filesystem entry is merely a directory reference (an inode) pointing to an internal kernel buffer. Reading and writing to a FIFO happens strictly in RAM.

### Rendezvous Semantics
- When Process A opens a FIFO with \`O_WRONLY\`, \`open()\` blocks until Process B opens it with \`O_RDONLY\`.
- This automatic rendezvous ensures that neither sender nor receiver starts transmitting into the void.
    `
  },
  {
    id: 'shm_deep_dive',
    title: '5. Shared Memory & Semaphores: Zero-Copy',
    tag: 'Mechanism Deep Dive',
    readTime: '6 min read',
    summary: 'The pinnacle of IPC performance: mapping identical physical RAM frames into two virtual address spaces.',
    content: `
### What is Zero-Copy?
In pipes and sockets, sending a 100MB video frame involves:
1. Copy 100MB from Process A's heap to Kernel space.
2. Context switch to kernel mode.
3. Copy 100MB from Kernel space to Process B's heap.
4. Total: 200MB of RAM memory copies plus CPU context switches.

In **Shared Memory**, the kernel configures the CPU's MMU page tables so that both Process A's virtual address (e.g., \`0x7ffd1000\`) and Process B's virtual address (e.g., \`0x55a42000\`) translate to the **exact same physical RAM chips**.
When Process A writes a byte, Process B can read it **instantly with zero kernel copies**.

### The Synchronization Mandate
Because the kernel does not intermediate reads and writes, shared memory has no built-in FIFO queue or blocking.
If both processes write at the same time, memory corruption occurs.

Therefore, shared memory is always paired with synchronization primitives:
- **POSIX Semaphores (\`sem_t\`)**: A counter protected by atomic CPU instructions (\`sem_wait\` and \`sem_post\`).
- **Process-Shared Mutexes**: Using \`pthread_mutexattr_setpshared(&attr, PTHREAD_PROCESS_SHARED)\`.
    `
  },
  {
    id: 'ipc_pitfalls',
    title: '6. Common IPC Pitfalls & Error Handling',
    tag: 'Debugging & Reliability',
    readTime: '4 min read',
    summary: 'How to diagnose and prevent SIGPIPE crashes, circular deadlocks, buffer overflows, and orphaned FIFOs.',
    content: `
### 1. SIGPIPE & EPIPE
**The Symptom**: Your sender process abruptly crashes without a stack trace when attempting to write.
**The Cause**: The receiver process exited or closed its read file descriptor. The kernel delivers signal 13 (\`SIGPIPE\`).
**The Fix**:
\`\`\`c
signal(SIGPIPE, SIG_IGN); // Ignore SIGPIPE
// Now write() returns -1 with errno == EPIPE, which you can handle gracefully!
\`\`\`

### 2. The Circular Deadlock
**The Symptom**: Both Process A and Process B freeze forever.
**The Cause**:
- Process A opens \`pipe1\` for writing, then blocks trying to open \`pipe2\` for reading.
- Process B opens \`pipe2\` for writing, then blocks trying to open \`pipe1\` for reading.
Both are waiting on the other to open the complementary end.
**The Fix**: Always open complementary ends in a consistent, standardized global order across both processes, or use non-blocking flags (\`O_NONBLOCK\`).

### 3. Orphaned FIFOs & Stale Locks
If a process crashes while holding a mutex on shared memory, other processes will block indefinitely. Always implement timeout-based locks (\`sem_timedwait\`) or robust mutexes (\`PTHREAD_MUTEX_ROBUST\`).
    `
  }
];
