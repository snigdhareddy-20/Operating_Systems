import { ChannelState, DeliveryStatus, IPCMechanismType, IPCMessage, IPCProcess } from '../types/ipc';

const STORAGE_KEY_MESSAGES = 'ipc_connect_messages_v1';
const STORAGE_KEY_PROCESSES = 'ipc_connect_processes_v1';
const STORAGE_KEY_STATS = 'ipc_connect_stats_v1';

export const INITIAL_PROCESS_A: IPCProcess = {
  id: 'proc_a',
  name: 'Process A (Producer/Sender)',
  pid: 2481,
  state: 'running',
  role: 'sender',
  channel: 'fd[4] (Write End)',
  messagesSent: 0,
  messagesReceived: 0,
  bytesSent: 0,
  bytesReceived: 0,
  memoryUsageKb: 2840,
  cpuPercent: 0.4,
  lastActive: 'Just now'
};

export const INITIAL_PROCESS_B: IPCProcess = {
  id: 'proc_b',
  name: 'Process B (Consumer/Receiver)',
  pid: 2482,
  state: 'running',
  role: 'receiver',
  channel: 'fd[3] (Read End)',
  messagesSent: 0,
  messagesReceived: 0,
  bytesSent: 0,
  bytesReceived: 0,
  memoryUsageKb: 2410,
  cpuPercent: 0.2,
  lastActive: 'Just now'
};

export const INITIAL_CHANNEL_STATE: ChannelState = {
  mechanism: 'pipe',
  bufferCapacityBytes: 65536, // 64 KB POSIX pipe limit
  currentBufferBytes: 0,
  pipeFds: {
    aToB: [3, 4], // Read 3, Write 4
    bToA: [5, 6]  // Read 5, Write 6
  },
  fifoPaths: {
    aToB: '/tmp/ipc_chat_a2b.fifo',
    bToA: '/tmp/ipc_chat_b2a.fifo'
  },
  shmState: {
    segmentAddress: '0x7ffd98e21000',
    shmId: 38472,
    sizeBytes: 4096,
    mutexLocked: false,
    lockedByProcessId: null,
    activeDataSlot: 'Empty',
    readersWaiting: 0
  }
};

export function loadStoredMessages(): IPCMessage[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_MESSAGES);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.error('Failed to load messages from localStorage', e);
  }
  return [];
}

export function saveStoredMessages(messages: IPCMessage[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_MESSAGES, JSON.stringify(messages));
  } catch (e) {
    console.error('Failed to save messages to localStorage', e);
  }
}

export function exportLogsToCSV(messages: IPCMessage[]): void {
  if (messages.length === 0) return;

  const headers = ['ID', 'Timestamp', 'Sender PID', 'Sender Name', 'Receiver PID', 'Receiver Name', 'Mechanism', 'Payload', 'Size (Bytes)', 'Latency (ms)', 'Status', 'Error'];
  const rows = messages.map(msg => [
    msg.id,
    msg.timestamp,
    msg.senderId === 'proc_a' ? '2481' : '2482',
    `"${msg.senderName.replace(/"/g, '""')}"`,
    msg.receiverId === 'proc_a' ? '2481' : '2482',
    `"${msg.receiverName.replace(/"/g, '""')}"`,
    msg.mechanism.toUpperCase(),
    `"${msg.content.replace(/"/g, '""')}"`,
    msg.sizeBytes,
    msg.latencyMs.toFixed(2),
    msg.status,
    msg.errorMessage ? `"${msg.errorMessage.replace(/"/g, '""')}"` : ''
  ]);

  const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const dateStr = new Date().toISOString().slice(0, 10);
  a.setAttribute('download', 'ipc_connect_logs_' + dateStr + '.csv');
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function downloadCFile(filename: string, content: string): void {
  const blob = new Blob([content], { type: 'text/x-csrc;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.setAttribute('download', filename);
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export const MAKEFILE_CONTENT = `# IPC Connect - Real Linux IPC Programs Makefile
CC = gcc
CFLAGS = -Wall -Wextra -O2 -pthread
LDFLAGS = -lrt -pthread

TARGETS = pipe_chat fifo_chat_a fifo_chat_b shm_chat

all: $(TARGETS)

pipe_chat: pipe_chat.c
	$(CC) $(CFLAGS) pipe_chat.c -o pipe_chat

fifo_chat_a: fifo_chat_a.c
	$(CC) $(CFLAGS) fifo_chat_a.c -o fifo_chat_a

fifo_chat_b: fifo_chat_b.c
	$(CC) $(CFLAGS) fifo_chat_b.c -o fifo_chat_b

shm_chat: shm_chat.c
	$(CC) $(CFLAGS) shm_chat.c -o shm_chat $(LDFLAGS)

clean:
	rm -f $(TARGETS) /tmp/ipc_chat_*.fifo
	@echo "Cleaned build artifacts and temporary FIFO files."

run_pipe: pipe_chat
	./pipe_chat

run_shm: shm_chat
	./shm_chat

.PHONY: all clean run_pipe run_shm
`;
