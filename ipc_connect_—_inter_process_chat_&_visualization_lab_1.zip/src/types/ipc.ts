export type IPCMechanismType = 'pipe' | 'fifo' | 'shm';

export type ProcessState = 'running' | 'stopped' | 'blocked' | 'paused';

export interface IPCProcess {
  id: string;
  name: string;
  pid: number;
  state: ProcessState;
  role: 'sender' | 'receiver' | 'peer';
  channel: string;
  messagesSent: number;
  messagesReceived: number;
  bytesSent: number;
  bytesReceived: number;
  memoryUsageKb: number;
  cpuPercent: number;
  lastActive: string;
}

export type DeliveryStatus = 'delivered' | 'in_transit' | 'blocked' | 'error_sigpipe' | 'error_overflow';

export interface IPCMessage {
  id: string;
  senderId: string;
  senderName: string;
  receiverId: string;
  receiverName: string;
  content: string;
  timestamp: string;
  timestampMs: number;
  mechanism: IPCMechanismType;
  status: DeliveryStatus;
  latencyMs: number;
  sizeBytes: number;
  packetSeq: number;
  errorMessage?: string;
}

export interface ChannelState {
  mechanism: IPCMechanismType;
  bufferCapacityBytes: number;
  currentBufferBytes: number;
  pipeFds: {
    aToB: [number, number]; // [read_fd, write_fd] e.g. [3, 4]
    bToA: [number, number]; // [read_fd, write_fd] e.g. [5, 6]
  };
  fifoPaths: {
    aToB: string; // e.g. "/tmp/fifo_a2b"
    bToA: string; // e.g. "/tmp/fifo_b2a"
  };
  shmState: {
    segmentAddress: string; // "0x7ffd98e21000"
    shmId: number;
    sizeBytes: number;
    mutexLocked: boolean;
    lockedByProcessId: string | null;
    activeDataSlot: string;
    readersWaiting: number;
  };
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  category: 'pipes' | 'fifo' | 'shm' | 'general';
}

export interface ComparisonFeature {
  metric: string;
  category: string;
  pipe: string;
  fifo: string;
  shm: string;
  detail?: string;
}
